package com.example.api

import com.squareup.moshi.Json
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

data class TmdbResponse(
    val results: List<TmdbItemDto> = emptyList()
)

data class TmdbItemDto(
    val id: Long,
    val title: String? = null,
    val name: String? = null,
    @Json(name = "overview") val overview: String? = null,
    @Json(name = "poster_path") val posterPath: String? = null,
    @Json(name = "backdrop_path") val backdropPath: String? = null,
    @Json(name = "release_date") val releaseDate: String? = null,
    @Json(name = "first_air_date") val firstAirDate: String? = null,
    @Json(name = "vote_average") val voteAverage: Double? = null,
    @Json(name = "media_type") val mediaType: String? = null,
    @Json(name = "genre_ids") val genreIds: List<Long> = emptyList()
)

interface TmdbApiService {
    @GET("trending/all/week")
    suspend fun getTrending(
        @Query("api_key") apiKey: String
    ): TmdbResponse

    @GET("movie/popular")
    suspend fun getPopularMovies(
        @Query("api_key") apiKey: String
    ): TmdbResponse

    @GET("tv/popular")
    suspend fun getPopularTvShows(
        @Query("api_key") apiKey: String
    ): TmdbResponse

    @GET("movie/top_rated")
    suspend fun getTopRatedMovies(
        @Query("api_key") apiKey: String
    ): TmdbResponse

    @GET("movie/now_playing")
    suspend fun getNowPlayingMovies(
        @Query("api_key") apiKey: String
    ): TmdbResponse

    @GET("tv/top_rated")
    suspend fun getTopRatedTvShows(
        @Query("api_key") apiKey: String
    ): TmdbResponse

    @GET("movie/{movie_id}/videos")
    suspend fun getMovieVideos(
        @Path("movie_id") movieId: Long,
        @Query("api_key") apiKey: String
    ): TmdbVideoResponse

    @GET("movie/{movie_id}/images")
    suspend fun getMovieImages(
        @Path("movie_id") movieId: Long,
        @Query("api_key") apiKey: String
    ): TmdbImagesResponse

    @GET("tv/{tv_id}/images")
    suspend fun getTvImages(
        @Path("tv_id") tvId: Long,
        @Query("api_key") apiKey: String
    ): TmdbImagesResponse

    @GET("tv/{tv_id}/season/{season_number}")
    suspend fun getTvSeason(
        @Path("tv_id") tvId: Long,
        @Path("season_number") seasonNumber: Int,
        @Query("api_key") apiKey: String
    ): TmdbSeasonResponse

    @GET("search/multi")
    suspend fun searchMulti(
        @Query("api_key") apiKey: String,
        @Query("query") query: String,
        @Query("page") page: Int = 1
    ): TmdbResponse

    @GET("genre/movie/list")
    suspend fun getMovieGenres(
        @Query("api_key") apiKey: String
    ): TmdbGenresResponse

    @GET("genre/tv/list")
    suspend fun getTvGenres(
        @Query("api_key") apiKey: String
    ): TmdbGenresResponse

    @GET("discover/movie")
    suspend fun discoverMoviesByGenre(
        @Query("api_key") apiKey: String,
        @Query("with_genres") genreId: Long,
        @Query("page") page: Int = 1
    ): TmdbResponse

    @GET("discover/movie")
    suspend fun discoverMoviesAdvanced(
        @Query("api_key") apiKey: String,
        @Query("with_genres") withGenres: String? = null,
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("vote_average.gte") voteAverageGte: Double? = null,
        @Query("vote_count.gte") voteCountGte: Int? = null,
        @Query("page") page: Int = 1
    ): TmdbResponse

    @GET("discover/tv")
    suspend fun discoverTvByGenre(
        @Query("api_key") apiKey: String,
        @Query("with_genres") genreId: Long,
        @Query("page") page: Int = 1
    ): TmdbResponse

    @GET("discover/tv")
    suspend fun discoverTvAdvanced(
        @Query("api_key") apiKey: String,
        @Query("with_genres") withGenres: String? = null,
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("vote_average.gte") voteAverageGte: Double? = null,
        @Query("vote_count.gte") voteCountGte: Int? = null,
        @Query("page") page: Int = 1
    ): TmdbResponse

    @GET("discover/movie")
    suspend fun discoverKidsMovies(
        @Query("api_key") apiKey: String,
        @Query("with_genres") withGenres: String = "10751,16",
        @Query("certification_country") certificationCountry: String = "US",
        @Query("certification.lte") certificationLte: String = "PG",
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("page") page: Int = 1
    ): TmdbResponse

    @GET("discover/tv")
    suspend fun discoverKidsTv(
        @Query("api_key") apiKey: String,
        @Query("with_genres") withGenres: String = "10762,10751,16",
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("page") page: Int = 1
    ): TmdbResponse

    @GET("tv/{tv_id}")
    suspend fun getTvDetails(
        @Path("tv_id") tvId: Long,
        @Query("api_key") apiKey: String
    ): TmdbTvDetailsDto
}

data class TmdbTvDetailsDto(
    val id: Long,
    val name: String? = null,
    @Json(name = "number_of_seasons") val numberOfSeasons: Int? = 1,
    @Json(name = "number_of_episodes") val numberOfEpisodes: Int? = null,
    val seasons: List<TmdbSeasonInfoDto> = emptyList()
)

data class TmdbSeasonInfoDto(
    val id: Long,
    @Json(name = "season_number") val seasonNumber: Int,
    val name: String? = null,
    @Json(name = "episode_count") val episodeCount: Int? = 0
)

data class TmdbGenresResponse(
    val genres: List<TmdbGenreDto> = emptyList()
)

data class TmdbGenreDto(
    val id: Long,
    val name: String
)

data class TmdbImagesResponse(
    val logos: List<TmdbLogoDto> = emptyList()
)

data class TmdbLogoDto(
    @Json(name = "file_path") val filePath: String,
    @Json(name = "iso_639_1") val iso: String? = null
)

data class TmdbSeasonResponse(
    val episodes: List<TmdbEpisodeDto> = emptyList()
)

data class TmdbEpisodeDto(
    val id: Long,
    val name: String? = null,
    val overview: String? = null,
    @Json(name = "episode_number") val episodeNumber: Int? = null,
    @Json(name = "season_number") val seasonNumber: Int? = null,
    val runtime: Int? = null,
    @Json(name = "still_path") val stillPath: String? = null
)

data class TmdbVideoResponse(
    val results: List<TmdbVideoDto> = emptyList()
)

data class TmdbVideoDto(
    val key: String,
    val site: String,
    val type: String
)

object TmdbClient {
    private const val BASE_URL = "https://api.themoviedb.org/3/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .build()

    val instance: TmdbApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(TmdbApiService::class.java)
    }
}
