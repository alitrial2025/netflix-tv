package com.example

import android.os.Bundle
import android.widget.Toast
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import androidx.tv.material3.Surface
import com.example.ui.screens.SplashScreen
import com.example.ui.NetflixViewModel
import com.example.ui.screens.TvAuthScreen
import com.example.ui.screens.AmbientWallpaperScreen
import com.example.ui.screens.CategoryScreen
import com.example.ui.screens.details.DetailsScreen
import com.example.ui.screens.EditProfileScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.player.PlayerScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ProfileSetupWalkthroughScreen
import com.example.ui.audio.DpadSoundManager
import com.example.ui.theme.NetflixProTheme
import com.example.ui.util.TvMotion
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow

class MainActivity : ComponentActivity() {
    private val _userInteractionTimestamp = MutableStateFlow(System.currentTimeMillis())
    private val _isWallpaperActiveState = MutableStateFlow(false)

    override fun onUserInteraction() {
        super.onUserInteraction()
        _userInteractionTimestamp.value = System.currentTimeMillis()
        com.example.ui.util.HomeStartupGate.onInteraction()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        _userInteractionTimestamp.value = System.currentTimeMillis()
        com.example.ui.util.HomeStartupGate.onInteraction()
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_DPAD_DOWN,
                KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_DPAD_RIGHT -> DpadSoundManager.playNavigation(event.repeatCount)
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_NUMPAD_ENTER,
                KeyEvent.KEYCODE_BACK,
                KeyEvent.KEYCODE_TAB -> {
                    if (event.repeatCount == 0) DpadSoundManager.playConfirm()
                }
            }
        }

        if (_isWallpaperActiveState.value && event.action == KeyEvent.ACTION_DOWN) {
            // Dismiss wallpaper on any TV remote button without triggering click behind
            _isWallpaperActiveState.value = false
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        _userInteractionTimestamp.value = System.currentTimeMillis()
        com.example.ui.util.HomeStartupGate.onInteraction()
        if (_isWallpaperActiveState.value && event.action == MotionEvent.ACTION_DOWN) {
            _isWallpaperActiveState.value = false
            return true
        }
        return super.dispatchTouchEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_SCROLL) {
            _userInteractionTimestamp.value = System.currentTimeMillis()
            com.example.ui.util.HomeStartupGate.onInteraction()
        }
        return super.dispatchGenericMotionEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.example.ui.util.AppDiagnosticsLogger.event("MainActivity", "MainActivity onCreate initialized.")
        lifecycleScope.launch(Dispatchers.IO) { DpadSoundManager.init(applicationContext) }

        // NOTE: The Coil ImageLoader is configured in `NetflixApplication.newImageLoader()`
        // (via the `ImageLoaderFactory` interface). Coil's default `imageLoader` lookup
        // will discover the Application's factory and use that single, authoritative
        // configuration. Previously this onCreate called `Coil.setImageLoader(...)`
        // with a *different* builder (35% memory, 100MB disk, no RGB_565, no User-Agent)
        // that silently shadowed the Application's loader. The two configs drifted, and
        // the MainActivity's loader was the one that actually ran. Removed in the
        // shared-infrastructure audit pass.

        setContent {
            NetflixProTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    colors = androidx.tv.material3.SurfaceDefaults.colors(
                        containerColor = com.example.ui.theme.NetflixBlack
                    )
                ) {
                    val navController = rememberNavController()
                    val viewModel: NetflixViewModel = viewModel()

                    val currentBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = currentBackStackEntry?.destination?.route ?: ""
                    val isPlayerScreen = currentRoute.contains("player", ignoreCase = true)

                    LaunchedEffect(currentRoute) {
                        if (currentRoute.isNotEmpty()) {
                            com.example.ui.util.AppDiagnosticsLogger.event("Navigation", "User navigated to screen: $currentRoute")
                        }
                    }

                    val isWallpaperActive by _isWallpaperActiveState.collectAsState()
                    val isBillboardPlaying by viewModel.isBillboardPlaying.collectAsState()

                    // App-wide Idle Inactivity Monitor:
                    // Automatically triggers Ambient Wallpaper when user is idle for 60s (except during video playback)
                    // The loop reads the latest timestamp directly. Collecting it here
                    // would recompose the entire navigation host on every remote press.
                    LaunchedEffect(isPlayerScreen, isBillboardPlaying) {
                        if (isPlayerScreen) {
                            _isWallpaperActiveState.value = false
                        } else if (!isBillboardPlaying) {
                            val idleTimeoutMs = 60_000L // 60 seconds of inactivity
                            while (true) {
                                val elapsed = System.currentTimeMillis() - _userInteractionTimestamp.value
                                if (elapsed >= idleTimeoutMs && !_isWallpaperActiveState.value) {
                                    _isWallpaperActiveState.value = true
                                }
                                delay(1000L)
                            }
                        } else {
                            _isWallpaperActiveState.value = false
                        }
                    }

                    LaunchedEffect(intent?.data) {
                        val uri = intent?.data
                        if (uri != null) {
                            val uriStr = uri.toString()
                            val path = uri.path ?: ""
                            val host = uri.host ?: ""
                            val codeParam = uri.getQueryParameter("code")

                            // Check if this is a TV session pairing request
                            if (path.contains("pair", ignoreCase = true) || host.contains("pair", ignoreCase = true) || uriStr.contains("pair", ignoreCase = true) || !codeParam.isNullOrBlank()) {
                                val code = codeParam ?: uri.lastPathSegment
                                if (!code.isNullOrBlank() && !code.equals("pair", ignoreCase = true)) {
                                    viewModel.pairTvSession(code) { success ->
                                        if (success) {
                                            Toast.makeText(this@MainActivity, "TV Paired & Unlocked Successfully!", Toast.LENGTH_LONG).show()
                                        } else {
                                            Toast.makeText(this@MainActivity, "Failed to pair TV. Please check code or try again.", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            } else {
                                val movieId = uri.lastPathSegment
                                if (!movieId.isNullOrBlank()) {
                                    if (path.contains("play") || host == "play") {
                                        navController.navigate("player/$movieId")
                                    } else if (path.contains("title") || path.contains("details") || host == "title") {
                                        navController.navigate("details/$movieId")
                                    }
                                }
                            }
                        }
                    }

                    Box(modifier = Modifier.fillMaxSize()) {
                        NavHost(
                            navController = navController,
                            startDestination = "splash"
                        ) {
                            composable(
                                route = "splash",
                                enterTransition = { fadeIn(animationSpec = tween(TvMotion.duration(140), easing = FastOutSlowInEasing)) },
                                exitTransition = { fadeOut(animationSpec = tween(TvMotion.duration(130), easing = FastOutSlowInEasing)) }
                            ) {
                                // Splash holds until the ViewModel's initial data (profiles +
                                // home rows) has loaded, so the transition into the app is
                                // instant — like the real Netflix TV app.
                                val isWarmupFinished by viewModel.isLoading.collectAsState()
                                SplashScreen(
                                    isWarmupFinished = !isWarmupFinished,
                                    onSplashComplete = {
                                        val isLoggedIn = viewModel.isUserLoggedInOrGuest()
                                        val destination = if (isLoggedIn) "profiles" else "tvAuth"
                                        navController.navigate(destination) {
                                            popUpTo("splash") { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable(
                                route = "tvAuth",
                                deepLinks = listOf(
                                    navDeepLink { uriPattern = "https://netflixpro.app/pair?code={code}" },
                                    navDeepLink { uriPattern = "https://www.netflixpro.app/pair?code={code}" },
                                    navDeepLink { uriPattern = "https://netflixpro.app/pair/{code}" },
                                    navDeepLink { uriPattern = "netflixpro://pair?code={code}" },
                                    navDeepLink { uriPattern = "netflixpro://pair/{code}" }
                                ),
                                enterTransition = { fadeIn(animationSpec = tween(TvMotion.duration(250), easing = FastOutSlowInEasing)) },
                                exitTransition = { fadeOut(animationSpec = tween(TvMotion.duration(200), easing = FastOutSlowInEasing)) }
                            ) {
                                TvAuthScreen(
                                    viewModel = viewModel,
                                    onAuthenticated = { email ->
                                        viewModel.ensureProfilesLoaded()
                                        val hasProfiles = viewModel.profiles.value.isNotEmpty()
                                        val destination = if (hasProfiles) "profiles" else "profileSetup"
                                        navController.navigate(destination) {
                                            popUpTo("tvAuth") { inclusive = true }
                                        }
                                    },
                                    onSkipToGuest = {
                                        viewModel.ensureProfilesLoaded()
                                        val hasProfiles = viewModel.profiles.value.isNotEmpty()
                                        val destination = if (hasProfiles) "profiles" else "profileSetup"
                                        navController.navigate(destination) {
                                            popUpTo("tvAuth") { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable(
                                route = "profileSetup",
                                enterTransition = { 
                                    fadeIn(animationSpec = tween(TvMotion.duration(220), easing = FastOutSlowInEasing))
                                },
                                exitTransition = { 
                                    fadeOut(animationSpec = tween(TvMotion.duration(180), easing = FastOutSlowInEasing))
                                }
                            ) {
                                val hasProfiles = viewModel.profiles.value.isNotEmpty()
                                ProfileSetupWalkthroughScreen(
                                    viewModel = viewModel,
                                    onComplete = { profile ->
                                        viewModel.selectProfile(profile)
                                        navController.navigate("home") {
                                            popUpTo("profileSetup") { inclusive = true }
                                            popUpTo("profiles") { inclusive = true }
                                        }
                                    },
                                    onCancel = if (hasProfiles) {
                                        { navController.popBackStack() }
                                    } else null
                                )
                            }

                            composable(
                                route = "profiles",
                                enterTransition = { 
                                    fadeIn(animationSpec = tween(TvMotion.duration(140), easing = LinearOutSlowInEasing))
                                },
                                exitTransition = { 
                                    fadeOut(animationSpec = tween(TvMotion.duration(110), easing = FastOutSlowInEasing))
                                },
                                popEnterTransition = {
                                    fadeIn(animationSpec = tween(TvMotion.duration(140), easing = LinearOutSlowInEasing))
                                },
                                popExitTransition = {
                                    fadeOut(animationSpec = tween(TvMotion.duration(110), easing = FastOutSlowInEasing))
                                }
                            ) {
                                val isLoggedIn = viewModel.isUserLoggedInOrGuest()
                                LaunchedEffect(isLoggedIn) {
                                    if (!isLoggedIn) {
                                        navController.navigate("tvAuth") {
                                            popUpTo("profiles") { inclusive = true }
                                        }
                                    }
                                }
                                if (isLoggedIn) {
                                    ProfileScreen(
                                        viewModel = viewModel,
                                        onProfileSelected = { _ ->
                                            // ProfileLoadingScreen already selected and hydrated this
                                            // profile before its transition. Do not repeat that work here.
                                            navController.navigate("home") {
                                                popUpTo("profiles") { inclusive = true }
                                            }
                                        },
                                        onEditProfile = { profileId ->
                                            navController.navigate("editProfile/$profileId")
                                        }
                                    )
                                }
                            }
                            
                            composable(
                                route = "editProfile/{profileId}",
                                arguments = listOf(navArgument("profileId") { type = NavType.StringType }),
                                enterTransition = { 
                                    slideInHorizontally(
                                        initialOffsetX = { (it * 0.04f).toInt() },
                                        animationSpec = tween(TvMotion.duration(280), easing = FastOutSlowInEasing)
                                    ) + fadeIn(animationSpec = tween(TvMotion.duration(260), easing = FastOutSlowInEasing))
                                },
                                exitTransition = { 
                                    slideOutHorizontally(
                                        targetOffsetX = { -(it * 0.03f).toInt() },
                                        animationSpec = tween(TvMotion.duration(220), easing = FastOutSlowInEasing)
                                    ) + fadeOut(animationSpec = tween(TvMotion.duration(200), easing = FastOutSlowInEasing))
                                },
                                popEnterTransition = {
                                    slideInHorizontally(
                                        initialOffsetX = { -(it * 0.03f).toInt() },
                                        animationSpec = tween(TvMotion.duration(280), easing = FastOutSlowInEasing)
                                    ) + fadeIn(animationSpec = tween(TvMotion.duration(260), easing = FastOutSlowInEasing))
                                },
                                popExitTransition = {
                                    slideOutHorizontally(
                                        targetOffsetX = { (it * 0.04f).toInt() },
                                        animationSpec = tween(TvMotion.duration(220), easing = FastOutSlowInEasing)
                                    ) + fadeOut(animationSpec = tween(TvMotion.duration(200), easing = FastOutSlowInEasing))
                                }
                            ) { backStackEntry ->
                                val profileId = backStackEntry.arguments?.getString("profileId") ?: ""
                                EditProfileScreen(
                                    profileId = profileId,
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(
                                route = "home",
                                deepLinks = listOf(navDeepLink { uriPattern = "netflixpro://home" }),
                                enterTransition = { 
                                    fadeIn(animationSpec = tween(TvMotion.duration(140), easing = LinearOutSlowInEasing))
                                },
                                exitTransition = { 
                                    fadeOut(animationSpec = tween(TvMotion.duration(110), easing = FastOutSlowInEasing))
                                },
                                popEnterTransition = {
                                    fadeIn(animationSpec = tween(TvMotion.duration(140), easing = LinearOutSlowInEasing))
                                },
                                popExitTransition = {
                                    fadeOut(animationSpec = tween(TvMotion.duration(110), easing = FastOutSlowInEasing))
                                }
                            ) {
                                HomeScreen(
                                    viewModel = viewModel,
                                    onPlayMovie = { movie ->
                                        _isWallpaperActiveState.value = false
                                        viewModel.cacheMovie(movie)
                                        val cw = viewModel.continueWatchingList.value.find { it.movieId == movie.id }
                                        val season = cw?.season ?: 1
                                        val episode = cw?.episode ?: 1
                                        val epName = cw?.episodeName ?: ""
                                        navController.navigate("player/${movie.id}?season=$season&episode=$episode&episodeName=${android.net.Uri.encode(epName)}")
                                    },
                                    onMovieClick = { movie ->
                                        viewModel.cacheMovie(movie)
                                        navController.navigate("details/${movie.id}")
                                    },
                                    onCategoryClick = { categoryName ->
                                        navController.navigate("category/$categoryName")
                                    },
                                    onNavigateToProfiles = {
                                        navController.navigate("profiles")
                                    }
                                )
                            }

                            composable(
                                route = "category/{categoryName}",
                                arguments = listOf(navArgument("categoryName") { type = NavType.StringType }),
                                enterTransition = { 
                                    slideInHorizontally(
                                        initialOffsetX = { (it * 0.04f).toInt() },
                                        animationSpec = tween(TvMotion.duration(320), easing = FastOutSlowInEasing)
                                    ) + fadeIn(animationSpec = tween(TvMotion.duration(280), easing = FastOutSlowInEasing))
                                },
                                exitTransition = { 
                                    slideOutHorizontally(
                                        targetOffsetX = { -(it * 0.03f).toInt() },
                                        animationSpec = tween(TvMotion.duration(260), easing = FastOutSlowInEasing)
                                    ) + fadeOut(animationSpec = tween(TvMotion.duration(240), easing = FastOutSlowInEasing))
                                },
                                popEnterTransition = {
                                    slideInHorizontally(
                                        initialOffsetX = { -(it * 0.03f).toInt() },
                                        animationSpec = tween(TvMotion.duration(320), easing = FastOutSlowInEasing)
                                    ) + fadeIn(animationSpec = tween(TvMotion.duration(280), easing = FastOutSlowInEasing))
                                },
                                popExitTransition = {
                                    slideOutHorizontally(
                                        targetOffsetX = { (it * 0.04f).toInt() },
                                        animationSpec = tween(TvMotion.duration(260), easing = FastOutSlowInEasing)
                                    ) + fadeOut(animationSpec = tween(TvMotion.duration(240), easing = FastOutSlowInEasing))
                                }
                            ) { backStackEntry ->
                                val categoryName = backStackEntry.arguments?.getString("categoryName") ?: ""
                                CategoryScreen(
                                    categoryName = categoryName,
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() },
                                    onPlayMovie = { movie ->
                                        _isWallpaperActiveState.value = false
                                        viewModel.cacheMovie(movie)
                                        val cw = viewModel.continueWatchingList.value.find { it.movieId == movie.id }
                                        val season = cw?.season ?: 1
                                        val episode = cw?.episode ?: 1
                                        val epName = cw?.episodeName ?: ""
                                        navController.navigate("player/${movie.id}?season=$season&episode=$episode&episodeName=${android.net.Uri.encode(epName)}")
                                    },
                                    onMovieClick = { movie ->
                                        viewModel.cacheMovie(movie)
                                        navController.navigate("details/${movie.id}")
                                    }
                                )
                            }

                            composable(
                                route = "details/{movieId}",
                                arguments = listOf(navArgument("movieId") { type = NavType.StringType }),
                                deepLinks = listOf(
                                    navDeepLink { uriPattern = "netflixpro://movie/{movieId}" },
                                    navDeepLink { uriPattern = "https://netflixpro.app/movie/{movieId}" }
                                ),
                                enterTransition = { 
                                    slideInHorizontally(
                                        initialOffsetX = { (it * 0.03f).toInt() },
                                        animationSpec = tween(TvMotion.duration(350), easing = FastOutSlowInEasing)
                                    ) + fadeIn(animationSpec = tween(TvMotion.duration(320), easing = FastOutSlowInEasing)) +
                                    scaleIn(initialScale = 0.97f, animationSpec = tween(TvMotion.duration(350), easing = FastOutSlowInEasing))
                                },
                                exitTransition = { 
                                    slideOutHorizontally(
                                        targetOffsetX = { -(it * 0.02f).toInt() },
                                        animationSpec = tween(TvMotion.duration(280), easing = FastOutSlowInEasing)
                                    ) + fadeOut(animationSpec = tween(TvMotion.duration(260), easing = FastOutSlowInEasing)) +
                                    scaleOut(targetScale = 1.02f, animationSpec = tween(TvMotion.duration(280), easing = FastOutSlowInEasing))
                                },
                                popEnterTransition = {
                                    slideInHorizontally(
                                        initialOffsetX = { -(it * 0.03f).toInt() },
                                        animationSpec = tween(TvMotion.duration(350), easing = FastOutSlowInEasing)
                                    ) + fadeIn(animationSpec = tween(TvMotion.duration(320), easing = FastOutSlowInEasing)) +
                                    scaleIn(initialScale = 1.02f, animationSpec = tween(TvMotion.duration(350), easing = FastOutSlowInEasing))
                                },
                                popExitTransition = {
                                    slideOutHorizontally(
                                        targetOffsetX = { (it * 0.03f).toInt() },
                                        animationSpec = tween(TvMotion.duration(280), easing = FastOutSlowInEasing)
                                    ) + fadeOut(animationSpec = tween(TvMotion.duration(260), easing = FastOutSlowInEasing)) +
                                    scaleOut(targetScale = 0.97f, animationSpec = tween(TvMotion.duration(280), easing = FastOutSlowInEasing))
                                }
                            ) { backStackEntry ->
                                val movieId = backStackEntry.arguments?.getString("movieId")
                                val movie = viewModel.getMovieById(movieId) ?: viewModel.currentMovie.collectAsState().value
                                if (movie != null) {
                                    DetailsScreen(
                                        movie = movie,
                                        onBack = { navController.popBackStack() },
                                        onPlayMovie = { m, season, episode, epName ->
                                            _isWallpaperActiveState.value = false
                                            navController.navigate("player/${m.id}?season=$season&episode=$episode&episodeName=${android.net.Uri.encode(epName)}")
                                        },
                                        onNavigateToDetails = { m ->
                                            navController.navigate("details/${m.id}") {
                                                popUpTo("home")
                                            }
                                        },
                                        viewModel = viewModel
                                    )
                                }
                            }
                            composable(
                                route = "player/{movieId}?season={season}&episode={episode}&episodeName={episodeName}",
                                deepLinks = listOf(
                                    navDeepLink { uriPattern = "netflixpro://play/{movieId}?season={season}&episode={episode}&pos={pos}" },
                                    navDeepLink { uriPattern = "netflixpro://play/{movieId}?season={season}&episode={episode}" },
                                    navDeepLink { uriPattern = "netflixpro://play/{movieId}" }
                                ),
                                enterTransition = { 
                                    fadeIn(animationSpec = tween(TvMotion.duration(380), easing = LinearOutSlowInEasing)) +
                                    scaleIn(initialScale = 0.96f, animationSpec = tween(TvMotion.duration(380), easing = FastOutSlowInEasing))
                                },
                                exitTransition = { 
                                    fadeOut(animationSpec = tween(TvMotion.duration(300), easing = FastOutSlowInEasing)) +
                                    scaleOut(targetScale = 1.03f, animationSpec = tween(TvMotion.duration(300), easing = FastOutSlowInEasing))
                                },
                                popEnterTransition = {
                                    fadeIn(animationSpec = tween(TvMotion.duration(350), easing = LinearOutSlowInEasing)) +
                                    scaleIn(initialScale = 1.03f, animationSpec = tween(TvMotion.duration(350), easing = FastOutSlowInEasing))
                                },
                                popExitTransition = {
                                    fadeOut(animationSpec = tween(TvMotion.duration(300), easing = FastOutSlowInEasing)) +
                                    scaleOut(targetScale = 0.96f, animationSpec = tween(TvMotion.duration(300), easing = FastOutSlowInEasing))
                                },
                                arguments = listOf(
                                    navArgument("movieId") { type = NavType.StringType },
                                    navArgument("season") { type = NavType.IntType; defaultValue = 1 },
                                    navArgument("episode") { type = NavType.IntType; defaultValue = 1 },
                                    navArgument("episodeName") { type = NavType.StringType; defaultValue = "" }
                                )
                            ) { backStackEntry ->
                                val movieId = backStackEntry.arguments?.getString("movieId")
                                val season = backStackEntry.arguments?.getInt("season") ?: 1
                                val episode = backStackEntry.arguments?.getInt("episode") ?: 1
                                val episodeName = backStackEntry.arguments?.getString("episodeName") ?: ""
                                val movie = viewModel.getMovieById(movieId) ?: viewModel.currentMovie.collectAsState().value
                                if (movie != null) {
                                    PlayerScreen(
                                        movie = movie,
                                        season = season,
                                        episode = episode,
                                        episodeName = episodeName,
                                        onBack = { navController.popBackStack() },
                                        viewModel = viewModel
                                    )
                                }
                            }
                        }

                        // App-Wide Ambient Wallpaper / Screensaver Overlay
                        AnimatedVisibility(
                            visible = isWallpaperActive && !isPlayerScreen,
                            enter = fadeIn(animationSpec = tween(700, easing = FastOutSlowInEasing)),
                            exit = fadeOut(animationSpec = tween(350, easing = FastOutSlowInEasing))
                        ) {
                            val categoryRows by viewModel.categoryRows.collectAsState()
                            val allMovies = remember(categoryRows) {
                                categoryRows.flatMap { it.second }.distinctBy { it.id }
                            }
                            AmbientWallpaperScreen(
                                movies = allMovies,
                                onDismiss = {
                                    _userInteractionTimestamp.value = System.currentTimeMillis()
                                    com.example.ui.util.HomeStartupGate.onInteraction()
                                    _isWallpaperActiveState.value = false
                                }
                            )
                        }

                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        DpadSoundManager.release()
    }
}
