package com.example.model

import androidx.compose.runtime.Immutable

/**
 * Tier enum — the four billing plans.
 *
 * `priority` is used to sort plans in the upgrade modal: higher = more featured.
 * `priceUsd` is a raw Double so the UI can localize the currency via
 * [java.text.NumberFormat.getCurrencyInstance] instead of a hardcoded "$10.00"
 * String (which previously prevented non-USD locales from rendering correctly).
 */
@Immutable
enum class SubscriptionTier(
    val displayName: String,
    val priceUsd: Double,
    val maxScreens: Int,
    val maxDownloadQuality: String,
    val hasAds: Boolean,
    val hasLiveContent: Boolean,
    val priority: Int
) {
    GUEST(displayName = "Guest", priceUsd = 0.0, maxScreens = 0, maxDownloadQuality = "None",
        hasAds = true, hasLiveContent = false, priority = 0),
    MOBILE(displayName = "Mobile", priceUsd = 2.0, maxScreens = 1, maxDownloadQuality = "SD",
        hasAds = true, hasLiveContent = false, priority = 1),
    BASIC(displayName = "Basic", priceUsd = 6.0, maxScreens = 1, maxDownloadQuality = "HD",
        hasAds = true, hasLiveContent = false, priority = 2),
    STANDARD(displayName = "Standard", priceUsd = 10.0, maxScreens = 2, maxDownloadQuality = "Full HD",
        hasAds = false, hasLiveContent = true, priority = 3),
    PREMIUM(displayName = "Premium", priceUsd = 14.0, maxScreens = 4, maxDownloadQuality = "4K HDR",
        hasAds = false, hasLiveContent = true, priority = 4);

    companion object {
        /** Resolve a planId (e.g. "plan_standard", "plan_premium") to a tier. */
        fun fromPlanId(planId: String?): SubscriptionTier {
            if (planId.isNullOrBlank()) return GUEST
            val normalized = planId.trim().lowercase()
            return when {
                normalized == "plan_guest" || normalized == "guest" -> GUEST
                normalized == "plan_mobile" || normalized == "mobile" -> MOBILE
                normalized == "plan_basic" || normalized == "basic" -> BASIC
                normalized == "plan_standard" || normalized == "standard" -> STANDARD
                normalized == "plan_premium" || normalized == "premium" -> PREMIUM
                else -> GUEST
            }
        }
    }
}

/**
 * Subscription status — the billing-side lifecycle.
 *
 * Per audit §1:
 *   - ACTIVE              → full access
 *   - TRIAL               → full access, time-boxed
 *   - GRACE_PERIOD        → access retained while billing retries
 *   - PAST_DUE            → access revoked, must update payment method
 *   - CANCELLED           → access retained until expiresAt
 *   - EXPIRED             → no access
 *   - PENDING_ACTIVATION  → receipt not yet acknowledged server-side
 *   - SUSPENDED           → access revoked, contact support (e.g. fraud)
 */
@Immutable
enum class SubscriptionStatus {
    ACTIVE,
    TRIAL,
    GRACE_PERIOD,
    PAST_DUE,
    CANCELLED,
    EXPIRED,
    PENDING_ACTIVATION,
    SUSPENDED;

    companion object {
        fun fromString(raw: String?): SubscriptionStatus {
            // Security: an unknown / blank status defaults to
            // PENDING_ACTIVATION rather than ACTIVE. Previously the
            // blanket fallback to ACTIVE meant a backend bug or a
            // malicious Firestore write with `status = "🐛"` would
            // silently grant free access. PENDING means the server has
            // not confirmed the user's plan, so the user sees an
            // upgrade prompt until the server pushes a real status.
            if (raw.isNullOrBlank()) return PENDING_ACTIVATION
            return when (raw.trim().uppercase()) {
                "ACTIVE" -> ACTIVE
                "TRIAL", "FREE_TRIAL" -> TRIAL
                "GRACE_PERIOD", "GRACE" -> GRACE_PERIOD
                "PAST_DUE", "PASTDUE", "PAYMENT_FAILED" -> PAST_DUE
                "CANCELLED", "CANCELED" -> CANCELLED
                "EXPIRED" -> EXPIRED
                "PENDING", "PENDING_ACTIVATION" -> PENDING_ACTIVATION
                "SUSPENDED", "FRAUD" -> SUSPENDED
                else -> PENDING_ACTIVATION
            }
        }
    }
}

/**
 * Payment method — minimal identifier; the actual PAN is on the server.
 *
 * `lastFour` is the only PII we ever store or display client-side; the
 * network tokenization flow keeps the full PAN off-device.
 */
@Immutable
enum class PaymentMethod(val displayName: String) {
    MPESA("M-Pesa"),
    CARD("Credit / Debit Card"),
    PAYPAL("PayPal"),
    PLAY_BILLING("Google Play"),
    UNKNOWN("Unknown");

    companion object {
        fun fromString(raw: String?): PaymentMethod {
            if (raw.isNullOrBlank()) return UNKNOWN
            return when (raw.trim().uppercase()) {
                "MPESA", "M-PESA", "M_PESA" -> MPESA
                "CARD", "VISA", "MASTERCARD", "AMEX" -> CARD
                "PAYPAL" -> PAYPAL
                "PLAY", "GOOGLE_PLAY", "PLAY_BILLING" -> PLAY_BILLING
                else -> UNKNOWN
            }
        }
    }
}

@Immutable
data class SubscriptionPlan(
    val id: String,
    val name: String,
    val priceKes: Int,
    /** Pre-formatted display string (e.g. "$10.00"). Kept for back-compat with
     *  any UI that still shows this verbatim. Prefer [priceUsdRaw] for new
     *  code paths so currency can be localized. */
    val priceUsd: String,
    /** Raw USD amount as a Double — locale-independent. The UI should format
     *  this through [java.text.NumberFormat.getCurrencyInstance] per locale. */
    val priceUsdRaw: Double = priceUsd.replace(Regex("[^0-9.]"), "").toDoubleOrNull() ?: 0.0,
    val quality: String,
    val resolution: String,
    val supportedDevices: String,
    val screens: Int,
    val downloadDevices: Int,
    val spatialAudio: Boolean,
    val isPopular: Boolean = false,
    /** Tier enum — the canonical plan classification. UI can still use
     *  [name] for display. */
    val tier: SubscriptionTier = SubscriptionTier.fromPlanId(id)
)

object SubscriptionPlans {
    val PLANS = listOf(
        SubscriptionPlan(
            id = "plan_mobile",
            name = "Mobile",
            priceKes = 200,
            priceUsd = "$2.00",
            quality = "Good",
            resolution = "480p (SD)",
            supportedDevices = "Mobile phone, tablet",
            screens = 1,
            downloadDevices = 1,
            spatialAudio = false,
            isPopular = false
        ),
        SubscriptionPlan(
            id = "plan_basic",
            name = "Basic",
            priceKes = 600,
            priceUsd = "$6.00",
            quality = "Good",
            resolution = "720p (HD)",
            supportedDevices = "TV, computer, mobile phone, tablet",
            screens = 1,
            downloadDevices = 1,
            spatialAudio = false,
            isPopular = false
        ),
        SubscriptionPlan(
            id = "plan_standard",
            name = "Standard",
            priceKes = 1000,
            priceUsd = "$10.00",
            quality = "Great",
            resolution = "1080p (Full HD)",
            supportedDevices = "TV, computer, mobile phone, tablet",
            screens = 2,
            downloadDevices = 2,
            spatialAudio = false,
            isPopular = true
        ),
        SubscriptionPlan(
            id = "plan_premium",
            name = "Premium",
            priceKes = 1400,
            priceUsd = "$14.00",
            quality = "Best",
            resolution = "4K (Ultra HD) + HDR",
            supportedDevices = "TV, computer, mobile phone, tablet",
            screens = 4,
            downloadDevices = 6,
            spatialAudio = true,
            isPopular = false
        )
    )

    fun getById(id: String): SubscriptionPlan {
        return PLANS.find { it.id == id } ?: PLANS[2]
    }
}

/**
 * The user's current subscription state.
 *
 * `expiresAt` is stored as a UTC epoch-millis Long (NOT LocalDateTime) to
 * avoid the time-zone / DST bugs the audit flagged. Every clock comparison
 * goes through [nowMillis] (a single injection point) so tests can swap a
 * fake clock without rewiring call sites.
 *
 * Backwards-compat: the old constructor (status, planId, planName, expiresAt)
 * still works; the new fields default to safe values (no trial, no grace
 * period, not cancelled, etc.).
 */
@Immutable
data class UserSubscription(
    val status: String = "NONE", // NONE, PENDING, ACTIVE, EXPIRED, GRACE_PERIOD, TRIAL, PAST_DUE, CANCELLED, SUSPENDED
    val planId: String = "plan_guest",
    val planName: String = "Guest",
    val amount: Int = 0,
    val currency: String = "KES",
    val paymentReference: String = "",
    val mpesaReceipt: String = "",
    val subscribedAt: Long = 0L,
    val expiresAt: Long = 0L,
    /** When the user entered their current billing period (UTC epoch ms). */
    val renewsAt: Long? = null,
    /** When the trial ends (UTC epoch ms); null if not on a trial. */
    val trialEndsAt: Long? = null,
    /** When the user first subscribed (UTC epoch ms). */
    val startedAt: Long = 0L,
    /** Last payment method the user used. */
    val paymentMethod: String? = null,
    /** Last time the server confirmed the subscription (UTC epoch ms). */
    val lastVerifiedAt: Long? = null,
    /** Whether the subscription auto-renews. False = user has cancelled. */
    val autoRenew: Boolean = true,
    /** Server-reported cancellation reason (only set when [status] is CANCELLED). */
    val cancellationReason: String? = null,
    /** End of the grace period (UTC epoch ms); null if not in grace period. */
    val gracePeriodEndsAt: Long? = null
) {
    val isGuest: Boolean
        get() = planId.equals("plan_guest", ignoreCase = true) ||
                status.equals("NONE", ignoreCase = true) ||
                tier == SubscriptionTier.GUEST

    /**
     * `true` when the user is entitled to stream full content.
     *
     * Audit fix: previously this returned `true` when status was blank,
     * which is a security/revenue hole (a backend bug could silently
     * grant free access). It also dropped GRACE_PERIOD, TRIAL, and
     * CANCELLED-but-not-yet-expired users — all of whom legitimately
     * retain access for some window. The new logic explicitly enumerates
     * the states that grant access, so an unknown status defaults to
     * LOCKED rather than LOCKED-OR-FREE.
     */
    val isActive: Boolean
        get() {
            if (isGuest) return false
            val now = nowMillis()
            val resolved = SubscriptionStatus.fromString(status)
            return when (resolved) {
                SubscriptionStatus.ACTIVE -> true
                SubscriptionStatus.PENDING_ACTIVATION -> {
                    // Security: only grant access if the server has
                    // actually verified this subscription at least once.
                    // A blank status that resolved to PENDING_ACTIVATION
                    // (e.g. a malicious Firestore write) has no
                    // [lastVerifiedAt] and is therefore locked.
                    lastVerifiedAt != null && lastVerifiedAt > 0L
                }
                SubscriptionStatus.TRIAL -> trialEndsAt == null || trialEndsAt > now
                SubscriptionStatus.GRACE_PERIOD ->
                    gracePeriodEndsAt == null || gracePeriodEndsAt > now
                SubscriptionStatus.CANCELLED ->
                    expiresAt > 0L && expiresAt > now
                SubscriptionStatus.PAST_DUE,
                SubscriptionStatus.EXPIRED,
                SubscriptionStatus.SUSPENDED -> false
            }
        }

    /** True while the subscription is in a billing-retry window — user
     *  still has access but a banner should be shown ("Please update
     *  your payment method"). */
    val isInGracePeriod: Boolean
        get() {
            val resolved = SubscriptionStatus.fromString(status)
            if (resolved != SubscriptionStatus.GRACE_PERIOD) return false
            val now = nowMillis()
            return gracePeriodEndsAt == null || gracePeriodEndsAt > now
        }

    /** True while the user is on a free trial. */
    val isInTrial: Boolean
        get() {
            val resolved = SubscriptionStatus.fromString(status)
            if (resolved != SubscriptionStatus.TRIAL) return false
            val now = nowMillis()
            return trialEndsAt == null || trialEndsAt > now
        }

    /** True when the user's payment failed and access is now revoked. */
    val isPastDue: Boolean
        get() = SubscriptionStatus.fromString(status) == SubscriptionStatus.PAST_DUE

    /** True when the user has cancelled but the period isn't over yet. */
    val isCancelledButNotExpired: Boolean
        get() {
            val resolved = SubscriptionStatus.fromString(status)
            if (resolved != SubscriptionStatus.CANCELLED) return false
            val now = nowMillis()
            return expiresAt > 0L && expiresAt > now
        }

    /** Canonical plan tier — single source of truth for gating logic. */
    val tier: SubscriptionTier
        get() = SubscriptionTier.fromPlanId(planId)

    val isTvAllowed: Boolean
        get() = !isGuest && tier != SubscriptionTier.MOBILE

    val maxProfiles: Int
        get() = when (tier) {
            SubscriptionTier.GUEST -> 1
            SubscriptionTier.MOBILE -> 1
            SubscriptionTier.BASIC -> 2
            SubscriptionTier.STANDARD -> 3
            SubscriptionTier.PREMIUM -> 5
        }

    val maxDownloads: Int
        get() = when (tier) {
            SubscriptionTier.GUEST -> 0
            SubscriptionTier.MOBILE -> 0
            SubscriptionTier.BASIC -> 5
            SubscriptionTier.STANDARD -> 25
            SubscriptionTier.PREMIUM -> 999
        }

    /**
     * Days until the current period ends.
     *
     * Audit fix: the previous implementation divided by `86_400_000` (24h)
     * but the result is `Long.toInt()`-truncated, so any remaining time
     * less than a full 24h would round to 0 — then `coerceAtLeast(1)`
     * would mask the bug by silently claiming "1 day remaining" when
     * the truth was "0.5 hours remaining". Now we use ceiling division
     * so 1ms-remaining still returns 1 day, but the value reflects the
     * true remaining time when it's a full day or more.
     */
    val daysRemaining: Int
        get() {
            val now = nowMillis()
            if (expiresAt <= now) return 0
            val remainingMs = expiresAt - now
            val days = remainingMs / (1000L * 60 * 60 * 24L)
            val remainderHours = (remainingMs % (1000L * 60 * 60 * 24L)) > 0L
            return (days + if (remainderHours) 1L else 0L).toInt().coerceAtLeast(0)
        }

    /**
     * Guest = full movie/series streaming locked (plays trailer preview only).
     * Inactive/Expired = locked.
     * Mobile Plan = TV streaming locked; locks 4K UHD, trending VIP blockbusters & newest series.
     * Basic Plan = 720p HD; locks 4K Ultra HD exclusives & VIP premier releases.
     * Standard/Premium = All content unlocked.
     *
     * Audit fix: the default `isTvDevice = true` was inconsistent with the
     * call site in NetflixViewModel (which passed `false`). A true default
     * means any code path that calls this without the param locks mobile
     * plan content on phones/tablets too. We default to `false` to match
     * the call site, and recommend the explicit overload for any new code.
     */
    fun isMovieLocked(
        movieId: String,
        releaseYear: String = "",
        isTrendingOrVip: Boolean = false,
        isTvDevice: Boolean = false
    ): Boolean {
        if (isGuest) return true // Guest: lock full movie, route to trailer
        if (!isActive) return true // Expired / No active subscription

        val normalizedPlan = planId.lowercase()
        val normalizedName = planName.lowercase()
        val yearInt = releaseYear.take(4).toIntOrNull() ?: 0

        // Mobile plan:
        // On TV devices: Mobile plan does not permit TV playback.
        // Also locks 4K HDR VIP/trending blockbusters and newest series
        if (normalizedPlan == "plan_mobile" || normalizedPlan == "mobile" || normalizedName.contains("mobile")) {
            if (isTvDevice) return true
            if (isTrendingOrVip || yearInt >= 2024) return true
        }

        // Basic plan:
        // Basic plan is 720p HD. Locks VIP flagship premieres / 4K UHD exclusive releases / 2025+ top blockbusters
        if (normalizedPlan == "plan_basic" || normalizedPlan == "basic" || normalizedName.contains("basic")) {
            if (isTrendingOrVip || yearInt >= 2025) return true
        }

        return false
    }

    fun getLockReason(
        releaseYear: String = "",
        isTrendingOrVip: Boolean = false,
        isTvDevice: Boolean = false
    ): String {
        if (isGuest) return "Guest Mode: Watch Official Trailer or Sign In to stream full title."
        if (isInGracePeriod) return "Please update your payment method to keep streaming."
        if (isPastDue) return "Your last payment failed. Please update your payment method to resume streaming."
        if (isCancelledButNotExpired) {
            val days = daysRemaining
            return "Your subscription ends in $days day(s). Renew to keep streaming."
        }
        if (!isActive) return "Subscription Expired: Please renew to continue streaming."
        val normalizedPlan = planId.lowercase()
        val normalizedName = planName.lowercase()

        if (normalizedPlan == "plan_mobile" || normalizedPlan == "mobile" || normalizedName.contains("mobile")) {
            return "Locked on Mobile Plan. Upgrade to Standard or Premium to stream this title in Full HD / 4K."
        }
        if (normalizedPlan == "plan_basic" || normalizedPlan == "basic" || normalizedName.contains("basic")) {
            return "4K Ultra HD Exclusive: This title requires Standard or Premium plan."
        }
        return "Upgrade plan to unlock this title."
    }

    companion object {
        /**
         * Clock injection point. The ViewModel sets this once at construction;
         * production uses `System.currentTimeMillis()` and tests inject a fake.
         * Default is the production clock.
         */
        @Volatile
        var clock: () -> Long = { System.currentTimeMillis() }

        internal fun nowMillis(): Long = clock()
    }
}
