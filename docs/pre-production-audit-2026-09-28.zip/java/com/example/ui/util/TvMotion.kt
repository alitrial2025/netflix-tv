package com.example.ui.util

import kotlin.math.roundToInt

/** A little more travel time, with input still handled on the very first frame. */
object TvMotion {
    private const val DurationScale = 1.3f

    fun duration(baseMillis: Int): Int = (baseMillis * DurationScale).roundToInt()

    // Spring duration follows 1 / sqrt(stiffness). Scaling stiffness this way
    // lengthens the glide while retaining velocity when the remote is held down.
    fun stiffness(baseStiffness: Float): Float = baseStiffness / (DurationScale * DurationScale)
}
