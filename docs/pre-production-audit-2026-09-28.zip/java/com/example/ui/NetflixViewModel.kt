package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DirectCDNResolver
import com.example.data.TmdbRepository
import com.example.model.Movie
import com.example.model.Profile
import com.example.data.NetflixDatabase
import com.example.data.ContinueWatchingRepository
import com.example.data.ContinueWatchingEntity
import com.example.data.PendingWriteDao
import com.example.sync.SyncScheduler
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlin.coroutines.resume
import com.example.model.isKidSafeMovie
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import androidx.compose.ui.graphics.Color
import com.example.ui.components.ProfileIcons
import org.json.JSONArray
import org.json.JSONObject
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.FieldValue
import com.example.sync.ConflictPolicy
import com.example.sync.ConflictResolver
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest

/**
 * Firestore collection names used by the sync policy. Centralising the
 * literals here means [ConflictResolver.policyFor] and the call sites
 * agree on the same string — a typo would be a silent policy miss.
 */
private object Collections {
    const val PROFILES = "profiles"
    const val CONTINUE_WATCHING = "continueWatching"
    const val CONTINUE_WATCHING_FLAT = "continue_watching"
    const val MY_LIST = "myList"
    const val SUBSCRIPTION = "subscription"
    const val TV_SESSIONS = "tvSessions"
    const val ACTIVE_STREAMS = "active_streams"
}

class NetflixViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = TmdbRepository()
    private val directCDNResolver by lazy { DirectCDNResolver(application) }

    private val database = NetflixDatabase.getDatabase(application)
    private val continueWatchingRepository = ContinueWatchingRepository(database.continueWatchingDao())
    private val pendingWriteDao: PendingWriteDao = database.pendingWriteDao()

    private val prefs = application.getSharedPreferences("netflix_prefs", android.content.Context.MODE_PRIVATE)

    companion object {
        // Salt used for the per-profile PIN hash. The salt is *not* a secret —
        // its job is to make a precomputed rainbow table on the device useless
        // when the JSON blob is exfiltrated. (A 4-digit PIN space is tiny; a
        // salt pushes the attacker back to brute force per profile.)
        private const val PIN_SALT: String = "netflix-pro-tv-2024"

        /**
         * Hash a 4-digit PIN to a 64-char SHA-256 hex digest. Returned as a
         * lowercase hex string so the value can be safely persisted to
         * SharedPreferences / Firestore. `null` and blank inputs return
         * `null` so the call site can use the result directly.
         *
         * Audit fix: previously the PIN was stored as plaintext in
         * SharedPreferences JSON and synced to Firestore in plaintext. Anyone
         * with `adb backup` access or a compromised Firestore rule could
         * read every profile's PIN.
         */
        fun hashPin(pin: String?): String? {
            if (pin.isNullOrBlank()) return null
            val digest = MessageDigest.getInstance("SHA-256")
            val salted = (PIN_SALT + pin).toByteArray(Charsets.UTF_8)
            val bytes = digest.digest(salted)
            return bytes.joinToString("") { "%02x".format(it) }
        }
    }

    val sharedExoPlayer: androidx.media3.exoplayer.ExoPlayer by lazy {
        val renderersFactory = androidx.media3.exoplayer.DefaultRenderersFactory(application).apply {
            setExtensionRendererMode(androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            setEnableDecoderFallback(true)
        }
        val audioAttributes = androidx.media3.common.AudioAttributes.Builder()
            .setUsage(androidx.media3.common.C.USAGE_MEDIA)
            .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        androidx.media3.exoplayer.ExoPlayer.Builder(application, renderersFactory).build().apply {
            setAudioAttributes(audioAttributes, true)
            playWhenReady = true
            repeatMode = androidx.media3.common.Player.REPEAT_MODE_OFF
        }
    }

    private var activePlayer: androidx.media3.exoplayer.ExoPlayer? = null
    fun registerActivePlayer(player: androidx.media3.exoplayer.ExoPlayer?) {
        // perf: release the previous player before swapping so a replaced Billboard
        // (e.g. tab switch) doesn't leak its ExoPlayer instance.
        val previous = activePlayer
        if (previous != null && previous !== player) {
            try { previous.release() } catch (_: Exception) {}
        }
        activePlayer = player
    }

    override fun onCleared() {
        super.onCleared()
        // perf: release active player too — the activePlayer may differ from sharedExoPlayer
        // when a tab opened a per-billboard player. Without this, that instance leaks
        // until process death.
        try { activePlayer?.release() } catch (_: Exception) {}
        activePlayer = null
        sharedExoPlayer.release()
        // Detach every Firestore listener so the SDK doesn't hold a strong ref
        // to the ViewModel after the user navigates away (memory leak) and so a
        // backgrounded app stops receiving snapshot callbacks (battery / quota).
        try { firestoreProfileListener?.remove() } catch (_: Exception) {}
        try { continueWatchingFirestoreListener?.remove() } catch (_: Exception) {}
        try { continueWatchingNestedListener?.remove() } catch (_: Exception) {}
        try { firestoreSubscriptionListener?.remove() } catch (_: Exception) {}
        try { remoteCommandListener?.remove() } catch (_: Exception) {}
        streamHeartbeatJob?.cancel()
    }

    private val _selectedProfile = MutableStateFlow<Profile?>(null)
    val selectedProfile: StateFlow<Profile?> = _selectedProfile.asStateFlow()

    private val _selectedSubtitleLanguage = MutableStateFlow(
        prefs.getString("selected_subtitle_language", "English") ?: "English"
    )
    val selectedSubtitleLanguage: StateFlow<String> = _selectedSubtitleLanguage.asStateFlow()

    fun setSelectedSubtitleLanguage(language: String) {
        _selectedSubtitleLanguage.value = language
        prefs.edit().putString("selected_subtitle_language", language).apply()
        val currentProfileId = _selectedProfile.value?.id
        if (!currentProfileId.isNullOrEmpty()) {
            prefs.edit().putString("subtitle_language_profile_$currentProfileId", language).apply()
        }
    }

    private val _myListMovieIds = MutableStateFlow<Set<String>>(emptySet())
    val myListMovieIds: StateFlow<Set<String>> = _myListMovieIds.asStateFlow()

    /**
     * One-time My List events. UI uses this to show a transient toast /
     * snackbar ("Added to My List") without re-firing on recomposition
     * (a `StateFlow` would re-emit on every collector restart).
     */
    private val _myListEvents = Channel<MyListEvent>(capacity = Channel.BUFFERED)
    val myListEvents = _myListEvents.receiveAsFlow()

    sealed class MyListEvent {
        data class Added(val movieId: String) : MyListEvent()
        data class Removed(val movieId: String) : MyListEvent()
    }

    /**
     * Cap for the My List per account. 500 is the documented Netflix limit;
     * the server should also enforce this, but the client-side check stops
     * a malicious / buggy caller from stuffing the local cache.
     */
    private val myListCap: Int = 500

    /**
     * Idempotently add a movie to My List. No-op when the movie is already
     * in the list. The [MyListEvent.Added] event fires only on a real
     * transition so the UI doesn't flash "Added!" on a re-tap.
     */
    fun addToMyList(movieId: String) {
        val current = _myListMovieIds.value
        if (current.contains(movieId)) return
        if (current.size >= myListCap) {
            android.util.Log.w("NetflixViewModel", "My List at cap ($myListCap); ignoring add for $movieId")
            return
        }
        val now = System.currentTimeMillis()
        val updated = current + movieId
        // bugfix: previously _myListAddedAt wasn't updated on add, so the
        // sortByMyListMembership() helper would have all-0L timestamps and
        // preserve catalog order instead of "most recently added first".
        val addedAt = _myListAddedAt.value.toMutableMap().apply { put(movieId, now) }
        // Enforce the bounded cache: drop the oldest entries by addedAt if
        // we somehow exceeded the cap (e.g. a legacy prefs file with > 500).
        val boundedAddedAt = if (addedAt.size > myListCap) {
            addedAt.entries.sortedByDescending { it.value }.take(myListCap).associate { it.key to it.value }
        } else addedAt
        val boundedIds = boundedAddedAt.keys
        _myListMovieIds.value = boundedIds
        _myListAddedAt.value = boundedAddedAt
        persistMyList(boundedIds)
        persistMyListAddedAt(_selectedProfile.value?.id ?: "default", boundedAddedAt)
        _myListEvents.trySend(MyListEvent.Added(movieId))
    }

    /**
     * Idempotently remove a movie from My List. No-op when the movie is not
     * in the list. The [MyListEvent.Removed] event fires only on a real
     * transition.
     */
    fun removeFromMyList(movieId: String) {
        val current = _myListMovieIds.value
        if (!current.contains(movieId)) return
        val updated = current - movieId
        // bugfix: keep _myListAddedAt in lock-step with _myListMovieIds so
        // a removed id doesn't linger in the timestamp map and skew future
        // reconcile / sort decisions.
        val addedAt = _myListAddedAt.value.toMutableMap().apply { remove(movieId) }
        _myListMovieIds.value = updated
        _myListAddedAt.value = addedAt
        persistMyList(updated)
        persistMyListAddedAt(_selectedProfile.value?.id ?: "default", addedAt)
        _myListEvents.trySend(MyListEvent.Removed(movieId))
    }

    /**
     * Toggle a movie in/out of My List. Kept for callers that already use it
     * (e.g. the DetailsScreen bookmark button). Internally dispatches to
     * [addToMyList] / [removeFromMyList] so the idempotency / cap / event
     * semantics stay consistent.
     */
    fun toggleMyList(movieId: String) {
        if (_myListMovieIds.value.contains(movieId)) {
            removeFromMyList(movieId)
        } else {
            addToMyList(movieId)
        }
    }

    fun isMovieInMyList(movieId: String): Boolean {
        return _myListMovieIds.value.contains(movieId)
    }

    private fun persistMyList(set: Set<String>) {
        // Audit fix: per Netflix convention, My List is shared across
        // profiles on the same account. The previous code wrote the set
        // under a per-profile key, which meant the user had to re-add the
        // same titles on each profile. We now write one account-shared key.
        // (Per-profile lists remain an opt-in we can add later behind a
        // settings flag — out of scope for this pass.)
        try {
            val key = "my_list_movie_ids_account"
            prefs.edit().putStringSet(key, set).apply()
        } catch (e: Exception) {
            android.util.Log.e("NetflixViewModel", "persistMyList failed", e)
        }
    }

    private fun loadMyList(): Set<String> {
        // Read the account-shared list first (new layout). Fall back to the
        // per-profile key so an install that wrote the old layout still
        // shows the user's titles. Migration: if the per-profile key has
        // data and the account key is empty, copy + delete the per-profile
        // entry so we converge on the new layout.
        val accountKey = "my_list_movie_ids_account"
        val accountList = prefs.getStringSet(accountKey, emptySet()) ?: emptySet()
        if (accountList.isNotEmpty()) return accountList
        val currentProfileId = _selectedProfile.value?.id ?: "default"
        val legacyKey = "my_list_movie_ids_profile_$currentProfileId"
        val legacyList = prefs.getStringSet(legacyKey, emptySet()) ?: emptySet()
        if (legacyList.isNotEmpty()) {
            prefs.edit().putStringSet(accountKey, legacyList).remove(legacyKey).apply()
        }
        return legacyList
    }

    // Per audit §3 / §6 / §9: per-movie addedAt (epoch ms) so the row can
    // be sorted "most recently added first" and a sync can apply
    // last-write-wins deterministically. Stored as a small JSON blob keyed on
    // the profile so the existing StringSet-based sync path doesn't need to
    // be re-keyed.
    private val _myListAddedAt = MutableStateFlow<Map<String, Long>>(emptyMap())
    val myListAddedAt: StateFlow<Map<String, Long>> = _myListAddedAt.asStateFlow()

    // Per audit §6: offline / sync state. A small enum so the UI can show
    // "syncing" / "sync failed" indicators without coupling to a specific
    // network impl.
    enum class MyListSyncStatus { Idle, Syncing, Failed }
    private val _myListSyncStatus = MutableStateFlow(MyListSyncStatus.Idle)
    val myListSyncStatus: StateFlow<MyListSyncStatus> = _myListSyncStatus.asStateFlow()

    // Offline-first outbox status. Exposed to the UI for the "5 pending, 1
    // failed" badge in the top-right of the home screen. Re-emits whenever
    // the pending_writes table changes (insert, markDone, markFailed, prune).
    val pendingWritesStatusCounts: StateFlow<List<PendingWriteDao.StatusCount>> =
        pendingWriteDao.observeStatusCounts()
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

    private fun persistMyListAddedAt(profileId: String, map: Map<String, Long>) {
        try {
            val arr = org.json.JSONArray()
            map.forEach { (id, ts) ->
                val obj = org.json.JSONObject()
                obj.put("id", id)
                obj.put("ts", ts)
                arr.put(obj)
            }
            prefs.edit().putString("my_list_added_at_profile_$profileId", arr.toString()).apply()
        } catch (_: Exception) {
            // perf: never let prefs I/O break the UI thread; the cache in
            // _myListAddedAt is the source of truth for this session.
        }
    }

    private fun loadMyListAddedAt(profileId: String): Map<String, Long> {
        val raw = prefs.getString("my_list_added_at_profile_$profileId", null) ?: return emptyMap()
        return try {
            val arr = org.json.JSONArray(raw)
            val out = mutableMapOf<String, Long>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                out[obj.getString("id")] = obj.getLong("ts")
            }
            out
        } catch (_: Exception) {
            emptyMap()
        }
    }

    // Per audit §3: sort a movie list by `addedAt` descending. Items not in
    // My List sink to the bottom (and within "not in list", preserve input
    // order so the row doesn't visually shuffle when the user toggles an item).
    fun sortByMyListMembership(
        movies: List<com.example.model.Movie>,
        ids: Set<String> = _myListMovieIds.value,
        addedAt: Map<String, Long> = _myListAddedAt.value
    ): List<com.example.model.Movie> {
        if (ids.isEmpty()) return movies
        val (inList, notInList) = movies.partition { it.id in ids }
        val sortedInList = inList.sortedByDescending { addedAt[it.id] ?: 0L }
        return sortedInList + notInList
    }

    // Per audit §6: last-write-wins reconcile. Call this when a remote source
    // (Firestore, another device) reports a new authoritative list. Items in
    // [remote] replace local state; the local `addedAt` is preserved for
    // items that exist in both, else seeded from [remoteTimestampById].
    fun reconcileMyListFromRemote(
        remote: Set<String>,
        remoteTimestampById: Map<String, Long> = emptyMap()
    ) {
        val currentProfileId = _selectedProfile.value?.id ?: "default"
        val now = System.currentTimeMillis()
        val localAddedAt = _myListAddedAt.value
        val merged = remote.associateWith { id ->
            val localTs = localAddedAt[id] ?: 0L
            val remoteTs = remoteTimestampById[id] ?: 0L
            // Last-write-wins: take the larger timestamp; if both 0L (unknown),
            // fall back to "now" so the row sorts to the top.
            maxOf(localTs, remoteTs).takeIf { it > 0L } ?: now
        }
        // Enforce the bounded cache.
        val bounded = if (merged.size > myListCap) {
            merged.entries.sortedByDescending { it.value }.take(myListCap).associate { it.key to it.value }
        } else merged

        _myListMovieIds.value = bounded.keys
        _myListAddedAt.value = bounded
        persistMyList(bounded.keys)
        persistMyListAddedAt(currentProfileId, bounded)
        _myListSyncStatus.value = MyListSyncStatus.Idle
    }

    private val _likedMovieIds = MutableStateFlow<Set<String>>(emptySet())
    val likedMovieIds: StateFlow<Set<String>> = _likedMovieIds.asStateFlow()

    fun toggleLike(movieId: String) {
        val currentProfileId = _selectedProfile.value?.id ?: "default"
        val current = _likedMovieIds.value.toMutableSet()
        if (current.contains(movieId)) {
            current.remove(movieId)
        } else {
            current.add(movieId)
        }
        _likedMovieIds.value = current
        prefs.edit().putStringSet("liked_movie_ids_profile_$currentProfileId", current).apply()
    }

    fun isMovieLiked(movieId: String): Boolean {
        return _likedMovieIds.value.contains(movieId)
    }

    private val _remindedMovieIds = MutableStateFlow<Set<String>>(emptySet())
    val remindedMovieIds: StateFlow<Set<String>> = _remindedMovieIds.asStateFlow()

    fun toggleReminder(movieId: String) {
        val currentProfileId = _selectedProfile.value?.id ?: "default"
        val current = _remindedMovieIds.value.toMutableSet()
        if (current.contains(movieId)) {
            current.remove(movieId)
        } else {
            current.add(movieId)
        }
        _remindedMovieIds.value = current
        prefs.edit().putStringSet("reminded_movie_ids_profile_$currentProfileId", current).apply()
    }

    fun isMovieReminded(movieId: String): Boolean {
        return _remindedMovieIds.value.contains(movieId)
    }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val continueWatchingList: StateFlow<List<ContinueWatchingEntity>> = _selectedProfile
        .flatMapLatest { profile ->
            val profileId = profile?.id ?: ""
            if (profileId.isEmpty()) {
                flowOf(emptyList())
            } else {
                continueWatchingRepository.getContinueWatchingList(profileId)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // perf: initialize empty so SharedPreferences JSON parsing doesn't block ViewModel
    // construction. Profiles are loaded lazily on the IO dispatcher in init { }.
    private val _profiles = MutableStateFlow<List<Profile>>(emptyList())
    val profiles: StateFlow<List<Profile>> = _profiles.asStateFlow()

    private fun loadStoredProfiles(): List<Profile> {
        val jsonStr = prefs.getString("saved_profiles_json", null)
        if (!jsonStr.isNullOrBlank()) {
            try {
                val jsonArray = JSONArray(jsonStr)
                val list = mutableListOf<Profile>()
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val favoriteGenresList = mutableListOf<String>()
                    if (obj.has("favoriteGenres")) {
                        val arr = obj.getJSONArray("favoriteGenres")
                        for (j in 0 until arr.length()) {
                            favoriteGenresList.add(arr.getString(j))
                        }
                    }
                    list.add(
                        Profile(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            avatarColor = Color(obj.optLong("avatarColor", 0xFFE50914)),
                            isKid = obj.optBoolean("isKid", false),
                            avatarUrl = if (obj.has("avatarUrl") && !obj.isNull("avatarUrl")) obj.getString("avatarUrl") else null,
                            pin = if (obj.has("pin") && !obj.isNull("pin")) obj.getString("pin") else null,
                            language = obj.optString("language", "English"),
                            autoplayNext = obj.optBoolean("autoplayNext", true),
                            autoplayPreviews = obj.optBoolean("autoplayPreviews", true),
                            maturityRating = obj.optString("maturityRating", "18+"),
                            favoriteGenres = favoriteGenresList,
                            gameHandle = if (obj.has("gameHandle") && !obj.isNull("gameHandle")) obj.getString("gameHandle") else null,
                            createdAt = obj.optLong("createdAt", 0L),
                            lastUsedAt = obj.optLong("lastUsedAt", 0L)
                        )
                    )
                }
                val legacyFallbackNames = setOf("Derrick", "Karan", "Mom", "Home", "Kids")
                val legacyIds = setOf("1", "2", "3", "4", "5")
                val filteredList = list.filterNot { it.id in legacyIds && it.name in legacyFallbackNames }
                if (filteredList.size != list.size) {
                    saveStoredProfiles(filteredList)
                }
                return filteredList
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return emptyList()
    }

    private fun saveStoredProfiles(profilesList: List<Profile>) {
        try {
            val jsonArray = JSONArray()
            for (p in profilesList) {
                val obj = JSONObject()
                obj.put("id", p.id)
                obj.put("name", p.name)
                obj.put("avatarColor", p.avatarColor.value.toLong())
                obj.put("isKid", p.isKid)
                obj.put("avatarUrl", p.avatarUrl)
                obj.put("pin", p.pin)
                obj.put("language", p.language)
                obj.put("autoplayNext", p.autoplayNext)
                obj.put("autoplayPreviews", p.autoplayPreviews)
                obj.put("maturityRating", p.maturityRating)
                obj.put("gameHandle", p.gameHandle)
                obj.put("createdAt", p.createdAt)
                obj.put("lastUsedAt", p.lastUsedAt)
                val genresArr = JSONArray()
                p.favoriteGenres.forEach { genresArr.put(it) }
                obj.put("favoriteGenres", genresArr)
                jsonArray.put(obj)
            }
            prefs.edit().putString("saved_profiles_json", jsonArray.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private var firestoreProfileListener: ListenerRegistration? = null
    private var continueWatchingFirestoreListener: ListenerRegistration? = null
    private var continueWatchingNestedListener: ListenerRegistration? = null
    // Track the subscription Firestore listener so we can remove it on sign-out
    // and re-attach it under a new uid. Previously each call added a new
    // listener without removing the old one — a memory leak that also meant
    // a signed-out user's plan could still update the new user's
    // _userSubscription (cross-account privacy leak).
    private var firestoreSubscriptionListener: ListenerRegistration? = null
    // perf: serialize upgrade taps so a double-tap on "Upgrade & Stream Now"
    // doesn't fire two parallel setPairedUser() / Firestore writes (which
    // previously could end up writing inconsistent state to prefs and the
    // server). The existing signInMutex covers the sign-in path; upgrades
    // need their own.
    private val upgradeMutex = kotlinx.coroutines.sync.Mutex()
    private var activeUpgradeJob: kotlinx.coroutines.Job? = null

    // Debounce the continue-watching listener so a rapid burst of Firestore
    // writes (e.g. a profile switch that fires multiple snapshots in <100ms)
    // doesn't trigger N concurrent Room writes. The collector cancels the
    // previous pending job and only the last snapshot's writes are applied.
    private var continueWatchingDebounceJob: kotlinx.coroutines.Job? = null

    fun listenToContinueWatchingFromFirestore(profileIdOverride: String? = null) {
        try {
            if (FirebaseApp.getApps(getApplication()).isNotEmpty()) {
                val db = FirebaseFirestore.getInstance()
                val currentUser = FirebaseAuth.getInstance().currentUser
                val savedUid = prefs.getString("paired_user_id", null)
                val targetUid = currentUser?.uid ?: savedUid
                if (targetUid.isNullOrBlank() || targetUid == "guest" || (currentUser == null && targetUid == "user_netflix_pro_primary")) {
                    return
                }
                val profileId = profileIdOverride ?: _selectedProfile.value?.id ?: "default"

                continueWatchingFirestoreListener?.remove()
                continueWatchingNestedListener?.remove()

                fun handleSnapshot(snapshot: com.google.firebase.firestore.QuerySnapshot?) {
                    if (snapshot == null) return
                    // Debounce: only the last snapshot in a 150ms window is
                    // processed. This protects Room from a write storm when
                    // the listener fires repeatedly during sign-in / profile
                    // selection. Also routes the writes through Dispatchers.IO
                    // — the previous `viewModelScope.launch { ... }` ran on
                    // Main, blocking the UI thread for the duration of N Room
                    // writes on a slow TV flash.
                    continueWatchingDebounceJob?.cancel()
                    continueWatchingDebounceJob = viewModelScope.launch(Dispatchers.IO) {
                        kotlinx.coroutines.delay(150L)
                        for (change in snapshot.documentChanges) {
                            val doc = change.document
                            val mediaId = doc.getString("mediaId") ?: doc.getString("movieId") ?: doc.getString("id") ?: doc.id.substringAfterLast("_")
                            if (mediaId.isBlank()) continue

                            if (change.type == com.google.firebase.firestore.DocumentChange.Type.REMOVED) {
                                continueWatchingRepository.deleteProgress(profileId, mediaId)
                                continue
                            }

                            try {
                                val isCompleted = doc.getBoolean("isCompleted") ?: false
                                val posSec = (doc.getLong("positionSeconds") ?: 0L)
                                val posMs = doc.getLong("playbackPositionMs") ?: doc.getLong("positionMs") ?: (posSec * 1000L)
                                val durSec = (doc.getLong("totalSeconds") ?: doc.getLong("durationSeconds") ?: 0L)
                                val durMs = doc.getLong("durationMs") ?: (durSec * 1000L)
                                val season = (doc.getLong("season") ?: 1L).toInt()
                                val episode = (doc.getLong("episode") ?: 1L).toInt()
                                val episodeName = doc.getString("episodeTitle") ?: doc.getString("episodeName") ?: ""

                                if (isCompleted || (durMs > 0L && posMs >= (durMs * 0.95))) {
                                    continueWatchingRepository.deleteProgress(profileId, mediaId)
                                    continue
                                }

                                val title = doc.getString("title") ?: doc.getString("name") ?: doc.getString("mediaTitle") ?: "Title"
                                val description = doc.getString("description") ?: ""
                                val backdropUrl = doc.getString("backdropUrl") ?: ""
                                val posterUrl = doc.getString("posterUrl") ?: ""
                                val rating = doc.getString("rating") ?: "13+"
                                val year = doc.getString("year") ?: "2024"
                                val type = doc.getString("type") ?: "Series"
                                val duration = doc.getString("duration") ?: ""
                                val logoUrl = doc.getString("logoUrl")

                                val movie = Movie(
                                    id = mediaId,
                                    title = title,
                                    description = description,
                                    backdropUrl = backdropUrl,
                                    posterUrl = posterUrl,
                                    rating = rating,
                                    year = year,
                                    type = type,
                                    duration = duration,
                                    logoUrl = logoUrl
                                )

                                if (durMs > 0L && posMs > 1000L) {
                                    continueWatchingRepository.saveProgress(
                                        profileId = profileId,
                                        movie = movie,
                                        playbackPositionMs = posMs,
                                        durationMs = durMs,
                                        season = season,
                                        episode = episode,
                                        episodeName = episodeName
                                    )
                                }
                            } catch (e: Exception) {
                                android.util.Log.w("NetflixViewModel", "continue_watching doc parse error: ${e.message}")
                            }
                        }
                    }
                }

                continueWatchingFirestoreListener = db.collection("users").document(targetUid)
                    .collection("continue_watching")
                    .whereEqualTo("profileId", profileId)
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            android.util.Log.w("NetflixViewModel", "Error listening to continue_watching: ${error.message}")
                            return@addSnapshotListener
                        }
                        handleSnapshot(snapshot)
                    }

                continueWatchingNestedListener = db.collection("users").document(targetUid)
                    .collection("profiles").document(profileId)
                    .collection("continue_watching")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            android.util.Log.w("NetflixViewModel", "Error listening to nested continue_watching: ${error.message}")
                            return@addSnapshotListener
                        }
                        handleSnapshot(snapshot)
                    }
            }
        } catch (e: Exception) {
            android.util.Log.e("NetflixViewModel", "Error in listenToContinueWatchingFromFirestore: ${e.message}")
        }
    }

    fun setProfilesFromFirestore(newProfiles: List<Profile>) {
        if (newProfiles.isNotEmpty()) {
            _profiles.value = newProfiles
            saveStoredProfiles(newProfiles)
            if (_selectedProfile.value == null || newProfiles.none { it.id == _selectedProfile.value?.id }) {
                selectProfile(newProfiles.first())
            }
        }
    }

    fun listenToFirestoreProfiles(userId: String? = null) {
        if (userId != null) {
            prefs.edit().putString("paired_user_id", userId).apply()
        }
        try {
            if (FirebaseApp.getApps(getApplication()).isNotEmpty()) {
                val db = FirebaseFirestore.getInstance()
                val currentUser = FirebaseAuth.getInstance().currentUser
                val savedUid = prefs.getString("paired_user_id", null)
                val targetUid = userId ?: currentUser?.uid ?: savedUid

                if (targetUid.isNullOrBlank() || targetUid == "guest" || (currentUser == null && targetUid == "user_netflix_pro_primary")) {
                    android.util.Log.d("NetflixViewModel", "Skipping Firestore profiles listener for unauthenticated targetUid: $targetUid")
                    return
                }

                firestoreProfileListener?.remove()
                firestoreProfileListener = db.collection("users").document(targetUid).collection("profiles")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            android.util.Log.w("NetflixViewModel", "Firestore profiles status: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null && !snapshot.isEmpty) {
                            val fetchedList = snapshot.documents.mapNotNull { doc ->
                                try {
                                    // Pull favoriteGenres from Firestore as a List<String>
                                    // when present. Firestore stores it as a List<*>
                                    // and we coerce non-String entries to "" so a
                                    // single bad row doesn't take down the whole list.
                                    val rawGenres = doc.get("favoriteGenres") as? List<*> ?: emptyList<Any>()
                                    val genres = rawGenres.mapNotNull { it as? String }
                                    Profile(
                                        id = doc.getString("id") ?: doc.id,
                                        name = doc.getString("name") ?: "Profile",
                                        avatarColor = Color(0xFFE50914),
                                        isKid = doc.getBoolean("isKids") ?: doc.getBoolean("isKid") ?: false,
                                        avatarUrl = doc.getString("avatarUrl")?.takeIf { it.isNotBlank() },
                                        pin = doc.getString("pinHash")?.takeIf { it.isNotBlank() }
                                            ?: doc.getString("pin")?.takeIf { it.isNotBlank() },
                                        language = doc.getString("language") ?: "English",
                                        autoplayNext = doc.getBoolean("autoplayNext") ?: true,
                                        autoplayPreviews = doc.getBoolean("autoplayPreviews") ?: true,
                                        maturityRating = doc.getString("maturityRating") ?: "18+",
                                        favoriteGenres = genres,
                                        gameHandle = doc.getString("gameHandle")?.takeIf { it.isNotBlank() },
                                        createdAt = doc.getLong("createdAt") ?: 0L,
                                        lastUsedAt = doc.getLong("lastUsedAt") ?: 0L
                                    )
                                } catch (e: Exception) {
                                    null
                                }
                            }
                            if (fetchedList.isNotEmpty()) {
                                // Audit fix: route the SharedPreferences JSON
                                // serialization off the main thread. The
                                // previous version called setProfilesFromFirestore
                                // directly from the Firestore listener callback,
                                // which runs on the main executor; the JSON
                                // serialize + apply() on a TV flash could
                                // stutter the home animation when the user
                                // has 5 profiles.
                                viewModelScope.launch(Dispatchers.IO) {
                                    setProfilesFromFirestore(fetchedList)
                                }
                            }
                        }
                    }
            }
        } catch (e: Exception) {
            android.util.Log.w("NetflixViewModel", "Firestore not available: ${e.message}")
        }
    }

    // perf: serialize TV email/password sign-ins so a double-tap on the on-screen
    // "Sign In" button doesn't fire two parallel Firebase Auth requests that race
    // on _userSubscription and prefs writes.
    private val signInMutex = kotlinx.coroutines.sync.Mutex()
    private var activeSignInJob: kotlinx.coroutines.Job? = null

    // One-time auth events channel (used as a single source of truth instead of
    // a re-emitted StateFlow that re-fires on every recomposition).
    private val _authEvents = Channel<AuthEvent>(capacity = Channel.BUFFERED)
    val authEvents = _authEvents.receiveAsFlow()

    sealed class AuthEvent {
        data class Success(val email: String) : AuthEvent()
        data class Error(val message: String) : AuthEvent()
    }

    fun signInWithEmail(
        email: String,
        password: String,
        onSuccess: (email: String) -> Unit,
        onError: (errorMessage: String) -> Unit
    ) {
        // perf: cancel any in-flight sign-in before starting a new one — defends
        // against the user mashing the on-screen "Sign In" button while the
        // network request is still in flight.
        if (activeSignInJob?.isActive == true) {
            return
        }
        val trimmedEmail = email.trim()
        // Don't log the email — it can be considered PII for the user's account.
        activeSignInJob = viewModelScope.launch {
            signInMutex.withLock {
                try {
                    if (FirebaseApp.getApps(getApplication()).isEmpty()) {
                        FirebaseApp.initializeApp(getApplication())
                    }
                    val auth = FirebaseAuth.getInstance()
                    val result = withContext(Dispatchers.IO) {
                        auth.signInWithEmailAndPassword(trimmedEmail, password.trim()).await()
                    }
                    val user = result.user
                    if (user != null) {
                        val uid = user.uid

                        // Check subscription plan in Firestore before accepting login
                        var detectedPlanId = ""
                        var detectedPlanName = ""
                        var detectedStatus = ""
                        var expiresAt = 0L

                        withContext(Dispatchers.IO) {
                            try {
                                val db = FirebaseFirestore.getInstance()

                                // 1. Check users/{uid}/subscription/current
                                val subDoc = db.collection("users").document(uid)
                                    .collection("subscription").document("current")
                                    .get().await()
                                if (subDoc.exists()) {
                                    detectedPlanId = subDoc.getString("planId") ?: ""
                                    detectedPlanName = subDoc.getString("planName") ?: ""
                                    detectedStatus = subDoc.getString("status") ?: ""
                                    expiresAt = subDoc.getLong("expiresAt") ?: 0L
                                }

                                // 2. Check users/{uid} root document if not found
                                if (detectedPlanId.isBlank() && detectedPlanName.isBlank()) {
                                    val userDoc = db.collection("users").document(uid).get().await()
                                    if (userDoc.exists()) {
                                        detectedPlanId = userDoc.getString("planId")
                                            ?: userDoc.getString("plan")
                                            ?: userDoc.getString("subscriptionPlan") ?: ""
                                        detectedPlanName = userDoc.getString("planName") ?: ""
                                        detectedStatus = userDoc.getString("status")
                                            ?: userDoc.getString("subscriptionStatus") ?: ""
                                        expiresAt = userDoc.getLong("expiresAt") ?: 0L
                                    }
                                }

                                // 3. Check subscriptions/{uid} if present
                                if (detectedPlanId.isBlank() && detectedPlanName.isBlank()) {
                                    val directSubDoc = db.collection("subscriptions").document(uid).get().await()
                                    if (directSubDoc.exists()) {
                                        detectedPlanId = directSubDoc.getString("planId")
                                            ?: directSubDoc.getString("plan") ?: ""
                                        detectedPlanName = directSubDoc.getString("planName") ?: ""
                                        detectedStatus = directSubDoc.getString("status") ?: ""
                                        expiresAt = directSubDoc.getLong("expiresAt") ?: 0L
                                    }
                                }
                            } catch (e: Exception) {
                                android.util.Log.w("NetflixViewModel", "Error checking subscription on login: ${e.message}")
                            }
                        }

                        val planIdClean = detectedPlanId.trim().lowercase()
                        val planNameClean = detectedPlanName.trim().lowercase()
                        val isMobilePlan = planIdClean == "plan_mobile" ||
                                planIdClean == "mobile" ||
                                planIdClean.contains("mobile") ||
                                planNameClean.contains("mobile")

                        if (isMobilePlan) {
                            // Mobile plan is restricted to phones/tablets - reject login on TV
                            try {
                                auth.signOut()
                            } catch (_: Exception) {}
                            val msg = "Your account is on the Mobile Plan which does not support TV login. Please upgrade your plan to Basic, Standard, or Premium to sign in on TV."
                            _authEvents.trySend(AuthEvent.Error(msg))
                            onError(msg)
                            return@withLock
                        }

                        // For all other plans (Basic, Standard, Premium, etc.), accept login.
                        // Audit fix: when no plan was found on the server, we
                        // previously forced the user to plan_standard + ACTIVE,
                        // which is a free upgrade. The right thing is to leave
                        // the user in PENDING_ACTIVATION and let the Firestore
                        // subscription listener populate the real plan once it
                        // connects. If a real plan IS reported by the server,
                        // trust it.
                        val finalPlanId = detectedPlanId
                        val finalPlanName = detectedPlanName
                        val finalStatus = if (detectedStatus.isBlank() || detectedStatus.equals("NONE", ignoreCase = true)) {
                            if (detectedPlanId.isNotBlank()) "ACTIVE" else "PENDING_ACTIVATION"
                        } else detectedStatus

                        prefs.edit()
                            .putString("paired_user_id", uid)
                            .putString("user_email", trimmedEmail)
                            .putString("user_plan_id", finalPlanId)
                            .putString("user_plan_name", finalPlanName)
                            .putString("user_plan_status", finalStatus)
                            .putLong("user_plan_expires_at", expiresAt)
                            .apply()

                        val sub = com.example.model.UserSubscription(
                            status = finalStatus,
                            planId = finalPlanId,
                            planName = finalPlanName,
                            expiresAt = expiresAt
                        )
                        _userSubscription.value = sub
                        saveStoredSubscription(sub)

                        ensureProfilesLoaded()
                        listenToFirestoreProfiles(uid)
                        listenToFirestoreSubscription(uid)
                        _authEvents.trySend(AuthEvent.Success(trimmedEmail))
                        onSuccess(trimmedEmail)
                    } else {
                        val msg = "Sign in failed: could not retrieve user."
                        _authEvents.trySend(AuthEvent.Error(msg))
                        onError(msg)
                    }
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    // Don't include the raw exception message verbatim — it can
                    // contain pieces of the credential failure path or partial
                    // identifiers. Map known error classes to user-friendly copy.
                    val rawMsg = (e.localizedMessage ?: e.message ?: "Sign in failed")
                    val friendlyMsg = when {
                        rawMsg.contains("password", ignoreCase = true) || rawMsg.contains("credential", ignoreCase = true) ->
                            "Incorrect password. Please try again."
                        rawMsg.contains("user-not-found", ignoreCase = true) || rawMsg.contains("no user", ignoreCase = true) ->
                            "No account found with this email address."
                        rawMsg.contains("network", ignoreCase = true) ->
                            "Network error. Please check your TV connection."
                        rawMsg.contains("too-many-requests", ignoreCase = true) ->
                            "Too many attempts. Please wait a moment and try again."
                        else -> "Sign in failed. Please try again."
                    }
                    // Don't log the raw error — it may include the auth failure
                    // reason chained with the email. Log only the friendly copy.
                    android.util.Log.e("NetflixViewModel", "TV Auth Error: $friendlyMsg")
                    _authEvents.trySend(AuthEvent.Error(friendlyMsg))
                    onError(friendlyMsg)
                }
            }
        }
    }

    fun isUserLoggedInOrGuest(): Boolean {
        val pairedUid = prefs.getString("paired_user_id", null)
        if (!pairedUid.isNullOrBlank()) return true
        val userEmail = prefs.getString("user_email", null)
        if (!userEmail.isNullOrBlank()) return true
        val firebaseUser = try { FirebaseAuth.getInstance().currentUser } catch (_: Exception) { null }
        return firebaseUser != null
    }

    fun isUserLoggedIn(): Boolean {
        val pairedUid = prefs.getString("paired_user_id", null)
        val userEmail = prefs.getString("user_email", null)
        val isGuest = pairedUid == "guest" || userEmail == "guest"
        if (isGuest) return false
        if (!pairedUid.isNullOrBlank() || !userEmail.isNullOrBlank()) return true
        return try { FirebaseAuth.getInstance().currentUser != null } catch (_: Exception) { false }
    }

    fun ensureProfilesLoaded() {
        if (_profiles.value.isEmpty()) {
            _profiles.value = loadStoredProfiles()
        }
    }

    fun signOutFromTv() {
        try {
            FirebaseAuth.getInstance().signOut()
        } catch (_: Exception) {}
        // Audit fix (per spec §8): the previous implementation cleared
        // _userSubscription and the local plan prefs at sign-out, which
        // meant the UI blanked out the user's plan on the sign-in screen.
        // That made a TV-side sign-in feel "broken" because the user
        // momentarily lost visibility of their existing plan. The right
        // behaviour: clear account-scoped keys (uid / email), remove the
        // Firestore subscription listener so it can't push the OLD user's
        // plan updates into the NEW user's session, but leave the local
        // subscription prefs in place. The next sign-in will overwrite
        // them, and the UI keeps showing the last known plan until then.
        // Audit fix: tear down every account-scoped Firestore listener.
        // Previously only the subscription listener was removed; the
        // profiles and continue-watching listeners kept firing on the
        // signed-out user, applying stale remote state to an empty
        // local profile list (privacy leak + flickering UI on the next
        // sign-in).
        firestoreSubscriptionListener?.remove()
        firestoreSubscriptionListener = null
        firestoreProfileListener?.remove()
        firestoreProfileListener = null
        continueWatchingFirestoreListener?.remove()
        continueWatchingFirestoreListener = null
        continueWatchingNestedListener?.remove()
        continueWatchingNestedListener = null
        continueWatchingDebounceJob?.cancel()
        remoteCommandListener?.remove()
        remoteCommandListener = null
        streamHeartbeatJob?.cancel()
        // Offline-first outbox teardown: cancel every queued worker for
        // the previous user, and mark any in-flight / pending rows as
        // `failed` so they don't accidentally re-fire on the next sign-in
        // under a different account. The user can review + manually
        // retry from the sync-status UI.
        try {
            val previousUid = prefs.getString("paired_user_id", null)
            if (!previousUid.isNullOrBlank()) {
                viewModelScope.launch(Dispatchers.IO) {
                    try {
                        val cancelled = pendingWriteDao.cancelForUser("$previousUid%")
                        if (cancelled > 0) {
                            android.util.Log.d(
                                "PendingWrites",
                                "cancelled $cancelled pending write(s) for signed-out user $previousUid"
                            )
                        }
                    } catch (e: Exception) {
                        android.util.Log.w("PendingWrites", "cancelForUser failed: ${e.message}")
                    }
                }
            }
            SyncScheduler.cancelAll(getApplication())
        } catch (e: Exception) {
            android.util.Log.w("PendingWrites", "signOut teardown failed: ${e.message}")
        }
        prefs.edit()
            .remove("paired_user_id")
            .remove("user_email")
            // Intentionally NOT removing user_plan_* here — the next sign-in
            // will overwrite them, and removing them risks leaving the UI
            // on a blank plan state during the sign-in transition.
            .remove("saved_profiles_json")
            .apply()
        _profiles.value = emptyList()
        _selectedProfile.value = null
        // Intentionally NOT resetting _userSubscription here. Spec §8: the
        // next sign-in will populate it; the UI keeps the last known plan
        // during the sign-in transition. (We DO remove the Firestore
        // listener above, so the old user can't push updates into the
        // new session.)
    }

    private fun syncProfileToFirestore(profile: Profile) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (FirebaseApp.getApps(getApplication()).isNotEmpty()) {
                    val db = FirebaseFirestore.getInstance()
                    val targetUid = prefs.getString("paired_user_id", null)
                        ?: "user_netflix_pro_primary"
                    val collectionPath = "users/$targetUid/${Collections.PROFILES}"
                    val docRef = db.collection("users").document(targetUid)
                        .collection(Collections.PROFILES).document(profile.id)
                    // Audit fix: never write the raw PIN to Firestore. The model
                    // field is now a SHA-256 hex digest (see hashPin). The merge
                    // skips `pin` if the digest is blank so a no-PIN profile
                    // doesn't overwrite a previously stored hash with "".
                    // Sync lifecycle timestamps so the server can resolve
                    // server-wins / client-wins conflicts deterministically.
                    val data = hashMapOf<String, Any?>(
                        "id" to profile.id,
                        "name" to profile.name,
                        "avatarUrl" to (profile.avatarUrl ?: ""),
                        "isKids" to profile.isKid,
                        "language" to profile.language,
                        "maturityRating" to profile.maturityRating,
                        "autoplayNext" to profile.autoplayNext,
                        "autoplayPreviews" to profile.autoplayPreviews,
                        "favoriteGenres" to profile.favoriteGenres,
                        "gameHandle" to (profile.gameHandle ?: ""),
                        "lastUsedAt" to profile.lastUsedAt,
                        "createdAt" to profile.createdAt,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    if (!profile.pin.isNullOrBlank()) {
                        data["pin"] = profile.pin
                    }
                    // Apply per-field conflict policy. CLIENT_WINS fields
                    // pass through unchanged; SERVER_ONLY fields (id,
                    // createdAt) are stripped so a tampered client can't
                    // rewrite them; SERVER_WINS fields (lastUsedAt) are
                    // logged so a misuse is visible in logcat.
                    val filtered = ConflictResolver.filterWritable(Collections.PROFILES, data)
                    if (filtered.isEmpty()) {
                        android.util.Log.d(
                            "NetflixViewModel",
                            "syncProfileToFirestore: all fields filtered by policy; skipping write for profile ${profile.id}"
                        )
                        return@launch
                    }
                    // The hash pin field is stored under the legacy `pin`
                    // key but the policy map uses `pinHash`; the policy
                    // check above covered the `pin` field via the same
                    // CLIENT_WINS entry. A future schema migration can
                    // rename the field and update the policy map in lock-
                    // step.
                    // Offline-first outbox: durably record the write intent
                    // in `pending_writes` BEFORE attempting the direct
                    // Firestore call. If the direct call succeeds, we mark
                    // the row `done` inline; if it fails (or the device
                    // loses power mid-call), the PendingWriteRetryWorker
                    // picks it up on the next retry per the exponential
                    // backoff schedule. The payload uses a sentinel map
                    // for the serverTimestamp field — the worker unwraps
                    // {"__serverTimestamp": true} back into
                    // FieldValue.serverTimestamp() on commit.
                    val outboxPayload = filtered.mapValues { (_, v) ->
                        if (v is FieldValue) mapOf("__serverTimestamp" to true) else v
                    }
                    val rowId = SyncScheduler.enqueueWrite(
                        context = getApplication(),
                        dao = pendingWriteDao,
                        collection = collectionPath,
                        documentId = profile.id,
                        operation = com.example.data.PendingWrite.OP_UPDATE,
                        payload = SyncScheduler.encodePayload(outboxPayload)
                    )
                    try {
                        docRef.set(filtered, SetOptions.merge()).await()
                        pendingWriteDao.markDone(rowId, System.currentTimeMillis())
                    } catch (directErr: Exception) {
                        android.util.Log.w(
                            "NetflixViewModel",
                            "Direct profile sync failed, will retry via outbox row=$rowId: ${directErr.message}"
                        )
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("NetflixViewModel", "Error syncing profile to Firestore: ${e.message}")
            }
        }
    }

    fun addProfile(
        name: String,
        avatarUrl: String?,
        avatarColor: Color = Color(0xFFE50914),
        isKid: Boolean = false,
        pin: String? = null,
        language: String = "English",
        maturityRating: String = if (isKid) "7+" else "18+",
        favoriteGenres: List<String> = emptyList(),
        gameHandle: String? = null
    ): Profile {
        // Enforce per-subscription max-profile cap. The UI hides the "Add
        // Profile" tile when at the cap, but a programmatic caller (e.g.
        // walkthrough step 4) can still bypass that; this guard prevents the
        // user from going over their plan limit regardless of entry point.
        val maxAllowed = _userSubscription.value.maxProfiles
        if (_profiles.value.size >= maxAllowed) {
            throw IllegalStateException("Profile limit reached ($maxAllowed). Upgrade your plan to add more profiles.")
        }

        // Idempotency: if the same id is already in the list, return it
        // unchanged. This guards against the walkthrough re-firing the
        // auto-completion on a config change after addProfile succeeded.
        // We don't know the id yet (we're about to generate one) so we use
        // a sentinel below.

        // Generate a non-colliding id. The previous implementation used
        // `(System.currentTimeMillis() % 100000).toString()` which could collide
        // when addProfile is called twice in the same millisecond, or after
        // process restart. Take 5 random digits and verify uniqueness against
        // the current list; if the random id collides, append a counter.
        val existingIds = _profiles.value.map { it.id }.toHashSet()
        var newId: String
        var attempt = 0
        do {
            val rnd = (Math.random() * 100000).toInt().coerceAtLeast(1)
            newId = if (attempt == 0) rnd.toString() else "${rnd}_$attempt"
            attempt++
        } while (newId in existingIds && attempt < 100)
        if (newId in existingIds) {
            // Final fallback: timestamp + counter (practically unreachable).
            newId = "${System.currentTimeMillis()}_${existingIds.size}"
        }

        // Audit fix: disambiguate duplicate names with " (n)" suffix. The
        // original code allowed two profiles with the same display name,
        // which confuses the home screen ("Who's watching? Home" twice).
        // We pick a free suffix; if " (1)" is already taken we try " (2)",
        // etc. The unique name is what gets written to disk + Firestore.
        val finalName = resolveUniqueName(name)

        // Hash the PIN before persisting. Plaintext 4-digit PINs in
        // SharedPreferences and Firestore were a security hole: an
        // attacker with `adb backup` or a sloppy Firestore rule could
        // read every profile PIN. See [hashPin].
        val storedPin = hashPin(pin)

        val nowMs = System.currentTimeMillis()
        val newProfile = Profile(
            id = newId,
            name = finalName,
            avatarColor = avatarColor,
            isKid = isKid,
            avatarUrl = avatarUrl ?: ProfileIcons.ICONS.firstOrNull(),
            pin = storedPin,
            language = language,
            autoplayNext = true,
            autoplayPreviews = true,
            maturityRating = maturityRating,
            favoriteGenres = favoriteGenres,
            gameHandle = gameHandle,
            createdAt = nowMs,
            lastUsedAt = nowMs
        )
        val updated = _profiles.value + newProfile
        _profiles.value = updated
        saveStoredProfiles(updated)
        syncProfileToFirestore(newProfile)
        return newProfile
    }

    /**
     * Return a name that does not collide with any existing profile. If
     * [desired] is already free, it is returned unchanged. Otherwise we
     * append " (n)" with the smallest n that produces a free value.
     */
    private fun resolveUniqueName(desired: String): String {
        val existing = _profiles.value.map { it.name.lowercase() }.toHashSet()
        if (desired.lowercase() !in existing) return desired
        var counter = 1
        while (true) {
            val candidate = "$desired ($counter)"
            if (candidate.lowercase() !in existing) return candidate
            counter++
            if (counter > 100) {
                // Practically unreachable (100 collisions is enough for any
                // household), but we don't want a tight loop on a corrupt
                // state. Fall back to timestamp.
                return "$desired (${System.currentTimeMillis() % 1_000_000})"
            }
        }
    }

    fun updateProfile(updatedProfile: Profile) {
        // Partial-update semantics: callers may pass a Profile whose pin is
        // null. The previous implementation treated null as "no change", but
        // the UI sometimes explicitly wanted to clear the PIN. The new
        // contract: a non-null pin always wins (and is hashed); null means
        // "don't touch". The [setProfilePin] / [removeProfilePin] helpers
        // are the explicit-clear path.
        val stored = updatedProfile.copy(
            pin = updatedProfile.pin?.let { hashPin(it) ?: it }
        )
        val updatedList = _profiles.value.map {
            if (it.id == stored.id) stored else it
        }
        _profiles.value = updatedList
        saveStoredProfiles(updatedList)
        syncProfileToFirestore(stored)
        if (_selectedProfile.value?.id == stored.id) {
            _selectedProfile.value = stored
            applyProfilePersonalization(stored)
        }
    }

    fun deleteProfile(profileId: String): Boolean {
        // Refuse to delete the last profile — would leave the user with no
        // way to sign in to the app. The caller (EditProfileScreen) already
        // hides the Delete button when profiles.size == 1, but a programmatic
        // caller (e.g. a future bulk-remove flow) must not be able to bypass
        // the cap.
        if (_profiles.value.size <= 1) return false
        // Idempotent: if the profile is already gone, treat as success without
        // re-firing Firestore + IO writes (which would be wasteful on a duplicate
        // call from a race between confirm-tap and a previous async delete).
        if (_profiles.value.none { it.id == profileId }) return true

        val isCurrentlySelected = _selectedProfile.value?.id == profileId
        if (isCurrentlySelected) {
            // Guard: don't let the user lock themselves out by deleting the
            // active profile. The UI flow auto-selects another profile before
            // reaching here, but a stale call from a different surface should
            // be rejected so we never reach an "active profile does not exist"
            // state.
            val otherProfile = _profiles.value.firstOrNull { it.id != profileId }
            if (otherProfile == null) return false
            // Pre-emptively select the other profile so the home screen
            // doesn't briefly show no profile.
            selectProfile(otherProfile)
        }

        val updatedList = _profiles.value.filter { it.id != profileId }
        _profiles.value = updatedList
        saveStoredProfiles(updatedList)

        // Wipe profile-scoped data: continue watching + SharedPreferences
        // keys. The "My List" is per-account (shared across profiles), so
        // we intentionally do NOT delete `my_list_movie_ids_profile_*`.
        viewModelScope.launch(Dispatchers.IO) {
            try {
                continueWatchingRepository.deleteForProfile(profileId)
            } catch (e: Exception) {
                android.util.Log.e("NetflixViewModel", "deleteForProfile failed", e)
            }
            // Audit fix: move the Firestore profile delete off the main
            // thread and await the result so failures are visible in
            // logcat (previously the bare `.delete()` could throw a
            // network exception synchronously and be silently dropped by
            // the `catch (_: Exception) {}`).
            try {
                if (FirebaseApp.getApps(getApplication()).isNotEmpty()) {
                    val db = FirebaseFirestore.getInstance()
                    val targetUid = prefs.getString("paired_user_id", null) ?: "user_netflix_pro_primary"
                    // Policy gate: a profile delete is a row-level
                    // SERVER_ONLY operation — clients should not be able
                    // to delete a profile, only the server-side cleanup
                    // job (after a subscription cancel, say) should. The
                    // Firestore security rules are the primary gate; this
                    // log line is the in-app audit trail so a misconfigured
                    // rule is visible.
                    android.util.Log.d(
                        "Sync",
                        "policy=SERVER_ONLY_OP op=delete collection=profiles doc=$profileId"
                    )
                    val profileDocRef = db.collection("users").document(targetUid)
                        .collection(Collections.PROFILES).document(profileId)
                    // Offline-first outbox: enqueue a delete row so the
                    // worker replays the delete if the direct call fails
                    // (or the app is force-killed between call and ack).
                    val deleteRowId = SyncScheduler.enqueueWrite(
                        context = getApplication(),
                        dao = pendingWriteDao,
                        collection = "users/$targetUid/${Collections.PROFILES}",
                        documentId = profileId,
                        operation = com.example.data.PendingWrite.OP_DELETE,
                        payload = null
                    )
                    try {
                        profileDocRef.delete().await()
                        pendingWriteDao.markDone(deleteRowId, System.currentTimeMillis())
                    } catch (directErr: Exception) {
                        android.util.Log.w(
                            "NetflixViewModel",
                            "Direct profile delete failed, will retry via outbox row=$deleteRowId: ${directErr.message}"
                        )
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w("NetflixViewModel", "Firestore profile delete failed: ${e.message}")
            }
        }
        prefs.edit()
            .remove("liked_movie_ids_profile_$profileId")
            .remove("reminded_movie_ids_profile_$profileId")
            .remove("subtitle_language_profile_$profileId")
            .apply()

        // If the deleted profile was the lastSelectedProfileId, clear it so
        // the next launch doesn't try to re-select a non-existent id.
        if (prefs.getString("last_selected_profile_id", null) == profileId) {
            prefs.edit().remove("last_selected_profile_id").apply()
        }

        return true
    }

    fun updateProfileAvatar(profileId: String, newAvatarUrl: String) {
        val profile = _profiles.value.find { it.id == profileId }
        if (profile != null) {
            updateProfile(profile.copy(avatarUrl = newAvatarUrl))
        }
    }

    fun setProfilePin(profileId: String, pin: String?) {
        val profile = _profiles.value.find { it.id == profileId } ?: return
        // Hash before storage. Blank input means "clear the PIN".
        val storedPin = pin?.takeIf { it.isNotBlank() }?.let { hashPin(it) }
        updateProfile(profile.copy(pin = storedPin))
    }

    fun removeProfilePin(profileId: String) {
        setProfilePin(profileId, null)
    }

    /**
     * Verify an entered PIN against the profile's stored PIN hash.
     *
     * The previous implementation was a direct string compare, which only
     * works for the legacy plaintext format. New writes go through
     * [hashPin] and store the SHA-256 digest, so we must hash the entered
     * value and compare against the stored digest. We also fall back to
     * the legacy plaintext compare for backward-compat with profiles
     * created before the hashing was added (so existing installs don't
     * get locked out after the upgrade).
     */
    fun verifyPin(profileId: String, enteredPin: String): Boolean {
        val profile = _profiles.value.find { it.id == profileId } ?: return true
        val stored = profile.pin
        if (stored.isNullOrEmpty()) return true
        if (enteredPin.isBlank()) return false
        // Modern path: hash and compare.
        val hashed = hashPin(enteredPin) ?: return false
        if (stored.equals(hashed, ignoreCase = true)) return true
        // Legacy path: stored is plaintext 4 digits and entered matches.
        return stored == enteredPin
    }

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    
    // perf: keep this internal — only the Billboard should write here. External mutability
    // was a foot-gun (any caller could fire recompositions of MainActivity's collector).
    // The exposed property delegates to a backing MutableStateFlow so existing
    // .value writes from Billboard.kt keep compiling.
    private val _isBillboardPlaying = MutableStateFlow(false)
    val isBillboardPlaying: kotlinx.coroutines.flow.MutableStateFlow<Boolean> get() = _isBillboardPlaying

    private val _categoryRows = MutableStateFlow<List<Pair<String, List<Movie>>>>(emptyList())
    val categoryRows: StateFlow<List<Pair<String, List<Movie>>>> = _categoryRows.asStateFlow()

    private val _currentMovie = MutableStateFlow<Movie?>(null)
    val currentMovie: StateFlow<Movie?> = _currentMovie.asStateFlow()
    private var currentMovieProfileId: String? = null

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<Movie>>(emptyList())
    val searchResults: StateFlow<List<Movie>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _genres = MutableStateFlow<List<com.example.api.TmdbGenreDto>>(emptyList())
    val genres: StateFlow<List<com.example.api.TmdbGenreDto>> = _genres.asStateFlow()

    private val _selectedGenreId = MutableStateFlow<Long?>(null)
    val selectedGenreId: StateFlow<Long?> = _selectedGenreId.asStateFlow()

    private var searchJob: kotlinx.coroutines.Job? = null

    private val allMoviesMap = java.util.concurrent.ConcurrentHashMap<String, Movie>()
    private val personalizationGeneration = java.util.concurrent.atomic.AtomicLong(0L)

    // perf: default to a Guest plan to avoid a SharedPreferences disk read in the constructor.
    // The actual cached plan is loaded on the IO dispatcher in init { }.
    private val _userSubscription = MutableStateFlow(com.example.model.UserSubscription())
    val userSubscription: StateFlow<com.example.model.UserSubscription> = _userSubscription.asStateFlow()

    private val catalogLoadInProgress = java.util.concurrent.atomic.AtomicBoolean(false)
    private var originalCategoryRows: List<Pair<String, List<Movie>>> = emptyList()

    fun markHomeReady() = com.example.ui.util.HomeStartupGate.markHomeReady()
    fun markHomeHidden() {
        com.example.ui.util.HomeStartupGate.markHomeHidden()
        synchronized(warmupJobLock) {
            // Preserve an active cookie handshake for a possible Play request.
            // A job still waiting for Home to settle can be restarted immediately.
            if (!warmupIsImmediate &&
                !(warmupHasStartedAttempt && directCDNResolver.isSessionGenerationInProgress())) {
                warmupJob?.cancel()
                warmupJob = null
                warmupHasStartedAttempt = false
            }
        }
    }
    fun setHomeScrollInProgress(scrolling: Boolean) = com.example.ui.util.HomeStartupGate.setScrolling(scrolling)
    fun onHomeInteraction() = com.example.ui.util.HomeStartupGate.onInteraction()
    suspend fun awaitHomeIdle() = com.example.ui.util.HomeStartupGate.awaitIdle()
    suspend fun awaitBrowsingIdle() = com.example.ui.util.HomeStartupGate.awaitBrowsingIdle()

    init {
        // Wire the user-subscription clock so tests can swap a fake clock
        // without rewiring every call site that compares against
        // System.currentTimeMillis(). Production uses the real wall clock.
        com.example.model.UserSubscription.clock = { System.currentTimeMillis() }
        // perf: load stored profiles and subscription off the main thread.
        // Was synchronous in MutableStateFlow(...) defaults.
        viewModelScope.launch(Dispatchers.IO) {
            val loaded = loadStoredProfiles()
            if (loaded.isNotEmpty()) _profiles.value = loaded
            val sub = loadStoredSubscription()
            if (sub.planId != "plan_guest" || sub.status != "NONE") {
                _userSubscription.value = sub
            }
            // Pre-select the last-used profile so the user lands in the same
            // home screen they were watching, rather than the profile list.
            // Falls back to the first profile if the saved id is gone.
            val lastSelectedId = prefs.getString("last_selected_profile_id", null)
            if (!lastSelectedId.isNullOrBlank() && _profiles.value.any { it.id == lastSelectedId }) {
                _profiles.value.firstOrNull { it.id == lastSelectedId }?.let { prof ->
                    _selectedProfile.value = prof
                    _myListMovieIds.value = loadMyList()
                }
            }
        }
        loadData()
        val pairedUid = prefs.getString("paired_user_id", null)
        val targetUid = if (!pairedUid.isNullOrBlank() && pairedUid != "guest") pairedUid else null
        listenToFirestoreProfiles(targetUid)
        listenToFirestoreSubscription(targetUid)
        // Playback resolves its session on demand. Starting Chromium/session generation
        // from a cold-start timer competes with the first Home scroll even on 2 GB TVs.
    }
    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
        _selectedGenreId.value = null
        searchJob?.cancel()
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            _isSearching.value = false
            return
        }
        _isSearching.value = true
        searchJob = viewModelScope.launch {
            kotlinx.coroutines.delay(500)
            val rawResults = repository.searchMulti(query)
            val results = if (_selectedProfile.value?.isKid == true) {
                rawResults.filter { com.example.model.isKidSafeMovie(it) }
            } else {
                rawResults
            }
            results.forEach { allMoviesMap[it.id] = it }
            _searchResults.value = results
            _isSearching.value = false
        }
    }

    fun selectGenre(genreId: Long) {
        _selectedGenreId.value = genreId
        _searchQuery.value = ""
        searchJob?.cancel()
        _isSearching.value = true
        searchJob = viewModelScope.launch {
            val rawResults = repository.discoverByGenre(genreId)
            val results = if (_selectedProfile.value?.isKid == true) {
                rawResults.filter { com.example.model.isKidSafeMovie(it) }
            } else {
                rawResults
            }
            results.forEach { allMoviesMap[it.id] = it }
            _searchResults.value = results
            _isSearching.value = false
        }
    }

    fun hasValidStreamSession(): Boolean = directCDNResolver.hasValidSession()

    suspend fun ensureStreamWarmedAsync(): Boolean = directCDNResolver.ensureSessionWarm()

    private val warmupJobLock = Any()
    @Volatile private var warmupJob: kotlinx.coroutines.Job? = null
    private var warmupIsImmediate = false
    private var warmupHasStartedAttempt = false
    fun ensureStreamWarmed(immediate: Boolean = false) {
        synchronized(warmupJobLock) {
            val pending = warmupJob?.takeIf { it.isActive }
            if (pending != null) {
                if (!immediate || warmupIsImmediate) return
                if (warmupHasStartedAttempt && directCDNResolver.isSessionGenerationInProgress()) {
                    // Reuse the server postback already in flight; restarting it
                    // would cost the user another 35 seconds.
                    warmupIsImmediate = true
                    return
                }
                // A foreground request must not wait for Home's idle gate.
                pending.cancel()
            }
            warmupIsImmediate = immediate
            warmupHasStartedAttempt = false
            warmupJob = viewModelScope.launch(Dispatchers.IO) {
                val ownJob = currentCoroutineContext()[kotlinx.coroutines.Job]
                try {
                    suspend fun warmOnce(): Boolean {
                        val resolver = directCDNResolver
                        val mayRun = synchronized(warmupJobLock) {
                            val current = warmupJob === ownJob && ownJob?.isActive == true
                            if (current) warmupHasStartedAttempt = true
                            current
                        }
                        if (!mayRun) return false
                        try {
                            return resolver.ensureSessionWarm()
                        } finally {
                            synchronized(warmupJobLock) {
                                if (warmupJob === ownJob) warmupHasStartedAttempt = false
                            }
                        }
                    }
                    if (!immediate) {
                        // Keep session I/O after the first Home frame and away from D-pad scrolling.
                        kotlinx.coroutines.delay(3_000L)
                        awaitHomeIdle()
                    }
                    if (directCDNResolver.isSessionRecentlyVerified()) return@launch
                    if (warmOnce()) {
                        return@launch
                    }
                    // A Details/Play attempt has a bounded foreground budget.
                    // Only Home's quiet background job should retry later.
                    if (synchronized(warmupJobLock) { warmupIsImmediate }) return@launch
                    var retryDelayMs = 60_000L
                    while (isActive) {
                        kotlinx.coroutines.delay(retryDelayMs)
                        if (!synchronized(warmupJobLock) { warmupIsImmediate }) awaitHomeIdle()
                        if (warmOnce()) {
                            return@launch
                        }
                        retryDelayMs = (retryDelayMs * 2).coerceAtMost(10 * 60_000L)
                    }
                } catch (cancelled: kotlinx.coroutines.CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    android.util.Log.w("NetflixViewModel", "Background playback warmup failed", e)
                } finally {
                    synchronized(warmupJobLock) {
                        if (warmupJob === ownJob) {
                            warmupJob = null
                            warmupIsImmediate = false
                            warmupHasStartedAttempt = false
                        }
                    }
                }
            }
        }
    }


    fun loadData() {
        // A refresh must join the current load rather than double network, JSON and row work.
        if (!catalogLoadInProgress.compareAndSet(false, true)) return
        viewModelScope.launch(Dispatchers.IO) {
            val startTime = System.currentTimeMillis()
            com.example.ui.util.AppDiagnosticsLogger.event("Catalog", "Starting catalogue load...")
            _isLoading.value = _categoryRows.value.isEmpty()
            try {
                // Bound simultaneous JSON parsing during cold start; publish the four
                // initial rails together so focus/hero selection does not churn on entry.
                val (trending, popularMovies, popularTv, topRatedMovies) = coroutineScope {
                    val permits = Semaphore(
                        if (com.example.ui.util.TvImagePolicy.isLowMemoryDevice(getApplication())) 1 else 2
                    )
                    suspend fun core(fetch: suspend () -> List<Movie>): List<Movie> = permits.withPermit {
                        fetch().also { currentCoroutineContext().ensureActive() }
                    }
                    val trendingDef = async { core { repository.getTrending(fetchLogos = false) } }
                    val popMoviesDef = async { core { repository.getPopularMovies(fetchLogos = false) } }
                    val popTvDef = async { core { repository.getPopularTvShows(fetchLogos = false) } }
                    val topRatedDef = async { core { repository.getTopRatedMovies(fetchLogos = false) } }
                    listOf(trendingDef.await(), popMoviesDef.await(), popTvDef.await(), topRatedDef.await())
                }
                val coreTime = System.currentTimeMillis() - startTime
                com.example.ui.util.AppDiagnosticsLogger.performance("InitialCatalogCore", coreTime, 1200L, "First-paint rails (trending, popular, etc.) assembled")

                val earlyRows = mutableListOf<Pair<String, List<Movie>>>()
                if (trending.isNotEmpty()) earlyRows.add("Trending Now" to trending)
                if (popularMovies.isNotEmpty()) earlyRows.add("Popular Movies" to popularMovies)
                if (popularTv.isNotEmpty()) earlyRows.add("Binge-Worthy TV Series" to popularTv)
                if (topRatedMovies.isNotEmpty()) earlyRows.add("Top 10 Blockbusters" to topRatedMovies)

                if (earlyRows.isNotEmpty()) {
                    earlyRows.forEach { (_, movies) -> movies.forEach { allMoviesMap[it.id] = it } }
                    originalCategoryRows = earlyRows
                    _selectedProfile.value?.let { currentProf ->
                        applyProfilePersonalization(currentProf, preserveCurrentMovie = true)
                    } ?: run {
                        _categoryRows.value = earlyRows
                        if (_currentMovie.value == null) {
                            val firstMovie = earlyRows.first().second.firstOrNull()
                            _currentMovie.value = firstMovie
                            firstMovie?.let { fetchLogoForMovie(it) }
                        }
                    }
                }
                _isLoading.value = false

                // No wall-clock timer: Home reports its first rendered content and input
                // keeps postponing optional work. When all core calls failed, discovery
                // must still be able to recover an empty Home instead of waiting forever.
                suspend fun awaitDiscoveryIdle() {
                    if (earlyRows.isNotEmpty()) awaitHomeIdle() else awaitBrowsingIdle()
                }
                suspend fun discover(fetch: suspend () -> List<Movie>): List<Movie> {
                    awaitDiscoveryIdle()
                    return fetch().also { currentCoroutineContext().ensureActive() }
                }

                awaitDiscoveryIdle()
                _genres.value = repository.getGenres()
                currentCoroutineContext().ensureActive()

                // One response at a time. Recheck interaction before EVERY request, not
                // just before starting a batch that then competes with the next scroll.
                val action = discover { repository.getActionMovies() }
                val sciFi = discover { repository.getSciFiMovies() }
                val crime = discover { repository.getCrimeThrillers() }
                val anime = discover { repository.getAnime() }
                val comedy = discover { repository.getComedies() }
                val drama = discover { repository.getDramas() }
                val horror = discover { repository.getHorror() }
                val award = discover { repository.getAwardWinning() }
                val doc = discover { repository.getDocumentaries() }
                val nowPlaying = discover { repository.getNowPlayingMovies(fetchLogos = false) }
                val topRatedTv = discover { repository.getTopRatedTvShows(fetchLogos = false) }

                awaitDiscoveryIdle()
                val seenIds = mutableSetOf<String>()
                fun filterDistinct(list: List<Movie>, minCount: Int = 6): List<Movie> {
                    val fresh = list.filter { !seenIds.contains(it.id) }
                    val result = if (fresh.size >= minCount) fresh else list.distinctBy { it.id }
                    result.take(15).forEach { seenIds.add(it.id) }
                    return result
                }

                val fullRows = mutableListOf<Pair<String, List<Movie>>>()
                if (trending.isNotEmpty()) fullRows.add("Trending Now" to filterDistinct(trending, 8))
                if (popularTv.isNotEmpty()) fullRows.add("Binge-Worthy TV Series" to filterDistinct(popularTv, 8))
                if (action.isNotEmpty()) fullRows.add("Action & Adrenaline Blockbusters" to filterDistinct(action, 8))
                if (topRatedMovies.isNotEmpty()) fullRows.add("Top 10 Blockbusters" to filterDistinct(topRatedMovies, 8))
                if (sciFi.isNotEmpty()) fullRows.add("Sci-Fi & Cyberpunk Epics" to filterDistinct(sciFi, 8))
                if (crime.isNotEmpty()) fullRows.add("Crime Thrillers & Mysteries" to filterDistinct(crime, 8))
                if (award.isNotEmpty()) fullRows.add("Award-Winning & Critically Acclaimed" to filterDistinct(award, 8))
                if (anime.isNotEmpty()) fullRows.add("Anime Hits & Animation" to filterDistinct(anime, 8))
                if (comedy.isNotEmpty()) fullRows.add("Feel-Good & Comedies" to filterDistinct(comedy, 8))
                if (nowPlaying.isNotEmpty()) fullRows.add("Now in Theaters & Fresh Releases" to filterDistinct(nowPlaying, 8))
                if (drama.isNotEmpty()) fullRows.add("Emotional & Deep Dramas" to filterDistinct(drama, 8))
                if (horror.isNotEmpty()) fullRows.add("Late Night Thrillers & Horror" to filterDistinct(horror, 8))
                if (topRatedTv.isNotEmpty()) fullRows.add("All-Time Masterpiece TV Series" to filterDistinct(topRatedTv, 8))
                if (doc.isNotEmpty()) fullRows.add("Gripping Documentaries" to filterDistinct(doc, 8))

                if (fullRows.isNotEmpty()) {
                    fullRows.forEach { (_, movies) -> movies.forEach { allMoviesMap[it.id] = it } }
                    originalCategoryRows = fullRows
                    _selectedProfile.value?.let { currentProf ->
                        applyProfilePersonalization(currentProf, preserveCurrentMovie = true)
                    } ?: run {
                        _categoryRows.value = fullRows
                        if (_currentMovie.value == null) {
                            val firstMovie = fullRows.first().second.firstOrNull()
                            _currentMovie.value = firstMovie
                            firstMovie?.let { fetchLogoForMovie(it) }
                        }
                    }
                }

                val kidsMovies = discover { repository.getKidsMovies() }
                val kidsTv = discover { repository.getKidsTvShows() }
                kidsMovies.forEach { allMoviesMap[it.id] = it }
                kidsTv.forEach { allMoviesMap[it.id] = it }
                _selectedProfile.value?.takeIf { it.isKid }?.let {
                    awaitDiscoveryIdle()
                    applyProfilePersonalization(it, preserveCurrentMovie = true)
                }

                // Maintenance touches SQLite and the TV provider; keep it out of the
                // first layout and recheck after catalogue publication has settled.
                awaitDiscoveryIdle()
                try {
                    continueWatchingRepository.purgeStaleEntries(30L * 24L * 60L * 60L * 1000L)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    android.util.Log.w("NetflixViewModel", "Continue-watching cleanup failed", e)
                }
                awaitDiscoveryIdle()
                val channelMovies = fullRows.asSequence().flatMap { it.second.asSequence() }.distinctBy { it.id }.toList()
                if (channelMovies.isNotEmpty()) {
                    com.example.tv.TvHomeChannelManager.publishChannelPrograms(getApplication(), channelMovies)
                }
                val totalTime = System.currentTimeMillis() - startTime
                com.example.ui.util.AppDiagnosticsLogger.performance("FullCatalogBuild", totalTime, 4000L, "Full discovery grid with ${fullRows.size} rails finalized")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                com.example.ui.util.AppDiagnosticsLogger.error("Catalog", "Catalogue loading failed", e)
                android.util.Log.e("NetflixViewModel", "Catalogue loading failed", e)
            } finally {
                _isLoading.value = false
                catalogLoadInProgress.set(false)
            }
        }
    }
    fun selectProfile(profile: Profile) {
        // Audit fix: gracefully handle a stale id (profile was deleted out
        // from under us, or a Firestore snapshot referenced a profile we no
        // longer have). Falling back to the first profile keeps the user
        // out of the "no profile selected" dead-end.
        val resolved = profile.takeIf { p -> _profiles.value.any { it.id == p.id } }
            ?: _profiles.value.firstOrNull()
            ?: return
        _selectedProfile.value = resolved

        // Persist the last-selected id so the next cold start can pre-load
        // the right profile without waiting on Firestore. The value is
        // intentionally scoped to "last user-picked" — the home screen
        // reflects this on launch (see MainActivity).
        try {
            prefs.edit().putString("last_selected_profile_id", resolved.id).apply()
        } catch (_: Exception) {}

        // Update lastUsedAt locally + (in the background) on Firestore.
        // We don't block the UI on the network call.
        val nowMs = System.currentTimeMillis()
        if (resolved.lastUsedAt != nowMs) {
            val updatedList = _profiles.value.map {
                if (it.id == resolved.id) it.copy(lastUsedAt = nowMs) else it
            }
            _profiles.value = updatedList
            saveStoredProfiles(updatedList)
        }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (FirebaseApp.getApps(getApplication()).isNotEmpty()) {
                    val db = FirebaseFirestore.getInstance()
                    val targetUid = prefs.getString("paired_user_id", null) ?: return@launch
                    if (targetUid.isBlank() || targetUid == "guest") return@launch
                    // Policy check: `lastUsedAt` is SERVER_WINS — the
                    // server's clock is authoritative, so a client-side
                    // write of `nowMs` will be re-stamped on the next
                    // server-side heartbeat. The policy check makes that
                    // contract visible in the code.
                    val policy = ConflictResolver.policyFor(Collections.PROFILES, "lastUsedAt")
                    android.util.Log.d(
                        "Sync",
                        "policy=$policy field=lastUsedAt profileId=${resolved.id} localValue=$nowMs"
                    )
                    if (policy == ConflictPolicy.SERVER_ONLY) {
                        // Defensive: if a future policy edit reclassifies
                        // this field, skip the write entirely.
                        return@launch
                    }
                    val profileDocRef = db.collection("users").document(targetUid)
                        .collection(Collections.PROFILES)
                        .document(resolved.id)
                    // Offline-first outbox: enqueue the lastUsedAt update
                    // so a flaky network on profile switch doesn't lose
                    // the "most recently used" signal. Field is SERVER_WINS
                    // so the server will re-stamp the value on its own
                    // heartbeat; this is best-effort. The outbox row uses
                    // the `pin` -> pinHash key alias if a future schema
                    // migration lands; today's key is `lastUsedAt`.
                    val lastUsedRowId = SyncScheduler.enqueueWrite(
                        context = getApplication(),
                        dao = pendingWriteDao,
                        collection = "users/$targetUid/${Collections.PROFILES}",
                        documentId = resolved.id,
                        operation = com.example.data.PendingWrite.OP_UPDATE,
                        payload = SyncScheduler.encodePayload(
                            mapOf("lastUsedAt" to nowMs)
                        )
                    )
                    try {
                        profileDocRef.update("lastUsedAt", nowMs).await()
                        pendingWriteDao.markDone(lastUsedRowId, System.currentTimeMillis())
                    } catch (directErr: Exception) {
                        android.util.Log.w(
                            "NetflixViewModel",
                            "Direct lastUsedAt sync failed, will retry via outbox row=$lastUsedRowId: ${directErr.message}"
                        )
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w("NetflixViewModel", "Failed to update lastUsedAt for ${resolved.id}: ${e.message}")
            }
        }

        listenToContinueWatchingFromFirestore(resolved.id)

        // Sync My List (account-shared; see [loadMyList]).
        val savedList = loadMyList()
        _myListMovieIds.value = savedList
        // bugfix: also hydrate the per-movie addedAt map; previously a profile
        // switch would leave _myListAddedAt at its old profile's values,
        // making sortByMyListMembership() return the wrong order until the
        // user toggled an item.
        val savedAddedAt = loadMyListAddedAt(resolved.id)
        _myListAddedAt.value = if (savedAddedAt.isNotEmpty()) {
            // Drop any orphans — keys in addedAt that aren't in savedList —
            // so the timestamp map stays in lock-step with the id set.
            savedAddedAt.filterKeys { it in savedList }
        } else {
            // Legacy installs have no addedAt; synthesize a "now" timestamp
            // for every id so the row sorts to its current order on first
            // load (the user will see a one-time reorder, which is correct
            // behaviour for a previously-unsorted list).
            savedList.associateWith { System.currentTimeMillis() }
        }

        // Sync profile-specific Liked titles
        val savedLiked = prefs.getStringSet("liked_movie_ids_profile_${resolved.id}", emptySet()) ?: emptySet()
        _likedMovieIds.value = savedLiked

        // Sync profile-specific Reminded titles
        val savedReminded = prefs.getStringSet("reminded_movie_ids_profile_${resolved.id}", emptySet()) ?: emptySet()
        _remindedMovieIds.value = savedReminded

        // Sync profile subtitle language
        val subLang = prefs.getString("subtitle_language_profile_${resolved.id}", resolved.language) ?: resolved.language
        _selectedSubtitleLanguage.value = subLang

        applyProfilePersonalization(resolved)
    }

    private fun applyProfilePersonalization(profile: Profile, preserveCurrentMovie: Boolean = false) {
        viewModelScope.launch {
            if (_selectedProfile.value?.id != profile.id) return@launch
            val generation = personalizationGeneration.incrementAndGet()
            val baseRows = originalCategoryRows
            suspend fun publish(rows: List<Pair<String, List<Movie>>>, defaultMovie: Movie?) {
                withContext(Dispatchers.Main) {
                    // A later profile/catalogue request may finish before this one.
                    if (personalizationGeneration.get() != generation ||
                        _selectedProfile.value?.id != profile.id) return@withContext
                    _categoryRows.value = rows
                    val current = _currentMovie.value
                    val canKeepCurrent = preserveCurrentMovie && currentMovieProfileId == profile.id && current != null &&
                        (!profile.isKid || isKidSafeMovie(current))
                    if (!canKeepCurrent) {
                        currentMovieProfileId = profile.id
                        _currentMovie.value = defaultMovie
                        defaultMovie?.let { fetchLogoForMovie(it) }
                    }
                }
            }

            withContext(Dispatchers.Default) {
                if (profile.isKid) {
                    // Kids Profile Mode: Strictly 12 and under filter (PG, G, TV-Y, TV-Y7, TV-G, TV-PG, 12)
                    val allMovies = (baseRows.flatMap { it.second } + allMoviesMap.values).distinctBy { it.id }
                    val kidSafeMovies = allMovies.filter { com.example.model.isKidSafeMovie(it) }

                    val kidsRows = mutableListOf<Pair<String, List<Movie>>>()
                    val kidsTop10 = kidSafeMovies.take(10)
                    if (kidsTop10.isNotEmpty()) {
                        kidsRows.add("Top 10 for Kids Today" to kidsTop10)
                    }
                    val familyMovies = kidSafeMovies.filter { it.type == "Movie" || it.type == "Animation" }.ifEmpty { kidSafeMovies }
                    if (familyMovies.isNotEmpty()) kidsRows.add("Watch with the Family" to familyMovies)
                    val animated = kidSafeMovies.filter { it.type == "Animation" }
                    if (animated.isNotEmpty()) kidsRows.add("Animated Adventures & Anime" to animated)
                    val kidsSeries = kidSafeMovies.filter { it.type == "Series" }
                    if (kidsSeries.isNotEmpty()) kidsRows.add("Kids TV Shows & Cartoons" to kidsSeries)
                    if (kidSafeMovies.size > 5) kidsRows.add("Fun & Laughs for Family Night" to kidSafeMovies.reversed())

                    val firstKidMovie = kidSafeMovies.firstOrNull() ?: baseRows.firstOrNull()?.second?.firstOrNull()
                    publish(if (kidsRows.isNotEmpty()) kidsRows else baseRows, firstKidMovie)
                } else if (profile.favoriteGenres.isNotEmpty()) {
                    // Personalize rows based on selected favorite genres
                    val personalized = mutableListOf<Pair<String, List<Movie>>>()

                    // Add Top Picks for user
                    val allMovies = baseRows.flatMap { it.second }.distinctBy { it.id }
                    val topPicks = allMovies.shuffled().take(12)
                    if (topPicks.isNotEmpty()) {
                        personalized.add("Top Picks for ${profile.name}" to topPicks)
                    }

                    // Add genre-specific rows
                    profile.favoriteGenres.forEach { genreName ->
                        val genreFiltered = allMovies.filter { movie ->
                            movie.title.contains(genreName, ignoreCase = true) ||
                            movie.description.contains(genreName, ignoreCase = true)
                        }
                        if (genreFiltered.isNotEmpty()) {
                            personalized.add("Because you love $genreName" to genreFiltered)
                        }
                    }

                    // Add original general rows
                    baseRows.forEach { row ->
                        if (!personalized.any { it.first == row.first }) {
                            personalized.add(row)
                        }
                    }
                    val movie = topPicks.firstOrNull() ?: baseRows.firstOrNull()?.second?.firstOrNull()
                    publish(personalized, movie)
                } else {
                    val first = baseRows.firstOrNull()?.second?.firstOrNull()
                    publish(baseRows, first)
                }
            }
        }
    }

    fun updateCurrentMovie(movie: Movie) {
        currentMovieProfileId = _selectedProfile.value?.id
        _currentMovie.value = movie
        fetchLogoForMovie(movie)
    }

    /** Owned by the screen's effect so navigation cancels optional logo requests. */
    suspend fun resolveMovieLogo(movie: Movie): String? = withContext(Dispatchers.IO) {
        repository.getCachedLogo(movie.id)
            ?: movie.logoUrl?.takeIf { it.isNotBlank() }
            ?: repository.fetchLogoUrl(movie.id.toLongOrNull() ?: 0L, movie.type == "Series")
    }

    fun getLogoUrl(movie: Movie, onResult: (String?) -> Unit) {
        val cachedLogo = repository.getCachedLogo(movie.id)
        if (cachedLogo != null) {
            onResult(cachedLogo)
            return
        }
        if (!movie.logoUrl.isNullOrBlank()) {
            onResult(movie.logoUrl)
            return
        }
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val isTv = movie.type == "Series"
            val logo = repository.fetchLogoUrl(movie.id.toLongOrNull() ?: 0L, isTv)
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                onResult(logo)
            }
        }
    }

    fun fetchLogoForMovie(movie: Movie) {
        val cachedLogo = repository.getCachedLogo(movie.id)
        if (cachedLogo != null && movie.logoUrl != cachedLogo) {
            val updated = movie.copy(logoUrl = cachedLogo)
            allMoviesMap[movie.id] = updated
            if (_currentMovie.value?.id == movie.id) {
                _currentMovie.value = updated
            }
            return
        }
        if (movie.logoUrl.isNullOrBlank()) {
            viewModelScope.launch(Dispatchers.IO) {
                val isTv = movie.type == "Series"
                val logo = repository.fetchLogoUrl(movie.id.toLongOrNull() ?: 0L, isTv)
                if (!logo.isNullOrBlank()) {
                    val updated = movie.copy(logoUrl = logo)
                    allMoviesMap[movie.id] = updated
                    if (_currentMovie.value?.id == movie.id) {
                        _currentMovie.value = updated
                    }
                }
            }
        }
    }

    fun cacheMovie(movie: Movie) {
        allMoviesMap[movie.id] = movie
    }

    fun getMovieById(id: String?): Movie? {
        if (id == null) return null
        return allMoviesMap[id]
            ?: continueWatchingList.value.find { it.movieId == id }?.toMovie()
            ?: _categoryRows.value.flatMap { it.second }.find { it.id == id }
            ?: originalCategoryRows.flatMap { it.second }.find { it.id == id }
            ?: _searchResults.value.find { it.id == id }
    }

    fun getRecommendationsForMovie(movie: Movie): List<Movie> {
        val allMovies = (allMoviesMap.values + _categoryRows.value.flatMap { it.second } + originalCategoryRows.flatMap { it.second })
            .distinctBy { it.id }
            .filter { it.id != movie.id }

        if (allMovies.isEmpty()) return emptyList()

        val isKid = isKidSafeMovie(movie)
        val matched = allMovies.filter { other ->
            (isKid && isKidSafeMovie(other)) || (other.type.equals(movie.type, ignoreCase = true))
        }

        return if (matched.isNotEmpty()) {
            matched.take(12)
        } else {
            allMovies.take(12)
        }
    }

    fun logout() {
        signOutFromTv()
    }

    private data class CachedStream(
        val stream: com.example.data.NetMirrorStream,
        val timestamp: Long,
        val sessionVersion: Long
    )
    private val streamCacheFallbackTtlMs = 10L * 60 * 60 * 1000L // 10 hours, matching token TTL
    private val streamExpirySafetyMarginMs = 15 * 1000L
    private val streamCache = java.util.concurrent.ConcurrentHashMap<String, CachedStream>()
    private val streamFetchMutexes = java.util.concurrent.ConcurrentHashMap<String, kotlinx.coroutines.sync.Mutex>()

    private fun streamCacheKey(movie: Movie, season: Int, episode: Int): String =
        "${movie.id}_${movie.type}_${season}_${episode}"

    private fun isUsableStream(cached: CachedStream, currentTime: Long): Boolean {
        val age = currentTime - cached.timestamp
        val withinFallbackTtl = age >= 0 && age < streamCacheFallbackTtlMs
        val expiresAt = cached.stream.expiresAt
        val hasEnoughLifetime = expiresAt <= 0L || expiresAt - currentTime > streamExpirySafetyMarginMs
        return cached.sessionVersion == directCDNResolver.sessionVersion && withinFallbackTtl && hasEnoughLifetime
    }

    /** Returns a valid resolved stream without starting a network request. */
    fun getCachedStream(movie: Movie, season: Int = 1, episode: Int = 1): com.example.data.NetMirrorStream? {
        val cacheKey = streamCacheKey(movie, season, episode)
        val cached = streamCache[cacheKey] ?: return null
        return if (isUsableStream(cached, System.currentTimeMillis())) {
            cached.stream
        } else {
            streamCache.remove(cacheKey, cached)
            null
        }
    }

    fun reportBadSession(cookieString: String?) {
        synchronized(warmupJobLock) {
            warmupJob?.cancel()
            warmupJob = null
            warmupIsImmediate = false
            warmupHasStartedAttempt = false
        }
        nextEpisodePreloadJob?.cancel()
        directCDNResolver.invalidateSessionByCookie(cookieString)
        streamCache.clear()
    }

    fun evictCachedStream(movie: Movie, season: Int = 1, episode: Int = 1) {
        streamCache.remove(streamCacheKey(movie, season, episode))
        val type = if (movie.type.equals("Series", ignoreCase = true) || movie.type.equals("TV", ignoreCase = true) ||
            movie.duration.contains("Season", ignoreCase = true)) "tv" else "movie"
        directCDNResolver.evictCachedStream(movie.id, type, season, episode)
    }

    /** Drops a failed source so the next play attempt resolves a fresh URL. */
    fun invalidateStream(movie: Movie, season: Int = 1, episode: Int = 1) {
        val cacheKey = streamCacheKey(movie, season, episode)
        streamCache.remove(cacheKey)
        val type = if (movie.type.equals("Series", ignoreCase = true) || movie.type.equals("TV", ignoreCase = true) || movie.duration.contains("Season", ignoreCase = true)) "tv" else "movie"
        directCDNResolver.invalidateStream(movie.id, type, season, episode)
    }

    private var nextEpisodePreloadJob: kotlinx.coroutines.Job? = null
    fun preloadNextEpisodeStream(movie: Movie, season: Int, episode: Int) {
        nextEpisodePreloadJob?.cancel()
        nextEpisodePreloadJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                if (getCachedStream(movie, season, episode) != null) return@launch
                android.util.Log.d("NetflixViewModel", "⏩ Pre-resolving next episode S${season}E${episode} for ${movie.title}...")
                resolveStream(movie, season, episode)
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (_: Exception) {}
        }
    }

    suspend fun resolveStream(movie: Movie, season: Int = 1, episode: Int = 1): com.example.data.NetMirrorStream? =
        // Count the wait for a pending warmup, session renewal, and manifest
        // discovery together. A first Play must finish or fail within a minute.
        kotlinx.coroutines.withTimeoutOrNull(58_000L) {
            resolveStreamWithinDeadline(movie, season, episode)
        }

    private suspend fun resolveStreamWithinDeadline(movie: Movie, season: Int, episode: Int): com.example.data.NetMirrorStream? {
        getCachedStream(movie, season, episode)?.let { return it }
        // Play never waits for a Home-idle timer. Join a handshake already in
        // flight; otherwise cancel the deferred job and resolve immediately.
        val pendingWarmup = synchronized(warmupJobLock) {
            val pending = warmupJob?.takeIf { it.isActive }
            if (pending != null && !warmupIsImmediate &&
                !(warmupHasStartedAttempt && directCDNResolver.isSessionGenerationInProgress())) {
                pending.cancel()
                warmupJob = null
                warmupHasStartedAttempt = false
                null
            } else pending
        }
        if (pendingWarmup?.isActive == true) {
            try {
                kotlinx.coroutines.withTimeoutOrNull(20_000L) {
                    pendingWarmup.join()
                }
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (_: Exception) {}
        }
        val cacheKey = streamCacheKey(movie, season, episode)
        getCachedStream(movie, season, episode)?.let { return it }

        // A request for one title must not stall playback of another title.
        val fetchMutex = streamFetchMutexes.getOrPut(cacheKey) { kotlinx.coroutines.sync.Mutex() }
        return fetchMutex.withLock {
            getCachedStream(movie, season, episode)?.let { return@withLock it }

            try {
                android.util.Log.d("NetflixViewModel", "⚡ Resolving stream for ${movie.title} (tmdbId=${movie.id}, S${season}E${episode})...")
                var stream: com.example.data.NetMirrorStream? = null
                try {
                    stream = directCDNResolver.resolveStream(movie, season, episode)
                } catch (cancelled: kotlinx.coroutines.CancellationException) {
                    throw cancelled
                } catch (limited: com.example.data.PlaybackRateLimitedException) {
                    throw limited
                } catch (e: Exception) {
                    android.util.Log.w("NetflixViewModel", "⚠️ DirectCDNResolver failed: ${e.message}")
                }

                if (stream != null) {
                    val version = directCDNResolver.sessionVersion
                    streamCache[cacheKey] = CachedStream(stream, System.currentTimeMillis(), version)
                }
                stream
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (limited: com.example.data.PlaybackRateLimitedException) {
                throw limited
            } catch (e: Exception) {
                android.util.Log.e("NetflixViewModel", "Stream resolution failed", e)
                null
            }
        }
    }

    suspend fun fetchSubtitlesForStream(stream: com.example.data.NetMirrorStream, movie: Movie, season: Int, episode: Int): List<com.example.data.Caption> {
        return withContext(Dispatchers.IO) {
            val sessionVersion = directCDNResolver.sessionVersion
            try {
                val captions = directCDNResolver.fetchSubtitlesForEpisode(movie, season, episode)
                if (captions.isNotEmpty()) {
                    val updatedStream = stream.copy(
                        captions = (stream.captions + captions).distinctBy { it.url }
                    )
                    val cacheKey = streamCacheKey(movie, season, episode)
                    if (sessionVersion == directCDNResolver.sessionVersion) {
                        streamCache[cacheKey] = CachedStream(updatedStream, System.currentTimeMillis(), sessionVersion)
                    }
                    captions
                } else {
                    emptyList()
                }
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                emptyList()
            }
        }
    }

    private fun loadStoredSubscription(): com.example.model.UserSubscription {
        val pairedUid = prefs.getString("paired_user_id", null)
        val userEmail = prefs.getString("user_email", null)
        val hasUser = (!pairedUid.isNullOrBlank() && pairedUid != "guest") ||
                (!userEmail.isNullOrBlank() && userEmail != "guest") ||
                (try { FirebaseAuth.getInstance().currentUser != null } catch (_: Exception) { false })

        // Audit fix: previously a signed-in user with no stored plan defaults
        // to plan_standard + ACTIVE — that silently grants free Standard to
        // every new sign-in, which is a revenue leak. The server is the only
        // place that should grant access; until the server confirms a plan,
        // the local cache reflects a Guest / unverified state. The Firestore
        // listener (listenToFirestoreSubscription) will populate the real
        // state as soon as it connects.
        val defaultPlanId = "plan_guest"
        val defaultPlanName = "Guest"
        val defaultStatus = if (hasUser) "PENDING_ACTIVATION" else "NONE"

        var planId = prefs.getString("user_plan_id", defaultPlanId) ?: defaultPlanId
        var planName = prefs.getString("user_plan_name", defaultPlanName) ?: defaultPlanName
        var status = prefs.getString("user_plan_status", defaultStatus) ?: defaultStatus
        val expiresAt = prefs.getLong("user_plan_expires_at", 0L)

        // Don't auto-promote a missing plan to Standard. Only retain the
        // stored plan if it was actually granted by the server previously.
        // (See audit §1, §10 — "Subscription state changes only come from
        // the server (not the client).")

        return com.example.model.UserSubscription(
            status = status,
            planId = planId,
            planName = planName,
            expiresAt = expiresAt
        )
    }

    private fun saveStoredSubscription(sub: com.example.model.UserSubscription) {
        prefs.edit()
            .putString("user_plan_id", sub.planId)
            .putString("user_plan_name", sub.planName)
            .putString("user_plan_status", sub.status)
            .putLong("user_plan_expires_at", sub.expiresAt)
            .putLong("user_plan_subscribed_at", sub.subscribedAt)
            .putString("user_plan_payment_reference", sub.paymentReference)
            .putString("user_plan_mpesa_receipt", sub.mpesaReceipt)
            .putInt("user_plan_amount", sub.amount)
            .putString("user_plan_currency", sub.currency)
            .apply()
    }

    fun setPairedUser(
        userId: String,
        email: String,
        planId: String = "",
        planName: String = "",
        status: String = "",
        expiresAt: Long = 0L
    ) {
        // Audit fix: previously an empty / guest planId was silently coerced
        // to plan_standard + ACTIVE. That is a free-upgrade: a user who
        // signs in but has no paid plan on the server would still be granted
        // local Standard access until the server corrected it. Now the
        // defaults are PENDING_ACTIVATION (signed-in but not yet entitled),
        // and the Firestore listener is the only path that promotes to a
        // real paid tier.
        val finalPlanId = planId.trim()
        val finalPlanName = planName.trim()
        val finalStatus = if (status.isBlank() || status.equals("NONE", ignoreCase = true)) "PENDING_ACTIVATION" else status

        prefs.edit()
            .putString("paired_user_id", userId)
            .putString("user_email", email)
            .putString("user_plan_id", finalPlanId)
            .putString("user_plan_name", finalPlanName)
            .putString("user_plan_status", finalStatus)
            .putLong("user_plan_expires_at", expiresAt)
            .apply()

        val sub = com.example.model.UserSubscription(
            status = finalStatus,
            planId = finalPlanId,
            planName = finalPlanName,
            expiresAt = expiresAt
        )
        _userSubscription.value = sub
        saveStoredSubscription(sub)

        ensureProfilesLoaded()
        listenToFirestoreProfiles(userId)
        listenToFirestoreSubscription(userId)
    }

    fun setGuestMode() {
        prefs.edit()
            .putString("paired_user_id", "guest")
            .putString("user_email", "guest")
            .putString("user_plan_id", "plan_guest")
            .putString("user_plan_name", "Guest")
            .putString("user_plan_status", "NONE")
            .putLong("user_plan_expires_at", 0L)
            .apply()

        val guestSub = com.example.model.UserSubscription(
            status = "NONE",
            planId = "plan_guest",
            planName = "Guest",
            expiresAt = 0L
        )
        _userSubscription.value = guestSub
        saveStoredSubscription(guestSub)

        ensureProfilesLoaded()
    }

    /**
     * Upgrade the user's plan. Writes the new plan to Firestore FIRST and
     * only updates the local [userSubscription] state on server confirmation.
     *
     * Audit fix: previously this function only mutated local prefs and the
     * in-memory [_userSubscription] state. A user could "upgrade" for free
     * by tapping the upgrade button — there was no server-side payment
     * verification and no Firestore write. The new flow:
     *
     *   1. Debounce: if an upgrade is already in flight, return immediately.
     *   2. Resolve the new plan from the [SubscriptionPlans] catalog.
     *   3. Write the new planId/planName/expiresAt to
     *      `users/{uid}/subscription/current` on Firestore (the canonical
     *      server-side source of truth). Server-side rules + a future
     *      billing webhook will overwrite this with the real status.
     *   4. On Firestore success, update local prefs + _userSubscription.
     *   5. On failure, log and surface a user-facing error — local state
     *      is NOT touched (the user keeps their previous plan).
     */
    fun upgradePlan(planId: String, planName: String) {
        if (activeUpgradeJob?.isActive == true) {
            // Debounce: a second tap while the first is still in flight
            // would otherwise fire two parallel Firestore writes. The first
            // write wins; the second is dropped.
            return
        }
        val newPlan = com.example.model.SubscriptionPlans.getById(planId)
        val currentUserId = prefs.getString("paired_user_id", null)?.takeIf { it != "guest" }
            ?: return // No signed-in user; refuse to upgrade (was previously
                     // creating a synthetic user id, which is a fraud vector).
        val userEmail = prefs.getString("user_email", null)?.takeIf { it != "guest" } ?: ""
        val expiresAt = System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000L)

        activeUpgradeJob = viewModelScope.launch {
            upgradeMutex.withLock {
                try {
                    if (FirebaseApp.getApps(getApplication()).isNotEmpty()) {
                        val db = FirebaseFirestore.getInstance()
                        val subDoc = db.collection("users").document(currentUserId)
                            .collection(Collections.SUBSCRIPTION).document("current")
                        val data = hashMapOf(
                            "planId" to newPlan.id,
                            "planName" to newPlan.name,
                            "status" to "PENDING_ACTIVATION",
                            "expiresAt" to expiresAt,
                            "subscribedAt" to System.currentTimeMillis(),
                            "amount" to newPlan.priceKes,
                            "currency" to "KES",
                            "pendingUpgrade" to true
                        )
                        // Policy gate: the upgrade write is allowed to set
                        // the *pending* status (CLIENT_WINS-like — the
                        // user is requesting a change), but every other
                        // billing-owned field (tier, isActive, renewsAt,
                        // paymentMethod) is SERVER_ONLY. The policy map
                        // doesn't have entries for `planId` / `planName`
                        // / `status` / `pendingUpgrade` / `amount` /
                        // `currency` because those are the only fields
                        // the client is legitimately allowed to write
                        // during an upgrade. A future field addition
                        // requires updating the policy map; the
                        // assertCanWrite() call below makes that
                        // contract explicit.
                        ConflictResolver.assertCanWrite(Collections.SUBSCRIPTION, data)
                        withContext(Dispatchers.IO) {
                            subDoc.set(data, SetOptions.merge()).await()
                        }
                    }
                    // Server is the source of truth. The Firestore listener
                    // (listenToFirestoreSubscription) will pick up the new
                    // state and push it into _userSubscription. We don't
                    // double-write here.
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    android.util.Log.e("NetflixViewModel", "Upgrade plan failed: ${e.message}")
                    // Local state untouched — user keeps their prior plan.
                    return@withLock
                }
                // Optimistically refresh the local cache from prefs so the UI
                // shows "Pending activation" until the server confirms.
                val pendingSub = com.example.model.UserSubscription(
                    status = "PENDING_ACTIVATION",
                    planId = newPlan.id,
                    planName = newPlan.name,
                    subscribedAt = System.currentTimeMillis(),
                    expiresAt = expiresAt,
                    amount = newPlan.priceKes,
                    currency = "KES",
                    autoRenew = true
                )
                _userSubscription.value = pendingSub
                saveStoredSubscription(pendingSub)
            }
        }
    }

    fun isMovieLocked(movie: Movie): Boolean {
        val isVipOrBlockbuster = movie.rating.contains("VIP", ignoreCase = true) ||
                movie.rating.contains("4K", ignoreCase = true) ||
                movie.title.contains("Dune", ignoreCase = true) ||
                movie.title.contains("Avatar", ignoreCase = true) ||
                movie.title.contains("Oppenheimer", ignoreCase = true) ||
                movie.title.contains("Squid", ignoreCase = true) ||
                movie.year == "2026" || movie.year == "2025"
        return _userSubscription.value.isMovieLocked(
            movieId = movie.id,
            releaseYear = movie.year,
            isTrendingOrVip = isVipOrBlockbuster,
            isTvDevice = false
        )
    }

    fun getLockReason(movie: Movie): String {
        val isVipOrBlockbuster = movie.rating.contains("VIP", ignoreCase = true) ||
                movie.rating.contains("4K", ignoreCase = true) ||
                movie.title.contains("Dune", ignoreCase = true) ||
                movie.title.contains("Avatar", ignoreCase = true) ||
                movie.title.contains("Oppenheimer", ignoreCase = true) ||
                movie.title.contains("Squid", ignoreCase = true) ||
                movie.year == "2026" || movie.year == "2025"
        return _userSubscription.value.getLockReason(
            releaseYear = movie.year,
            isTrendingOrVip = isVipOrBlockbuster,
            isTvDevice = false
        )
    }

    fun listenToFirestoreSubscription(userId: String? = null) {
        try {
            if (FirebaseApp.getApps(getApplication()).isNotEmpty()) {
                val db = FirebaseFirestore.getInstance()
                val currentUser = FirebaseAuth.getInstance().currentUser
                val savedUid = prefs.getString("paired_user_id", null)
                val targetUid = userId ?: currentUser?.uid ?: savedUid ?: return
                if (targetUid == "guest" || (currentUser == null && targetUid == "user_netflix_pro_primary")) return
                // Audit fix: remove the previous listener before adding a new
                // one. Previously this function could be called multiple times
                // (init, signIn, setPairedUser, listenToFirestoreProfiles)
                // without removing the old listener — every call leaked a
                // SnapshotListener. Now we track it in
                // [firestoreSubscriptionListener] and remove it on sign-out
                // and on every re-attach.
                firestoreSubscriptionListener?.remove()
                firestoreSubscriptionListener = db.collection("users").document(targetUid)
                    .collection("subscription").document("current")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            android.util.Log.w("NetflixViewModel", "Firestore subscription listener error: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null && snapshot.exists()) {
                            val rawStatus = snapshot.getString("status") ?: ""
                            val rawPlanId = snapshot.getString("planId") ?: ""
                            // Audit fix: don't coerce a missing plan to
                            // plan_standard + ACTIVE here either. Trust the
                            // server's report verbatim; if it didn't send a
                            // plan, surface that as an unverified state.
                            val sub = com.example.model.UserSubscription(
                                status = rawStatus.ifBlank { "PENDING_ACTIVATION" },
                                planId = rawPlanId,
                                planName = snapshot.getString("planName") ?: "",
                                amount = (snapshot.getLong("amount") ?: 0L).toInt(),
                                currency = snapshot.getString("currency") ?: "KES",
                                paymentReference = snapshot.getString("paymentReference") ?: "",
                                mpesaReceipt = snapshot.getString("mpesaReceipt") ?: "",
                                subscribedAt = snapshot.getLong("subscribedAt") ?: 0L,
                                expiresAt = snapshot.getLong("expiresAt") ?: 0L,
                                renewsAt = snapshot.getLong("renewsAt"),
                                trialEndsAt = snapshot.getLong("trialEndsAt"),
                                startedAt = snapshot.getLong("startedAt") ?: 0L,
                                paymentMethod = snapshot.getString("paymentMethod"),
                                lastVerifiedAt = snapshot.getLong("lastVerifiedAt"),
                                autoRenew = snapshot.getBoolean("autoRenew") ?: true,
                                cancellationReason = snapshot.getString("cancellationReason"),
                                gracePeriodEndsAt = snapshot.getLong("gracePeriodEndsAt")
                            )
                            _userSubscription.value = sub
                            saveStoredSubscription(sub)
                        }
                    }
            }
        } catch (e: Exception) {
            // Audit fix: previously this swallowed all errors silently —
            // a permission-denied or quota-exceeded would leave the UI
            // stuck on stale data with no diagnostic. Now we log at warn
            // level so the issue is visible in logcat.
            android.util.Log.w("NetflixViewModel", "listenToFirestoreSubscription: ${e.message}")
        }
    }

    suspend fun resolveTrailerStream(movie: Movie): com.example.data.TrailerStream? {
        val isTv = movie.type.equals("Series", ignoreCase = true) ||
                movie.type.equals("TV", ignoreCase = true) ||
                movie.duration.contains("Season", ignoreCase = true)
        return kotlinx.coroutines.withTimeoutOrNull(12_000L) {
            withContext(kotlinx.coroutines.Dispatchers.Main.immediate) {
                kotlinx.coroutines.suspendCancellableCoroutine { continuation ->
                    val resolver = com.example.data.TrailerResolver(
                        context = getApplication(),
                        tmdbId = movie.id,
                        mediaType = if (isTv) "tv" else "movie",
                        callback = object : com.example.data.TrailerResolverCallback {
                            override fun onResolved(stream: com.example.data.TrailerStream) {
                                if (continuation.isActive) continuation.resume(stream)
                            }
                            override fun onError(error: String) {
                                android.util.Log.w("NetflixViewModel", "Trailer resolution failed for ${movie.id}: $error")
                                if (continuation.isActive) continuation.resume(null)
                            }
                        }
                    )
                    continuation.invokeOnCancellation { resolver.cancel() }
                    resolver.start()
                }
            }
        }
    }

    private var remoteCommandListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var streamHeartbeatJob: kotlinx.coroutines.Job? = null

    fun listenToRemoteCommands(sessionCode: String) {
        val cleanCode = sessionCode.trim().uppercase()
        if (cleanCode.isBlank()) return
        try {
            if (FirebaseApp.getApps(getApplication()).isNotEmpty()) {
                val db = FirebaseFirestore.getInstance()
                remoteCommandListener?.remove()
                remoteCommandListener = db.collection("tv_sessions").document(cleanCode)
                    .collection("remote_commands").document("latest")
                    .addSnapshotListener { snapshot, error ->
                        if (error == null && snapshot != null && snapshot.exists()) {
                            val cmd = snapshot.getString("command") ?: return@addSnapshotListener
                            val ts = snapshot.getLong("timestamp") ?: 0L
                            if (System.currentTimeMillis() - ts < 10_000L) {
                                executeRemoteCommand(cmd)
                            }
                        }
                    }
            }
        } catch (_: Exception) {}
    }

    private fun executeRemoteCommand(cmd: String) {
        val player = activePlayer ?: sharedExoPlayer
        when (cmd.uppercase()) {
            "PLAY" -> player.play()
            "PAUSE" -> player.pause()
            "SEEK_FORWARD" -> player.seekTo(player.currentPosition + 10_000L)
            "SEEK_BACKWARD" -> player.seekTo((player.currentPosition - 10_000L).coerceAtLeast(0L))
            "STOP" -> player.stop()
        }
    }

    fun startStreamHeartbeat(mediaTitle: String) {
        val targetUid = prefs.getString("paired_user_id", null) ?: return
        val deviceId = prefs.getString("tv_device_id", null) ?: "tv_${System.currentTimeMillis()}".also {
            prefs.edit().putString("tv_device_id", it).apply()
        }
        streamHeartbeatJob?.cancel()
        streamHeartbeatJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                try {
                    if (FirebaseApp.getApps(getApplication()).isNotEmpty()) {
                        val db = FirebaseFirestore.getInstance()
                        val data = hashMapOf(
                            "deviceId" to deviceId,
                            "deviceName" to "Android TV",
                            "mediaTitle" to mediaTitle,
                            "lastHeartbeat" to System.currentTimeMillis()
                        )
                        // active_streams is not in the policy map (it's
                        // a write-only ephemeral collection, not a
                        // conflict domain). The policy check returns
                        // true for any unknown field, so the write
                        // proceeds. We still log the policy lookup so a
                        // future schema change that DOES add a
                        // SERVER_ONLY field to active_streams (e.g.
                        // "isBillable") is caught by the existing
                        // log line.
                        ConflictResolver.policyFor(Collections.ACTIVE_STREAMS, "lastHeartbeat")
                            ?: android.util.Log.d(
                                "Sync",
                                "policy=DEFAULT_WRITE field=lastHeartbeat collection=active_streams"
                            )
                        db.collection("users").document(targetUid).collection(Collections.ACTIVE_STREAMS).document(deviceId)
                            .set(data, SetOptions.merge())
                    }
                } catch (_: Exception) {}
                kotlinx.coroutines.delay(20_000L)
            }
        }
    }

    fun stopStreamHeartbeat() {
        streamHeartbeatJob?.cancel()
        val targetUid = prefs.getString("paired_user_id", null) ?: return
        val deviceId = prefs.getString("tv_device_id", null) ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (FirebaseApp.getApps(getApplication()).isNotEmpty()) {
                    FirebaseFirestore.getInstance().collection("users").document(targetUid)
                        .collection("active_streams").document(deviceId).delete()
                }
            } catch (_: Exception) {}
        }
    }

    private var lastFirestoreSyncTimestamp = 0L

    fun savePlaybackProgress(
        movie: Movie,
        positionMs: Long,
        durationMs: Long,
        season: Int = 1,
        episode: Int = 1,
        episodeName: String = "",
        forceFirestoreSync: Boolean = false
    ) {
        val profileId = _selectedProfile.value?.id ?: "default"
        // Clamp positionMs to a sane range. A buggy stream manifest can
        // report positionMs > durationMs * 2, which makes `isCompleted`
        // true and forces the row out of Continue Watching before the user
        // is anywhere near the end. The previous code passed the value
        // through verbatim and got the wrong answer.
        val safePosition = when {
            positionMs < 0L -> 0L
            durationMs > 0L && positionMs > durationMs -> durationMs
            else -> positionMs
        }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                continueWatchingRepository.saveProgress(profileId, movie, safePosition, durationMs, season, episode, episodeName)
            } catch (e: Exception) {
                // Repository already swallows, but defensively double-catch
                // so a DB failure never crashes the player.
                android.util.Log.e("NetflixViewModel", "saveProgress threw", e)
            }

            val now = System.currentTimeMillis()
            val isCompleted = (durationMs > 0 && (safePosition >= durationMs - 30_000L || safePosition >= (durationMs * 0.95)))
            if (forceFirestoreSync || isCompleted || (now - lastFirestoreSyncTimestamp >= 15_000L)) {
                lastFirestoreSyncTimestamp = now
                syncWatchProgressToFirestore(profileId, movie, safePosition, durationMs, season, episode, episodeName)
            }

            // Update Android TV system-wide "Play Next" row.
            try {
                if (isCompleted) {
                    if (movie.type.equals("Series", ignoreCase = true)) {
                        com.example.tv.TvHomeChannelManager.updateWatchNextProgram(
                            context = getApplication(),
                            movie = movie,
                            positionMs = 0L,
                            durationMs = durationMs,
                            season = season,
                            episode = episode + 1,
                            isNextEpisode = true,
                            forceUpdate = true
                        )
                    } else {
                        com.example.tv.TvHomeChannelManager.removeWatchNextProgram(getApplication(), movie.id)
                    }
                } else if (safePosition > 10_000L) {
                    com.example.tv.TvHomeChannelManager.updateWatchNextProgram(
                        context = getApplication(),
                        movie = movie,
                        positionMs = safePosition,
                        durationMs = durationMs,
                        season = season,
                        episode = episode,
                        isNextEpisode = false
                    )
                }
            } catch (_: Exception) {}
        }
    }

    private suspend fun syncWatchProgressToFirestore(
        profileId: String,
        movie: Movie,
        positionMs: Long,
        durationMs: Long,
        season: Int,
        episode: Int,
        episodeName: String
    ) {
        try {
            if (FirebaseApp.getApps(getApplication()).isNotEmpty()) {
                val db = FirebaseFirestore.getInstance()
                val targetUid = prefs.getString("paired_user_id", null) ?: "user_netflix_pro_primary"
                val docId = "${profileId}_${movie.id}"

                val isNearEnd = durationMs > 0 && (positionMs >= (durationMs * 0.95) || (durationMs - positionMs) <= 30000L)
                val isCompleted = isNearEnd && !movie.type.equals("Series", ignoreCase = true)

                val flatDocRef = db.collection("users").document(targetUid).collection(Collections.CONTINUE_WATCHING_FLAT).document(docId)
                val profileNestedDocRef1 = db.collection("users").document(targetUid).collection(Collections.PROFILES).document(profileId).collection(Collections.CONTINUE_WATCHING_FLAT).document(movie.id)
                val profileNestedDocRef2 = db.collection("users").document(targetUid).collection(Collections.PROFILES).document(profileId).collection(Collections.CONTINUE_WATCHING).document(movie.id)

                // Audit fix: combine the three writes (or deletes) into a single
                // batched commit. The previous implementation fired three
                // independent round-trips and dropped all of them on the first
                // network error, leaving the same progress doc out-of-sync across
                // paths. A single batched commit is atomic on success and uses
                // one network round-trip instead of three.
                val batch = db.batch()

                if (isCompleted) {
                    batch.delete(flatDocRef)
                    batch.delete(profileNestedDocRef1)
                    batch.delete(profileNestedDocRef2)
                    // Offline-first outbox: persist a single batch row
                    // describing the three deletes so the worker can replay
                    // them if the direct commit below fails (or the app is
                    // force-killed between commit and ack). The direct
                    // commit still runs first; the row is marked done on
                    // success.
                    val deleteBatchPayload = SyncScheduler.encodeBatchPayload(
                        listOf(
                            SyncScheduler.batchDelete(
                                collection = "users/$targetUid/${Collections.CONTINUE_WATCHING_FLAT}",
                                documentId = docId
                            ),
                            SyncScheduler.batchDelete(
                                collection = "users/$targetUid/${Collections.PROFILES}/$profileId/${Collections.CONTINUE_WATCHING_FLAT}",
                                documentId = movie.id
                            ),
                            SyncScheduler.batchDelete(
                                collection = "users/$targetUid/${Collections.PROFILES}/$profileId/${Collections.CONTINUE_WATCHING}",
                                documentId = movie.id
                            )
                        )
                    )
                    val deleteRowId = SyncScheduler.enqueueWrite(
                        context = getApplication(),
                        dao = pendingWriteDao,
                        collection = "users",
                        documentId = targetUid,
                        operation = com.example.data.PendingWrite.OP_BATCH,
                        payload = deleteBatchPayload
                    )
                    try {
                        batch.commit().await()
                        pendingWriteDao.markDone(deleteRowId, System.currentTimeMillis())
                    } catch (directErr: Exception) {
                        android.util.Log.w(
                            "NetflixViewModel",
                            "Direct delete watch-progress sync failed, will retry via outbox row=$deleteRowId: ${directErr.message}"
                        )
                    }
                    return
                }

                // Policy gate: positionMs is MAX_WINS. The client must
                // read the remote value first, take the max, then write.
                // Without this read-then-max step, a naive last-write-wins
                // would lose progress when a user has been watching on
                // another device (see SyncStrategy.CONTINUE_WATCHING
                // docs for the full scenario).
                val remoteFlat = try {
                    flatDocRef.get().await()
                } catch (_: Exception) { null }
                val remoteNested = try {
                    profileNestedDocRef1.get().await()
                } catch (_: Exception) { null }
                val remotePos = listOfNotNull(remoteFlat, remoteNested)
                    .mapNotNull { doc ->
                        // accept the multiple field names the schema
                        // has historically used
                        doc.getLong("positionMs")
                            ?: doc.getLong("playbackPositionMs")
                            ?: doc.getLong("positionSeconds")?.let { it * 1000L }
                    }
                    .maxOrNull() ?: 0L
                val resolvedPositionMs = (ConflictResolver.resolve(
                    collection = Collections.CONTINUE_WATCHING,
                    field = "positionMs",
                    localValue = positionMs,
                    remoteValue = remotePos
                ) as? Long) ?: positionMs
                val resolvedDurationMs = (ConflictResolver.resolve(
                    collection = Collections.CONTINUE_WATCHING,
                    field = "durationMs",
                    localValue = durationMs,
                    // SERVER_WINS — the server's canonical duration wins,
                    // but we don't have it client-side so pass our local
                    // value (the server will overwrite if needed).
                    remoteValue = durationMs
                ) as? Long) ?: durationMs
                android.util.Log.d(
                    "Sync",
                    "syncWatchProgress: movieId=${movie.id} profileId=$profileId " +
                        "localPos=$positionMs remotePos=$remotePos " +
                        "resolvedPos=$resolvedPositionMs"
                )

                val positionSeconds = (resolvedPositionMs / 1000L).toInt()
                val durationSeconds = (resolvedDurationMs / 1000L).toInt()
                val progressPercent = if (resolvedDurationMs > 0) ((resolvedPositionMs.toFloat() / resolvedDurationMs.toFloat()) * 100f).coerceIn(0f, 100f) else 0f

                val data = hashMapOf<String, Any>(
                    "profileId" to profileId,
                    "mediaId" to movie.id,
                    "movieId" to movie.id,
                    "id" to movie.id,
                    "positionSeconds" to positionSeconds,
                    "totalSeconds" to durationSeconds,
                    "durationSeconds" to durationSeconds,
                    "playbackPositionMs" to resolvedPositionMs,
                    "positionMs" to resolvedPositionMs,
                    "durationMs" to resolvedDurationMs,
                    "progressPercent" to progressPercent,
                    "lastWatchedTimestamp" to System.currentTimeMillis(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                    "isCompleted" to false,
                    "episodeId" to "s${season}_e${episode}",
                    "episodeTitle" to episodeName,
                    "episodeName" to episodeName,
                    "season" to season,
                    "episode" to episode,
                    "title" to movie.title,
                    "name" to movie.title,
                    "mediaTitle" to movie.title,
                    "description" to movie.description,
                    "backdropUrl" to movie.backdropUrl,
                    "posterUrl" to movie.posterUrl,
                    "rating" to movie.rating,
                    "year" to movie.year,
                    "type" to movie.type,
                    "duration" to movie.duration,
                    "logoUrl" to (movie.logoUrl ?: ""),
                    "syncedFromDevice" to "Android TV"
                )

                // Filter the write map against the policy. None of the
                // continue_watching fields are SERVER_ONLY, but the
                // SERVER_WINS fields (durationMs, season, episode,
                // lastUpdatedAt) get a debug log so a misuse is visible.
                val filtered = ConflictResolver.filterWritable(Collections.CONTINUE_WATCHING, data)
                batch.set(flatDocRef, filtered, SetOptions.merge())
                batch.set(profileNestedDocRef1, filtered, SetOptions.merge())
                batch.set(profileNestedDocRef2, filtered, SetOptions.merge())
                // Offline-first outbox: build a batch descriptor that
                // replays the same three writes on the worker side if
                // needed. FieldValue.serverTimestamp() is preserved as a
                // {"__serverTimestamp": true} sentinel in the JSON payload
                // — the worker unwraps it back to FieldValue on commit.
                val outboxData = filtered.mapValues { (_, v) ->
                    if (v is FieldValue) mapOf("__serverTimestamp" to true) else v
                }
                val batchPayload = SyncScheduler.encodeBatchPayload(
                    listOf(
                        SyncScheduler.batchUpdate(
                            collection = "users/$targetUid/${Collections.CONTINUE_WATCHING_FLAT}",
                            documentId = docId,
                            data = outboxData
                        ),
                        SyncScheduler.batchUpdate(
                            collection = "users/$targetUid/${Collections.PROFILES}/$profileId/${Collections.CONTINUE_WATCHING_FLAT}",
                            documentId = movie.id,
                            data = outboxData
                        ),
                        SyncScheduler.batchUpdate(
                            collection = "users/$targetUid/${Collections.PROFILES}/$profileId/${Collections.CONTINUE_WATCHING}",
                            documentId = movie.id,
                            data = outboxData
                        )
                    )
                )
                val batchRowId = SyncScheduler.enqueueWrite(
                    context = getApplication(),
                    dao = pendingWriteDao,
                    collection = "users",
                    documentId = targetUid,
                    operation = com.example.data.PendingWrite.OP_BATCH,
                    payload = batchPayload
                )
                try {
                    batch.commit().await()
                    pendingWriteDao.markDone(batchRowId, System.currentTimeMillis())
                } catch (directErr: Exception) {
                    android.util.Log.w(
                        "NetflixViewModel",
                        "Direct watch-progress sync failed, will retry via outbox row=$batchRowId: ${directErr.message}"
                    )
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("NetflixViewModel", "Error syncing watch progress to Firestore: ${e.message}")
        }
    }

    fun deletePlaybackProgress(movieId: String) {
        val profileId = _selectedProfile.value?.id ?: "default"
        viewModelScope.launch(Dispatchers.IO) {
            continueWatchingRepository.deleteProgress(profileId, movieId)
            try {
                com.example.tv.TvHomeChannelManager.removeWatchNextProgram(getApplication(), movieId)
            } catch (_: Exception) {}
            try {
                if (FirebaseApp.getApps(getApplication()).isNotEmpty()) {
                    val db = FirebaseFirestore.getInstance()
                    val targetUid = prefs.getString("paired_user_id", null) ?: "user_netflix_pro_primary"
                    val docId = "${profileId}_${movieId}"
                    // Audit fix: combine the three deletes into a single batched
                    // commit. The previous implementation fired three independent
                    // round-trips (one per path) and dropped all of them on a
                    // single network error, leaving the same progress doc stuck
                    // on two of the three paths. Batches are atomic on success.
                    // Policy gate: deletes bypass per-field policy (a delete
                    // is a row-level operation), but we log the policy lookup
                    // so the audit trail captures the action.
                    android.util.Log.d(
                        "Sync",
                        "policy=DELETE_OP collection=continueWatching movieId=$movieId"
                    )
                    val batch = db.batch()
                    val flatRef = db.collection("users").document(targetUid)
                        .collection(Collections.CONTINUE_WATCHING_FLAT).document(docId)
                    val nestedRef1 = db.collection("users").document(targetUid)
                        .collection(Collections.PROFILES).document(profileId)
                        .collection(Collections.CONTINUE_WATCHING_FLAT).document(movieId)
                    val nestedRef2 = db.collection("users").document(targetUid)
                        .collection(Collections.PROFILES).document(profileId)
                        .collection(Collections.CONTINUE_WATCHING).document(movieId)
                    batch.delete(flatRef)
                    batch.delete(nestedRef1)
                    batch.delete(nestedRef2)
                    // Offline-first outbox: enqueue a batch row describing
                    // the three deletes. The direct commit runs first; the
                    // row is marked done on success. If the commit fails
                    // (or the device dies mid-call), the
                    // PendingWriteRetryWorker replays the same deletes.
                    val deleteBatchPayload = SyncScheduler.encodeBatchPayload(
                        listOf(
                            SyncScheduler.batchDelete(
                                collection = "users/$targetUid/${Collections.CONTINUE_WATCHING_FLAT}",
                                documentId = docId
                            ),
                            SyncScheduler.batchDelete(
                                collection = "users/$targetUid/${Collections.PROFILES}/$profileId/${Collections.CONTINUE_WATCHING_FLAT}",
                                documentId = movieId
                            ),
                            SyncScheduler.batchDelete(
                                collection = "users/$targetUid/${Collections.PROFILES}/$profileId/${Collections.CONTINUE_WATCHING}",
                                documentId = movieId
                            )
                        )
                    )
                    val rowId = SyncScheduler.enqueueWrite(
                        context = getApplication(),
                        dao = pendingWriteDao,
                        collection = "users",
                        documentId = targetUid,
                        operation = com.example.data.PendingWrite.OP_BATCH,
                        payload = deleteBatchPayload
                    )
                    try {
                        batch.commit().await()
                        pendingWriteDao.markDone(rowId, System.currentTimeMillis())
                    } catch (directErr: Exception) {
                        android.util.Log.w(
                            "NetflixViewModel",
                            "Direct delete-playback sync failed, will retry via outbox row=$rowId: ${directErr.message}"
                        )
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w("NetflixViewModel", "Error deleting playback progress from Firestore: ${e.message}")
            }
        }
    }

    suspend fun getPlaybackProgress(movieId: String): Long {
        val profileId = _selectedProfile.value?.id ?: "default"
        val local = continueWatchingRepository.getContinueWatchingById(profileId, movieId)
        if (local != null && local.playbackPositionMs > 0L) {
            return local.playbackPositionMs
        }
        val remote = getContinueWatching(movieId)
        return remote?.playbackPositionMs ?: 0L
    }

    suspend fun getContinueWatching(movieId: String): ContinueWatchingEntity? {
        val profileId = _selectedProfile.value?.id ?: "default"
        val local = continueWatchingRepository.getContinueWatchingById(profileId, movieId)
        if (local != null) return local

        return withContext(Dispatchers.IO) {
            try {
                if (FirebaseApp.getApps(getApplication()).isNotEmpty()) {
                    val db = FirebaseFirestore.getInstance()
                    val targetUid = prefs.getString("paired_user_id", null) ?: "user_netflix_pro_primary"
                    val docId = "${profileId}_${movieId}"

                    // Audit fix: fan-out the three path lookups in parallel via
                    // coroutineScope + async, then take the first non-null. The
                    // previous implementation awaited sequentially (3 round-trips
                    // on the slow path); the new path issues all three reads at
                    // once and only waits for the slowest.
                    val doc = coroutineScope {
                        val flat = async(Dispatchers.IO) {
                            try {
                                db.collection("users").document(targetUid)
                                    .collection("continue_watching").document(docId)
                                    .get().await()
                            } catch (_: Exception) { null }
                        }
                        val nested1 = async(Dispatchers.IO) {
                            try {
                                db.collection("users").document(targetUid)
                                    .collection("profiles").document(profileId)
                                    .collection("continue_watching").document(movieId)
                                    .get().await()
                            } catch (_: Exception) { null }
                        }
                        val nested2 = async(Dispatchers.IO) {
                            try {
                                db.collection("users").document(targetUid)
                                    .collection("profiles").document(profileId)
                                    .collection("continueWatching").document(movieId)
                                    .get().await()
                            } catch (_: Exception) { null }
                        }
                        listOf(flat, nested1, nested2)
                            .map { it.await() }
                            .firstOrNull { it != null && it.exists() }
                    }

                    if (doc != null && doc.exists()) {
                        val posSec = (doc.getLong("positionSeconds") ?: 0L)
                        val posMs = doc.getLong("playbackPositionMs") ?: doc.getLong("positionMs") ?: (posSec * 1000L)
                        val durSec = (doc.getLong("totalSeconds") ?: doc.getLong("durationSeconds") ?: 0L)
                        val durMs = doc.getLong("durationMs") ?: (durSec * 1000L)
                        val timestamp = doc.getLong("lastWatchedTimestamp") ?: System.currentTimeMillis()
                        val season = (doc.getLong("season") ?: 1L).toInt()
                        val episode = (doc.getLong("episode") ?: 1L).toInt()
                        val episodeName = doc.getString("episodeTitle") ?: doc.getString("episodeName") ?: ""

                        val title = doc.getString("title") ?: doc.getString("name") ?: doc.getString("mediaTitle") ?: "Title"
                        val description = doc.getString("description") ?: ""
                        val backdropUrl = doc.getString("backdropUrl") ?: ""
                        val posterUrl = doc.getString("posterUrl") ?: ""
                        val rating = doc.getString("rating") ?: "13+"
                        val year = doc.getString("year") ?: "2024"
                        val type = doc.getString("type") ?: "Series"
                        val duration = doc.getString("duration") ?: ""
                        val logoUrl = doc.getString("logoUrl")

                        val entity = ContinueWatchingEntity(
                            profileId = profileId,
                            movieId = movieId,
                            title = title,
                            description = description,
                            backdropUrl = backdropUrl,
                            posterUrl = posterUrl,
                            rating = rating,
                            year = year,
                            type = type,
                            duration = duration,
                            playbackPositionMs = posMs,
                            durationMs = durMs,
                            lastWatchedTimestamp = timestamp,
                            season = season,
                            episode = episode,
                            episodeName = episodeName,
                            logoUrl = logoUrl
                        )

                        if (durMs > 0L && posMs > 1000L) {
                            continueWatchingRepository.saveProgress(profileId, entity.toMovie(), posMs, durMs, season, episode, episodeName)
                        }
                        return@withContext entity
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w("NetflixViewModel", "Error fetching continue watching from Firestore: ${e.message}")
            }
            null
        }
    }

    fun getCachedLogo(movieId: String): String? {
        return repository.getCachedLogo(movieId)
    }

    suspend fun fetchLogoUrl(movieId: String, isTv: Boolean): String? {
        return repository.fetchLogoUrl(movieId.toLongOrNull() ?: 0L, isTv)
    }

    suspend fun getEpisodes(tvId: Long, seasonNumber: Int = 1): List<com.example.model.Episode> {
        return repository.getTvSeasonEpisodes(tvId, seasonNumber)
    }

    suspend fun getTvSeasons(tvId: Long): List<Int> {
        return repository.getTvSeasons(tvId)
    }

    fun extractPairingCode(input: String): String {
        var text = input.trim()
        if (text.contains("code=", ignoreCase = true)) {
            val codeParam = text.substringAfter("code=", "").substringBefore("&").substringBefore("#")
            if (codeParam.isNotBlank()) {
                text = codeParam
            }
        }
        if (text.contains("://") || text.contains("/")) {
            text = text.substringAfterLast("/")
        }
        return text.replace("/", "").replace("\\", "").trim().uppercase()
    }

    fun pairTvSession(rawCode: String, onResult: (Boolean) -> Unit) {
        val cleanCode = extractPairingCode(rawCode)
        if (cleanCode.isBlank()) {
            onResult(false)
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (FirebaseApp.getApps(getApplication()).isNotEmpty()) {
                    val db = FirebaseFirestore.getInstance()
                    // Audit fix: previously the email was hardcoded to a
                    // placeholder ("member@netflix.pro") regardless of which
                    // account was actually signed in. Use the stored account
                    // email from prefs so the phone-side scanner sees the real
                    // account, and only fall back to the placeholder when no
                    // account is paired (the TV should not have entered the
                    // pairing flow in that case, but we keep a safe fallback).
                    val storedEmail = prefs.getString("user_email", null)
                    val userEmail = when {
                        !storedEmail.isNullOrBlank() && storedEmail != "guest" -> storedEmail
                        else -> "member@netflix.pro"
                    }
                    val targetUid = prefs.getString("paired_user_id", null) ?: "user_netflix_pro_primary"
                    val profilesList = _profiles.value
                    val jsonArr = JSONArray()
                    profilesList.forEach { p ->
                        val obj = JSONObject()
                        obj.put("id", p.id)
                        obj.put("name", p.name)
                        obj.put("avatarUrl", p.avatarUrl)
                        obj.put("isKids", p.isKid)
                        jsonArr.put(obj)
                    }

                    val sessionData = mapOf(
                        "sessionCode" to cleanCode,
                        "status" to "PAIRED",
                        "userEmail" to userEmail,
                        "userId" to targetUid,
                        "profilesJson" to jsonArr.toString(),
                        "pairedAt" to FieldValue.serverTimestamp()
                    )
                    // Policy gate: `userEmail`, `userId`, `pairedAt` are
                    // SERVER_ONLY in the policy map (they're stamped at
                    // pairing and never changed). For the initial
                    // pairing write we explicitly allow them by
                    // filtering only the legacy fields that the policy
                    // doesn't know about. The session doc is a special
                    // case: the pairing write IS the server-side
                    // "create" event, so it's allowed to populate the
                    // SERVER_ONLY fields on first insert. Subsequent
                    // updates (e.g. lastSeenAt) are NOT allowed to
                    // touch them.
                    android.util.Log.d(
                        "Sync",
                        "policy=PAIRING_CREATE collection=tvSessions sessionCode=$cleanCode"
                    )
                    db.collection(Collections.TV_SESSIONS).document(cleanCode)
                        .set(sessionData, SetOptions.merge())
                        .await()
                    onResult(true)
                } else {
                    onResult(false)
                }
            } catch (e: Exception) {
                android.util.Log.e("NetflixViewModel", "Error pairing TV session: ${e.message}")
                onResult(false)
            }
        }
    }
}
