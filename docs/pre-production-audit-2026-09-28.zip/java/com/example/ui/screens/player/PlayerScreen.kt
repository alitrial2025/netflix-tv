package com.example.ui.screens.player

import android.net.Uri
import android.view.KeyEvent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.model.Movie
import com.example.ui.NetflixViewModel
import com.example.ui.screens.PlaybackMarkers
import com.example.ui.screens.SubtitleMarkerDetector
import com.example.ui.screens.ThumbnailCue
import com.example.ui.screens.ThumbnailParser
import com.example.ui.theme.NetflixBlack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.data.toNetMirrorStream

@OptIn(androidx.media3.common.util.UnstableApi::class)
private fun Throwable.playbackHttpResponseCode(): Int? {
    var current: Throwable? = this
    val visited = java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Throwable, Boolean>())
    while (current != null && visited.add(current)) {
        if (current is HttpDataSource.InvalidResponseCodeException) return current.responseCode
        current = current.cause
    }
    return null
}

@OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun PlayerScreen(
    movie: Movie,
    season: Int = 1,
    episode: Int = 1,
    episodeName: String = "",
    onBack: () -> Unit,
    viewModel: NetflixViewModel
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var currentSeason by remember(movie.id, season) { mutableIntStateOf(season) }
    var currentEpisode by remember(movie.id, season, episode) { mutableIntStateOf(episode) }
    var currentEpisodeName by remember(movie.id, season, episode, episodeName) { mutableStateOf(episodeName) }

    var playbackMarkers by remember(movie.id, currentSeason, currentEpisode) { mutableStateOf(PlaybackMarkers()) }
    var thumbnailCues by remember(movie.id, currentSeason, currentEpisode) { mutableStateOf<List<ThumbnailCue>>(emptyList()) }

    var isPlaying by remember(movie.id, currentSeason, currentEpisode) { mutableStateOf(true) }
    var showControls by remember(movie.id, currentSeason, currentEpisode) { mutableStateOf(true) }
    var lastActivityTime by remember(movie.id, currentSeason, currentEpisode) { mutableLongStateOf(System.currentTimeMillis()) }

    val exoPlayer = viewModel.sharedExoPlayer
    val initialTargetMediaId = "${movie.id}_${currentSeason}_${currentEpisode}"
    val isAlreadyWarm = remember(movie.id, currentSeason, currentEpisode) {
        try {
            val currId = exoPlayer.currentMediaItem?.mediaId
            val state = exoPlayer.playbackState
            (currId == initialTargetMediaId || currId == "${movie.id}_preview") &&
                    (state == Player.STATE_READY || state == Player.STATE_BUFFERING)
        } catch (_: Exception) {
            false
        }
    }

    var isLoading by remember(movie.id, currentSeason, currentEpisode) { mutableStateOf(!isAlreadyWarm) }
    var isBuffering by remember(movie.id, currentSeason, currentEpisode) {
        mutableStateOf(try { exoPlayer.playbackState == Player.STATE_BUFFERING } catch (_: Exception) { false })
    }
    var playbackError by remember(movie.id, currentSeason, currentEpisode) { mutableStateOf<String?>(null) }
    var loadAttempt by remember(movie.id, currentSeason, currentEpisode) { mutableIntStateOf(0) }
    var sessionRecoveryAttempts by remember(movie.id, currentSeason, currentEpisode) { mutableIntStateOf(0) }
    var trailerFallbackAttempted by remember(movie.id, currentSeason, currentEpisode) { mutableStateOf(false) }
    var pendingResumePositionMs by remember(movie.id, currentSeason, currentEpisode) { mutableStateOf<Long?>(null) }
    val fallbackJobHolder = remember(movie.id, currentSeason, currentEpisode) {
        object { var job: Job? = null }
    }

    var showSubtitleModal by remember { mutableStateOf(false) }
    val selectedSubLang by viewModel.selectedSubtitleLanguage.collectAsStateWithLifecycle()
    var activeStream by remember(movie.id, currentSeason, currentEpisode) {
        mutableStateOf(viewModel.getCachedStream(movie, currentSeason, currentEpisode))
    }
    var logoUrl by remember(movie) { mutableStateOf(movie.logoUrl) }
    val isLoggedIn = viewModel.isUserLoggedIn()

    var currentSubtitleCues by remember(movie.id, currentSeason, currentEpisode) { mutableStateOf<List<SubtitleCue>>(emptyList()) }
    var exoPlayerSubtitleText by remember(movie.id, currentSeason, currentEpisode) { mutableStateOf("") }
    var playerTracks by remember(exoPlayer) { mutableStateOf(exoPlayer.currentTracks) }

    fun restartPlaybackResolution() {
        fallbackJobHolder.job?.cancel()
        fallbackJobHolder.job = null
        val positionMs = runCatching { exoPlayer.currentPosition }.getOrDefault(0L)
        if (positionMs > 0L) pendingResumePositionMs = positionMs
        try { exoPlayer.stop() } catch (_: Exception) {}
        try { exoPlayer.clearMediaItems() } catch (_: Exception) {}
        activeStream = null
        currentSubtitleCues = emptyList()
        exoPlayerSubtitleText = ""
        trailerFallbackAttempted = false
        playbackError = null
        isBuffering = false
        isLoading = true
        loadAttempt += 1
    }

    val mainPlayerRequester = remember { FocusRequester() }
    val playButtonRequester = remember { FocusRequester() }
    val progressRequester = remember { FocusRequester() }

    var isExitProgressSaved by remember { mutableStateOf(false) }
    fun safeSaveAndExit() {
        if (!isExitProgressSaved) {
            isExitProgressSaved = true
            val (safePos, safeDur) = try {
                exoPlayer.currentPosition to exoPlayer.duration
            } catch (_: Exception) {
                0L to 0L
            }
            if (safeDur > 0L) {
                viewModel.savePlaybackProgress(
                    movie = movie,
                    positionMs = safePos,
                    durationMs = safeDur,
                    season = currentSeason,
                    episode = currentEpisode,
                    episodeName = currentEpisodeName,
                    forceFirestoreSync = true
                )
            }
            try { exoPlayer.pause() } catch (_: Exception) {}
        }
        onBack()
    }

    val nextEpisodeJobHolder = remember(movie.id) { object { var job: kotlinx.coroutines.Job? = null } }
    fun playNextEpisode() {
        val movieIdLong = movie.id.toLongOrNull() ?: 0L
        if (nextEpisodeJobHolder.job?.isActive == true) return
        nextEpisodeJobHolder.job = coroutineScope.launch {
            isLoading = true
            val (positionMs, durationMs) = try {
                exoPlayer.currentPosition to exoPlayer.duration
            } catch (_: Exception) {
                0L to 0L
            }
            if (durationMs > 0L) {
                viewModel.savePlaybackProgress(
                    movie = movie,
                    positionMs = positionMs,
                    durationMs = durationMs,
                    season = currentSeason,
                    episode = currentEpisode,
                    episodeName = currentEpisodeName,
                    forceFirestoreSync = true
                )
            }
            currentSubtitleCues = emptyList()
            exoPlayerSubtitleText = ""
            activeStream = null
            isLoading = true

            val nextEpNum = currentEpisode + 1
            if (movieIdLong > 0L) {
                val episodesList = withContext(Dispatchers.IO) { viewModel.getEpisodes(movieIdLong, currentSeason) }
                val nextEp = episodesList.find { it.episodeNumber == nextEpNum }
                if (nextEp != null) {
                    currentEpisode = nextEpNum
                    currentEpisodeName = nextEp.title
                } else {
                    val nextSeasonNum = currentSeason + 1
                    val nextSeasonEps = withContext(Dispatchers.IO) { viewModel.getEpisodes(movieIdLong, nextSeasonNum) }
                    val firstEp = nextSeasonEps.find { it.episodeNumber == 1 }
                    if (firstEp != null) {
                        currentSeason = nextSeasonNum
                        currentEpisode = 1
                        currentEpisodeName = firstEp.title
                    } else {
                        safeSaveAndExit()
                    }
                }
            } else {
                currentEpisode = nextEpNum
                currentEpisodeName = "Episode $nextEpNum"
            }
        }
    }

    fun userActivity() {
        showControls = true
        lastActivityTime = System.currentTimeMillis()
    }

    LaunchedEffect(movie.id) {
        if (logoUrl.isNullOrBlank()) {
            val isTv = movie.type == "Series"
            val fetchedLogo = withContext(Dispatchers.IO) { viewModel.fetchLogoUrl(movie.id, isTv) }
            if (!fetchedLogo.isNullOrBlank()) {
                logoUrl = fetchedLogo
            }
        }
    }

    DisposableEffect(exoPlayer, movie.id, currentSeason, currentEpisode, selectedSubLang, loadAttempt) {
        val listenerSeason = currentSeason
        val listenerEpisode = currentEpisode
        val listenerMediaId = "${movie.id}_${listenerSeason}_${listenerEpisode}"
        fun ownsCurrentMedia(): Boolean {
            if (currentSeason != listenerSeason || currentEpisode != listenerEpisode) return false
            val mediaId = runCatching { exoPlayer.currentMediaItem?.mediaId }.getOrNull()
            return mediaId == listenerMediaId || mediaId == "${movie.id}_preview"
        }
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = (playbackState == Player.STATE_BUFFERING)
                if (playbackState == Player.STATE_READY) {
                    isLoading = false
                    val durationMs = try { exoPlayer.duration } catch (_: Exception) { 0L }
                    if (durationMs in 535000L..545000L && ownsCurrentMedia()) {
                        fallbackJobHolder.job?.cancel()
                        viewModel.evictCachedStream(movie, listenerSeason, listenerEpisode)
                        playbackError = "Playback is temporarily rate limited.\nPlease wait and press Retry."
                        try { exoPlayer.stop() } catch (_: Exception) {}
                        try { exoPlayer.clearMediaItems() } catch (_: Exception) {}
                        activeStream = null
                    }
                }
            }
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
            override fun onCues(cueGroup: androidx.media3.common.text.CueGroup) {
                if (!selectedSubLang.equals("Off", ignoreCase = true)) {
                    val cues = cueGroup.cues
                    if (cues.isNotEmpty()) {
                        val text = cues.mapNotNull { it.text?.toString() }
                            .filter { it.isNotBlank() }
                            .joinToString("\n")
                        exoPlayerSubtitleText = text
                    } else {
                        exoPlayerSubtitleText = ""
                    }
                } else {
                    exoPlayerSubtitleText = ""
                }
            }
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                playerTracks = tracks
                updateExoPlayerTrackSelection(exoPlayer, selectedSubLang)
                var hasSelectedAudio = false
                for (group in tracks.groups) {
                    if (group.type == androidx.media3.common.C.TRACK_TYPE_AUDIO && group.isSelected) {
                        hasSelectedAudio = true
                        break
                    }
                }
                if (!hasSelectedAudio) {
                    for (group in tracks.groups) {
                        if (group.type == androidx.media3.common.C.TRACK_TYPE_AUDIO && group.isSupported) {
                            for (i in 0 until group.length) {
                                if (group.isTrackSupported(i)) {
                                    try {
                                        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                            .buildUpon()
                                            .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_AUDIO, false)
                                            .setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, i))
                                            .build()
                                    } catch (_: Exception) {}
                                    return
                                }
                            }
                        }
                    }
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                if (!ownsCurrentMedia()) return
                isLoading = false
                isBuffering = false
                android.util.Log.e("PlayerScreen", "Playback failed: ${error.errorCodeName} (${error.errorCode})", error)
                fallbackJobHolder.job?.cancel()
                val responseCode = error.playbackHttpResponseCode()
                if (responseCode == 429) {
                    // Rate limits require waiting; refreshing authentication would
                    // turn one playback request into another rejected request.
                    viewModel.evictCachedStream(movie, listenerSeason, listenerEpisode)
                    try { exoPlayer.stop() } catch (_: Exception) {}
                    try { exoPlayer.clearMediaItems() } catch (_: Exception) {}
                    activeStream = null
                    playbackError = "Playback is temporarily rate limited.\nPlease wait and press Retry."
                    return
                }
                if (responseCode == 401 || responseCode == 403) {
                    // A signed stream and its cookies expire together. Reusing the
                    // raw URL with the same headers cannot recover an auth failure.
                    viewModel.reportBadSession(activeStream?.headers?.get("Cookie"))
                    viewModel.invalidateStream(movie, listenerSeason, listenerEpisode)
                    if (sessionRecoveryAttempts < 1) {
                        sessionRecoveryAttempts += 1
                        restartPlaybackResolution()
                    } else {
                        try { exoPlayer.stop() } catch (_: Exception) {}
                        try { exoPlayer.clearMediaItems() } catch (_: Exception) {}
                        activeStream = null
                        playbackError = "This title could not be played."
                    }
                    return
                }
                val failedStream = activeStream
                val failedHeaders = failedStream?.headers.orEmpty()
                fallbackJobHolder.job = coroutineScope.launch {
                    val rawUrl = failedStream?.rawVideoUrl
                    val currUri = try { exoPlayer.currentMediaItem?.localConfiguration?.uri?.toString() } catch (_: Exception) { null }
                    if (!rawUrl.isNullOrBlank() && currUri != rawUrl) {
                        android.util.Log.w("PlayerScreen", "Audio/track playback failed ($currUri), falling back to raw direct stream: $rawUrl")
                        try {
                            val httpDataSourceFactory = DefaultHttpDataSource.Factory()
                                .setUserAgent(failedHeaders["User-Agent"] ?: "Mozilla/5.0 (Linux; Android 16; sdk_gphone64_x86_64 Build/BE2A.250530.026.D1; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/133.0.6943.137 Mobile Safari/537.36 /OS.Gatu v3.0")
                                .setAllowCrossProtocolRedirects(true)
                                .setConnectTimeoutMs(15000)
                                .setReadTimeoutMs(15000)
                                .setDefaultRequestProperties(failedHeaders)
                            val dataSourceFactory = androidx.media3.datasource.DefaultDataSource.Factory(context, httpDataSourceFactory)
                            val mediaItemBuilder = MediaItem.Builder()
                                .setUri(rawUrl)
                                .setMediaId(listenerMediaId)
                                .setMimeType(MimeTypes.APPLICATION_M3U8)
                            val mediaSource = DefaultMediaSourceFactory(dataSourceFactory).createMediaSource(mediaItemBuilder.build())
                            exoPlayer.setMediaSource(mediaSource)
                            exoPlayer.prepare()
                            exoPlayer.playWhenReady = true
                            exoPlayer.play()
                            isPlaying = true
                            playbackError = null
                            return@launch
                        } catch (e: Exception) {
                            android.util.Log.w("PlayerScreen", "Raw stream fallback failed: ${e.message}")
                        }
                    }

                    if (trailerFallbackAttempted) {
                        playbackError = "This title could not be played."
                        return@launch
                    }
                    trailerFallbackAttempted = true
                    val trailerStream = try {
                        withContext(Dispatchers.IO) { viewModel.resolveTrailerStream(movie) }
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (e: Exception) {
                        android.util.Log.w("PlayerScreen", "Trailer resolution failed: ${e.message}")
                        null
                    }
                    ensureActive()
                    if (!ownsCurrentMedia()) return@launch
                    if (trailerStream != null) {
                        try {
                            val httpDataSourceFactory = DefaultHttpDataSource.Factory()
                                .setUserAgent(trailerStream.headers["User-Agent"] ?: "Mozilla/5.0 (Linux; Android 16; sdk_gphone64_x86_64 Build/BE2A.250530.026.D1; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/133.0.6943.137 Mobile Safari/537.36 /OS.Gatu v3.0")
                                .setAllowCrossProtocolRedirects(true)
                                .setConnectTimeoutMs(15000)
                                .setReadTimeoutMs(15000)
                                .setDefaultRequestProperties(trailerStream.headers)
                            val dataSourceFactory = androidx.media3.datasource.DefaultDataSource.Factory(context, httpDataSourceFactory)
                            val streamMimeType = when {
                                trailerStream.url.contains(".m3u8", ignoreCase = true) -> MimeTypes.APPLICATION_M3U8
                                trailerStream.url.contains(".mpd", ignoreCase = true) -> MimeTypes.APPLICATION_MPD
                                trailerStream.url.contains(".mp4", ignoreCase = true) -> MimeTypes.VIDEO_MP4
                                else -> null
                            }
                            val mediaItemBuilder = MediaItem.Builder()
                                .setUri(trailerStream.url)
                                .setMediaId(listenerMediaId)
                            if (streamMimeType != null) {
                                mediaItemBuilder.setMimeType(streamMimeType)
                            }
                            val mediaSource = DefaultMediaSourceFactory(dataSourceFactory).createMediaSource(mediaItemBuilder.build())
                            activeStream = trailerStream.toNetMirrorStream(title = movie.title, sourceId = "trailer_${movie.id}")
                            exoPlayer.setMediaSource(mediaSource)
                            exoPlayer.prepare()
                            exoPlayer.playWhenReady = true
                            exoPlayer.play()
                            isPlaying = true
                            playbackError = null
                            return@launch
                        } catch (e: Exception) {
                            android.util.Log.w("PlayerScreen", "Trailer fallback failed: ${e.message}")
                        }
                    }
                    playbackError = "This title could not be played."
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            fallbackJobHolder.job?.cancel()
            fallbackJobHolder.job = null
            exoPlayer.removeListener(listener)
        }
    }

    LaunchedEffect(movie.id, currentSeason, currentEpisode, loadAttempt) {
        val targetMediaId = "${movie.id}_${currentSeason}_${currentEpisode}"
        val currentMediaId = try { exoPlayer.currentMediaItem?.mediaId } catch (_: IllegalStateException) { null } catch (_: Exception) { null }
        val currentState = try { exoPlayer.playbackState } catch (_: IllegalStateException) { Player.STATE_IDLE } catch (_: Exception) { Player.STATE_IDLE }

        if (loadAttempt == 0 && (currentMediaId == targetMediaId || currentMediaId == "${movie.id}_preview") &&
            (currentState == Player.STATE_READY || currentState == Player.STATE_BUFFERING)) {
            if (activeStream == null) {
                activeStream = viewModel.getCachedStream(movie, currentSeason, currentEpisode)
            }
            isBuffering = currentState == Player.STATE_BUFFERING
            isLoading = false
            playbackError = null
            try { exoPlayer.volume = 1.0f } catch (_: Exception) {}
            try { exoPlayer.playWhenReady = true } catch (_: IllegalStateException) {} catch (_: Exception) {}
            try { exoPlayer.play() } catch (_: IllegalStateException) {} catch (_: Exception) {}
            isPlaying = true
            return@LaunchedEffect
        }

        isLoading = true
        playbackError = null
        playbackMarkers = PlaybackMarkers()
        try {
            try { exoPlayer.volume = 1.0f } catch (_: IllegalStateException) {} catch (_: Exception) {}

            fun needsNewMediaSource(mediaId: String?): Boolean {
                val playbackState = try { exoPlayer.playbackState } catch (_: Exception) { Player.STATE_IDLE }
                val matches = mediaId == targetMediaId || mediaId == "${movie.id}_preview"
                return !matches || playbackState == Player.STATE_IDLE || playbackState == Player.STATE_ENDED
            }

            val stream = withContext(Dispatchers.IO) { viewModel.resolveStream(movie, currentSeason, currentEpisode) }
            activeStream = stream
            if (stream != null) {
                val currentMediaId = try { exoPlayer.currentMediaItem?.mediaId } catch (_: IllegalStateException) { null } catch (_: Exception) { null }
                if (needsNewMediaSource(currentMediaId)) {
                    val httpDataSourceFactory = DefaultHttpDataSource.Factory()
                        .setUserAgent(stream.headers["User-Agent"] ?: "Mozilla/5.0 (Linux; Android 16; sdk_gphone64_x86_64 Build/BE2A.250530.026.D1; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/133.0.6943.137 Mobile Safari/537.36 /OS.Gatu v3.0")
                        .setAllowCrossProtocolRedirects(true)
                        .setConnectTimeoutMs(15000)
                        .setReadTimeoutMs(15000)
                        .setDefaultRequestProperties(stream.headers)
                    val dataSourceFactory = androidx.media3.datasource.DefaultDataSource.Factory(context, httpDataSourceFactory)

                    val mediaItemBuilder = MediaItem.Builder()
                        .setUri(stream.url)
                        .setMediaId(targetMediaId)
                    streamMimeTypeForUrl(stream.url)?.let { mediaItemBuilder.setMimeType(it) }

                    val subtitleConfigs = stream.captions
                        .filter { it.type != "thumbnails" && it.url.isNotBlank() }
                        .map { caption ->
                            val mimeType = if (caption.url.contains(".srt", ignoreCase = true) || caption.type.equals("srt", ignoreCase = true)) {
                                MimeTypes.APPLICATION_SUBRIP
                            } else {
                                MimeTypes.TEXT_VTT
                            }
                            val iso2 = getIso2LanguageCode(caption.languageCode.ifBlank { caption.language })
                            MediaItem.SubtitleConfiguration.Builder(Uri.parse(caption.url))
                                .setMimeType(mimeType)
                                .setLanguage(iso2)
                                .setLabel(caption.language)
                                .setSelectionFlags(
                                    if (captionMatchesLanguage(caption, selectedSubLang)) C.SELECTION_FLAG_DEFAULT else 0
                                )
                                .build()
                        }
                    if (subtitleConfigs.isNotEmpty()) {
                        mediaItemBuilder.setSubtitleConfigurations(subtitleConfigs)
                    }
                    val mediaItem = mediaItemBuilder.build()

                    val mediaSource = DefaultMediaSourceFactory(dataSourceFactory).createMediaSource(mediaItem)
                    try {
                        exoPlayer.volume = 1.0f
                        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                            .buildUpon()
                            .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_AUDIO, false)
                            .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_AUDIO)
                            .setPreferredAudioLanguages("en", "eng")
                            .build()
                    } catch (_: Exception) {}
                    try { exoPlayer.setMediaSource(mediaSource) } catch (_: IllegalStateException) {} catch (_: Exception) {}
                    try { exoPlayer.prepare() } catch (_: IllegalStateException) {} catch (_: Exception) {}
                    updateExoPlayerTrackSelection(exoPlayer, selectedSubLang)

                    val cw = withContext(Dispatchers.IO) { viewModel.getContinueWatching(movie.id) }
                    val savedProgress = pendingResumePositionMs ?: cw?.playbackPositionMs ?: 0L
                    if (savedProgress > 0) {
                        if (pendingResumePositionMs != null || movie.type != "Series" || (cw != null && cw.season == currentSeason && cw.episode == currentEpisode)) {
                            try { exoPlayer.seekTo(savedProgress) } catch (_: IllegalStateException) {} catch (_: Exception) {}
                        }
                    }
                    pendingResumePositionMs = null
                    try { exoPlayer.playWhenReady = true } catch (_: IllegalStateException) {} catch (_: Exception) {}
                    try { exoPlayer.play() } catch (_: IllegalStateException) {} catch (_: Exception) {}
                    isPlaying = true
                } else {
                    try { exoPlayer.volume = 1.0f } catch (_: IllegalStateException) {} catch (_: Exception) {}
                    try { exoPlayer.playWhenReady = true } catch (_: IllegalStateException) {} catch (_: Exception) {}
                    try { exoPlayer.play() } catch (_: IllegalStateException) {} catch (_: Exception) {}
                    isPlaying = true
                }
                isLoading = false
            } else {
                trailerFallbackAttempted = true
                val trailerStream = withContext(Dispatchers.IO) { viewModel.resolveTrailerStream(movie) }
                if (trailerStream != null) {
                    activeStream = trailerStream.toNetMirrorStream(title = movie.title, sourceId = "trailer_${movie.id}")
                    val currentMediaId = try { exoPlayer.currentMediaItem?.mediaId } catch (_: IllegalStateException) { null } catch (_: Exception) { null }
                    if (needsNewMediaSource(currentMediaId)) {
                        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
                            .setUserAgent(trailerStream.headers["User-Agent"] ?: "Mozilla/5.0 (Linux; Android 16; sdk_gphone64_x86_64 Build/BE2A.250530.026.D1; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/133.0.6943.137 Mobile Safari/537.36 /OS.Gatu v3.0")
                            .setAllowCrossProtocolRedirects(true)
                            .setConnectTimeoutMs(15000)
                            .setReadTimeoutMs(15000)
                            .setDefaultRequestProperties(trailerStream.headers)
                        val dataSourceFactory = androidx.media3.datasource.DefaultDataSource.Factory(context, httpDataSourceFactory)
                        val streamMimeType = when {
                            trailerStream.url.contains(".m3u8", ignoreCase = true) -> MimeTypes.APPLICATION_M3U8
                            trailerStream.url.contains(".mpd", ignoreCase = true) -> MimeTypes.APPLICATION_MPD
                            trailerStream.url.contains(".mp4", ignoreCase = true) -> MimeTypes.VIDEO_MP4
                            else -> null
                        }
                        val mediaItemBuilder = MediaItem.Builder()
                            .setUri(trailerStream.url)
                            .setMediaId(targetMediaId)
                        if (streamMimeType != null) {
                            mediaItemBuilder.setMimeType(streamMimeType)
                        }
                        val mediaItem = mediaItemBuilder.build()
                        val mediaSource = DefaultMediaSourceFactory(dataSourceFactory).createMediaSource(mediaItem)
                        try { exoPlayer.setMediaSource(mediaSource) } catch (_: IllegalStateException) {} catch (_: Exception) {}
                        try { exoPlayer.prepare() } catch (_: IllegalStateException) {} catch (_: Exception) {}
                        try { exoPlayer.playWhenReady = true } catch (_: IllegalStateException) {} catch (_: Exception) {}
                        try { exoPlayer.play() } catch (_: IllegalStateException) {} catch (_: Exception) {}
                        isPlaying = true
                    }
                } else {
                    playbackError = "This title could not be played."
                }
                isLoading = false
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (limited: com.example.data.PlaybackRateLimitedException) {
            playbackError = "Playback is temporarily rate limited.\nPlease wait and press Retry."
        } catch (e: Exception) {
            android.util.Log.e("PlayerScreen", "Stream load exception", e)
            playbackError = "This title could not be played."
        } finally {
            if (isActive) isLoading = false
        }
    }

    val isTvShow = remember(movie, currentSeason, currentEpisode, currentEpisodeName) {
        movie.type.equals("Series", ignoreCase = true) ||
        movie.type.equals("TV", ignoreCase = true) ||
        movie.duration.contains("Season", ignoreCase = true) ||
        currentEpisode > 1 ||
        currentSeason > 1 ||
        currentEpisodeName.isNotBlank()
    }

    LaunchedEffect(activeStream, isTvShow, isLoading) {
        if (activeStream != null && !isLoading) {
            val captionUrl = activeStream?.captions?.find {
                it.language.contains("English", ignoreCase = true) && it.type != "thumbnails"
            }?.url ?: activeStream?.captions?.firstOrNull { it.type != "thumbnails" }?.url

            if (captionUrl.isNullOrBlank()) {
                playbackMarkers = PlaybackMarkers()
                return@LaunchedEffect
            }

            val durationMs = try {
                val d = exoPlayer.duration
                if (d > 0 && d != C.TIME_UNSET) d else 0L
            } catch (_: IllegalStateException) {
                0L
            } catch (_: Exception) {
                0L
            }
            val markers = withContext(Dispatchers.IO) {
                try {
                    SubtitleMarkerDetector.detectMarkers(captionUrl, durationMs, isTvShow)
                } catch (e: Exception) {
                    android.util.Log.e("PlayerScreen", "Marker detection failed", e)
                    PlaybackMarkers()
                }
            }
            playbackMarkers = markers
        }
    }

    LaunchedEffect(movie.id, currentSeason, currentEpisode, activeStream, isLoading, isTvShow) {
        if (isTvShow && activeStream != null && !isLoading) {
            delay(8000L)
            val nextEpNum = currentEpisode + 1
            viewModel.preloadNextEpisodeStream(movie, currentSeason, nextEpNum)
        }
    }

    LaunchedEffect(activeStream, isLoading) {
        if (activeStream != null && !isLoading) {
            val thumbTrack = activeStream?.captions?.find { it.type == "thumbnails" }
            if (thumbTrack != null && thumbTrack.url.isNotBlank()) {
                val cues = withContext(Dispatchers.IO) {
                    try {
                        ThumbnailParser.parseVtt(thumbTrack.url)
                    } catch (e: Exception) {
                        android.util.Log.e("PlayerScreen", "Thumbnail parse failed", e)
                        emptyList<ThumbnailCue>()
                    }
                }
                thumbnailCues = cues
            }
        }
    }

    LaunchedEffect(selectedSubLang, activeStream, isLoading) {
        if (isLoading) {
            currentSubtitleCues = emptyList()
            exoPlayerSubtitleText = ""
            return@LaunchedEffect
        }
        updateExoPlayerTrackSelection(exoPlayer, selectedSubLang)
        val stream = activeStream
        if (selectedSubLang.equals("Off", ignoreCase = true) || stream == null) {
            currentSubtitleCues = emptyList()
            exoPlayerSubtitleText = ""
        } else {
            var matchingCaptions = stream.captions.filter {
                it.type != "thumbnails" && captionMatchesLanguage(it, selectedSubLang)
            }
            if (matchingCaptions.isEmpty()) {
                matchingCaptions = stream.captions.filter {
                    it.type != "thumbnails" && (
                        it.language.contains(selectedSubLang, ignoreCase = true) ||
                        selectedSubLang.contains(it.language, ignoreCase = true)
                    )
                }
            }

            val candidates = if (matchingCaptions.isEmpty()) {
                val freshCaptions = withContext(Dispatchers.IO) {
                    viewModel.fetchSubtitlesForStream(stream, movie, currentSeason, currentEpisode)
                }
                freshCaptions.filter {
                    it.type != "thumbnails" && (
                        captionMatchesLanguage(it, selectedSubLang) ||
                        it.language.contains(selectedSubLang, ignoreCase = true)
                    )
                }
            } else {
                matchingCaptions
            }

            if (candidates.isNotEmpty()) {
                var loaded = false
                for (caption in candidates) {
                    val body = SubtitleCueParser.fetchSubtitleText(caption.url, stream.headers)
                    if (!body.isNullOrBlank()) {
                        val cues = SubtitleCueParser.parseCuesFromTextOrM3u8(body, caption.url)
                        if (cues.isNotEmpty()) {
                            currentSubtitleCues = cues
                            loaded = true
                            break
                        }
                    }
                }
                if (!loaded) {
                    currentSubtitleCues = emptyList()
                }
            } else {
                currentSubtitleCues = emptyList()
            }
        }
    }

    DisposableEffect(Unit) {
        val window = (context as? android.app.Activity)?.window
        window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (!isExitProgressSaved) {
                isExitProgressSaved = true
                val (safePos, safeDur) = try {
                    exoPlayer.currentPosition to exoPlayer.duration
                } catch (_: IllegalStateException) {
                    0L to 0L
                } catch (_: Exception) {
                    0L to 0L
                }
                if (safeDur > 0L) {
                    viewModel.savePlaybackProgress(
                        movie = movie,
                        positionMs = safePos,
                        durationMs = safeDur,
                        season = currentSeason,
                        episode = currentEpisode,
                        episodeName = currentEpisodeName,
                        forceFirestoreSync = true
                    )
                }
                try { exoPlayer.pause() } catch (_: IllegalStateException) {} catch (_: Exception) {}
            }
        }
    }

    var lastFocusedControlRequester by remember { mutableStateOf<FocusRequester?>(null) }
    LaunchedEffect(lastActivityTime, showControls, showSubtitleModal) {
        if (showControls && !showSubtitleModal) {
            delay(4000L)
            showControls = false
        }
    }
    LaunchedEffect(showControls) {
        if (showControls) {
            delay(80L)
            val toFocus = lastFocusedControlRequester ?: playButtonRequester
            try { toFocus.requestFocus() } catch (_: Exception) {}
        } else {
            try { mainPlayerRequester.requestFocus() } catch (_: Exception) {}
        }
    }

    LaunchedEffect(showSubtitleModal) {
        if (!showSubtitleModal && showControls) {
            delay(60L)
            val toFocus = lastFocusedControlRequester ?: playButtonRequester
            try { toFocus.requestFocus() } catch (_: Exception) {}
        }
    }

    LaunchedEffect(isPlaying) {
        try { exoPlayer.playWhenReady = isPlaying } catch (_: IllegalStateException) {} catch (_: Exception) {}
    }

    LaunchedEffect(exoPlayer) {
        while (true) {
            delay(15_000L)
            val safeState = try {
                Triple(exoPlayer.duration > 0, exoPlayer.isPlaying, exoPlayer.currentPosition to exoPlayer.duration)
            } catch (_: IllegalStateException) {
                null
            } catch (_: Exception) {
                null
            }
            if (safeState != null) {
                val (hasDuration, playing, posDur) = safeState
                if (hasDuration && playing) {
                    viewModel.savePlaybackProgress(
                        movie = movie,
                        positionMs = posDur.first,
                        durationMs = posDur.second,
                        season = currentSeason,
                        episode = currentEpisode,
                        episodeName = currentEpisodeName,
                        forceFirestoreSync = false
                    )
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        try {
            androidx.compose.runtime.withFrameNanos { }
            if (showControls) {
                playButtonRequester.requestFocus()
            } else {
                mainPlayerRequester.requestFocus()
            }
        } catch (_: Exception) {}
    }

    BackHandler {
        if (showSubtitleModal) {
            showSubtitleModal = false
        } else if (showControls) {
            showControls = false
        } else {
            safeSaveAndExit()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NetflixBlack)
            .focusRequester(mainPlayerRequester)
            .focusable()
            .onPreviewKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyDown) {
                    val keyCode = keyEvent.nativeKeyEvent.keyCode

                    if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                        if (showSubtitleModal) {
                            showSubtitleModal = false
                            return@onPreviewKeyEvent true
                        } else if (showControls) {
                            showControls = false
                            try { mainPlayerRequester.requestFocus() } catch (_: Exception) {}
                            return@onPreviewKeyEvent true
                        }
                        return@onPreviewKeyEvent false
                    }

                    // Android marks a held D-pad seek key as a long press. Do not
                    // turn repeated LEFT/RIGHT (or confirm on the scrubber) into
                    // the subtitle shortcut before the scrubber receives it.
                    val subtitleShortcutLongPress = keyEvent.nativeKeyEvent.isLongPress &&
                        lastFocusedControlRequester != progressRequester &&
                        (keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
                            keyCode == KeyEvent.KEYCODE_ENTER ||
                            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER)
                    if (keyCode == KeyEvent.KEYCODE_MENU || subtitleShortcutLongPress) {
                        showSubtitleModal = true
                        userActivity()
                        return@onPreviewKeyEvent true
                    }

                    if (!showControls) {
                        showControls = true
                        lastActivityTime = System.currentTimeMillis()
                        when (keyCode) {
                            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_SPACE -> {
                                isPlaying = !isPlaying
                                val toFocus = lastFocusedControlRequester ?: playButtonRequester
                                try { toFocus.requestFocus() } catch (_: Exception) {}
                            }
                            KeyEvent.KEYCODE_DPAD_LEFT -> {
                                isPlaying = false
                                lastFocusedControlRequester = progressRequester
                                val safePos = try { exoPlayer.currentPosition } catch (_: IllegalStateException) { return@onPreviewKeyEvent true } catch (_: Exception) { return@onPreviewKeyEvent true }
                                val newPos = (safePos - 10000).coerceAtLeast(0)
                                val canSeek = try { exoPlayer.playbackState != Player.STATE_IDLE } catch (_: IllegalStateException) { false } catch (_: Exception) { false }
                                if (canSeek) {
                                    try { exoPlayer.seekTo(newPos) } catch (_: IllegalStateException) {} catch (_: Exception) {}
                                }
                                try { progressRequester.requestFocus() } catch (_: Exception) {}
                            }
                            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                                isPlaying = false
                                lastFocusedControlRequester = progressRequester
                                val safePair = try {
                                    exoPlayer.currentPosition to exoPlayer.duration
                                } catch (_: IllegalStateException) {
                                    return@onPreviewKeyEvent true
                                } catch (_: Exception) {
                                    return@onPreviewKeyEvent true
                                }
                                val maxDur = if (safePair.second > 0L && safePair.second != C.TIME_UNSET) safePair.second else Long.MAX_VALUE
                                val newPos = (safePair.first + 10000).coerceAtMost(maxDur)
                                val canSeek = try { exoPlayer.playbackState != Player.STATE_IDLE } catch (_: IllegalStateException) { false } catch (_: Exception) { false }
                                if (canSeek) {
                                    try { exoPlayer.seekTo(newPos) } catch (_: IllegalStateException) {} catch (_: Exception) {}
                                }
                                try { progressRequester.requestFocus() } catch (_: Exception) {}
                            }
                            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                                val toFocus = lastFocusedControlRequester ?: playButtonRequester
                                try { toFocus.requestFocus() } catch (_: Exception) {}
                            }
                            else -> {
                                val toFocus = lastFocusedControlRequester ?: playButtonRequester
                                try { toFocus.requestFocus() } catch (_: Exception) {}
                            }
                        }
                        return@onPreviewKeyEvent true
                    } else {
                        userActivity()
                    }

                    val isMediaKey = keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE ||
                            keyCode == KeyEvent.KEYCODE_MEDIA_PLAY ||
                            keyCode == KeyEvent.KEYCODE_MEDIA_PAUSE ||
                            keyCode == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD ||
                            keyCode == KeyEvent.KEYCODE_MEDIA_REWIND ||
                            keyCode == KeyEvent.KEYCODE_MEDIA_NEXT ||
                            keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS

                    if (isMediaKey) {
                        when (keyCode) {
                            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> isPlaying = !isPlaying
                            KeyEvent.KEYCODE_MEDIA_PLAY -> isPlaying = true
                            KeyEvent.KEYCODE_MEDIA_PAUSE -> isPlaying = false
                            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                                val safePair = try {
                                    exoPlayer.currentPosition to exoPlayer.duration
                                } catch (_: IllegalStateException) {
                                    return@onPreviewKeyEvent true
                                } catch (_: Exception) {
                                    return@onPreviewKeyEvent true
                                }
                                val maxDur = if (safePair.second > 0L && safePair.second != C.TIME_UNSET) safePair.second else Long.MAX_VALUE
                                val newPos = (safePair.first + 10000).coerceAtMost(maxDur)
                                val canSeek = try { exoPlayer.playbackState != Player.STATE_IDLE } catch (_: IllegalStateException) { false } catch (_: Exception) { false }
                                if (canSeek) {
                                    try { exoPlayer.seekTo(newPos) } catch (_: IllegalStateException) {} catch (_: Exception) {}
                                }
                            }
                            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                                val safePos = try { exoPlayer.currentPosition } catch (_: IllegalStateException) { return@onPreviewKeyEvent true } catch (_: Exception) { return@onPreviewKeyEvent true }
                                val newPos = (safePos - 10000).coerceAtLeast(0)
                                val canSeek = try { exoPlayer.playbackState != Player.STATE_IDLE } catch (_: IllegalStateException) { false } catch (_: Exception) { false }
                                if (canSeek) {
                                    try { exoPlayer.seekTo(newPos) } catch (_: IllegalStateException) {} catch (_: Exception) {}
                                }
                            }
                            KeyEvent.KEYCODE_MEDIA_NEXT -> playNextEpisode()
                        }
                        return@onPreviewKeyEvent true
                    }
                    false
                } else {
                    false
                }
            }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        awaitPointerEvent()
                        if (!showControls) {
                            showControls = true
                            try { playButtonRequester.requestFocus() } catch (_: Exception) {}
                        }
                        userActivity()
                    }
                }
            }
    ) {
        val backdropUrl = remember(movie) { movie.backdropUrl.ifBlank { movie.posterUrl } }
        if (!backdropUrl.isNullOrBlank()) {
            val backdropCtx = LocalContext.current
            val density = LocalDensity.current
            val screenW = with(density) { LocalConfiguration.current.screenWidthDp.dp.roundToPx() }
            val screenH = with(density) { LocalConfiguration.current.screenHeightDp.dp.roundToPx() }
            val backdropRequest = remember(backdropUrl, screenW, screenH) {
                buildPlayerImageRequest(
                    context = backdropCtx,
                    url = backdropUrl,
                    widthPx = screenW,
                    heightPx = screenH,
                    memoryCacheKey = "player_backdrop_$backdropUrl"
                )
            }
            AsyncImage(
                model = backdropRequest,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        AndroidView(
            factory = { ctx ->
                val view = android.view.LayoutInflater.from(ctx)
                    .inflate(com.example.R.layout.media_player_view, null) as PlayerView
                view.apply {
                    player = exoPlayer
                    useController = false
                    subtitleView?.visibility = android.view.View.GONE
                    setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                    setBackgroundColor(android.graphics.Color.TRANSPARENT)
                    layoutParams = android.view.ViewGroup.LayoutParams(
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { playerView ->
                if (playerView.player != exoPlayer) {
                    playerView.player = exoPlayer
                }
            },
            onRelease = { playerView ->
                playerView.player = null
            },
            modifier = Modifier.fillMaxSize()
        )

        AnimatedVisibility(
            visible = showControls,
            enter = fadeIn(animationSpec = tween(200, easing = FastOutSlowInEasing)),
            exit = fadeOut(animationSpec = tween(200, easing = FastOutSlowInEasing))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.82f),
                                Color.Black.copy(alpha = 0.45f),
                                Color.Black.copy(alpha = 0.90f)
                            )
                        )
                    )
            )
        }

        AnimatedVisibility(
            visible = showControls,
            enter = slideInVertically(
                initialOffsetY = { -it },
                animationSpec = tween(200, easing = FastOutSlowInEasing)
            ) + fadeIn(animationSpec = tween(200, easing = FastOutSlowInEasing)),
            exit = slideOutVertically(
                targetOffsetY = { -it },
                animationSpec = tween(200, easing = FastOutSlowInEasing)
            ) + fadeOut(animationSpec = tween(200, easing = FastOutSlowInEasing)),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            PlayerTopBar(
                movie = movie,
                currentSeason = currentSeason,
                currentEpisode = currentEpisode,
                currentEpisodeName = currentEpisodeName,
                logoUrl = logoUrl,
                isLoggedIn = isLoggedIn,
                isTvShow = isTvShow,
                onBack = {
                    val (safePos, safeDur) = try {
                        exoPlayer.currentPosition to exoPlayer.duration
                    } catch (_: IllegalStateException) {
                        0L to 0L
                    } catch (_: Exception) {
                        0L to 0L
                    }
                    viewModel.savePlaybackProgress(
                        movie = movie,
                        positionMs = safePos,
                        durationMs = safeDur,
                        season = currentSeason,
                        episode = currentEpisode,
                        episodeName = currentEpisodeName,
                        forceFirestoreSync = true
                    )
                    try { exoPlayer.pause() } catch (_: IllegalStateException) {} catch (_: Exception) {}
                    onBack()
                },
                onReplay10 = onReplay10@{
                    userActivity()
                    val safePos = try { exoPlayer.currentPosition } catch (_: IllegalStateException) { return@onReplay10 } catch (_: Exception) { return@onReplay10 }
                    val newPos = (safePos - 10000).coerceAtLeast(0)
                    val canSeek = try { exoPlayer.playbackState != Player.STATE_IDLE } catch (_: IllegalStateException) { false } catch (_: Exception) { false }
                    if (canSeek) {
                        try { exoPlayer.seekTo(newPos) } catch (_: IllegalStateException) {} catch (_: Exception) {}
                    }
                },
                onNextEpisode = {
                    userActivity()
                    playNextEpisode()
                }
            )
        }

        AnimatedVisibility(
            visible = showControls && !isPlaying,
            enter = slideInHorizontally(
                initialOffsetX = { -it / 3 },
                animationSpec = tween(200, easing = FastOutSlowInEasing)
            ) + fadeIn(animationSpec = tween(200, easing = FastOutSlowInEasing)),
            exit = slideOutHorizontally(
                targetOffsetX = { -it / 3 },
                animationSpec = tween(200, easing = FastOutSlowInEasing)
            ) + fadeOut(animationSpec = tween(200, easing = FastOutSlowInEasing)),
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 56.dp, top = 20.dp)
        ) {
            PlayerPauseInfoCard(
                movie = movie,
                currentSeason = currentSeason,
                currentEpisode = currentEpisode,
                currentEpisodeName = currentEpisodeName,
                logoUrl = logoUrl,
                onUserActivity = { userActivity() }
            )
        }

        AnimatedVisibility(
            visible = showControls,
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = tween(200, easing = FastOutSlowInEasing)
            ) + fadeIn(animationSpec = tween(200, easing = FastOutSlowInEasing)),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = tween(200, easing = FastOutSlowInEasing)
            ) + fadeOut(animationSpec = tween(200, easing = FastOutSlowInEasing)),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            PlayerBottomControls(
                exoPlayer = exoPlayer,
                isPlaying = isPlaying,
                activeStream = activeStream,
                thumbnailCues = thumbnailCues,
                movie = movie,
                currentSeason = currentSeason,
                currentEpisode = currentEpisode,
                isTvShow = isTvShow,
                selectedSubLang = selectedSubLang,
                playButtonRequester = playButtonRequester,
                progressRequester = progressRequester,
                onTogglePlay = {
                    userActivity()
                    isPlaying = !isPlaying
                },
                onUserActivity = { userActivity() },
                onTrackFocus = { requester -> lastFocusedControlRequester = requester },
                onSelectSubtitle = { lang ->
                    userActivity()
                    viewModel.setSelectedSubtitleLanguage(lang)
                },
                onOpenSubtitleSettings = {
                    userActivity()
                    showSubtitleModal = true
                }
            )
        }

        val introStart = playbackMarkers.introStart
        val introEnd = playbackMarkers.introEnd
        if (introStart != null && introEnd != null) {
            val skipBottomPadding by animateDpAsState(
                targetValue = if (showControls) 175.dp else 48.dp,
                animationSpec = tween(220, easing = FastOutSlowInEasing),
                label = "skipIntroPadding"
            )
            SkipIntroOverlay(
                exoPlayer = exoPlayer,
                introStart = introStart,
                introEnd = introEnd,
                onUserActivity = { userActivity() },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 48.dp, bottom = skipBottomPadding)
            )
        }

        val outroStart = playbackMarkers.outroStart
        if (outroStart != null && isTvShow) {
            val nextBottomPadding by animateDpAsState(
                targetValue = if (showControls) 185.dp else 48.dp,
                animationSpec = tween(220, easing = FastOutSlowInEasing),
                label = "nextEpisodePadding"
            )
            NextEpisodeCountdownOverlay(
                exoPlayer = exoPlayer,
                outroStart = outroStart,
                currentSeason = currentSeason,
                currentEpisode = currentEpisode,
                movie = movie,
                onTriggerNextEpisode = { playNextEpisode() },
                onUserActivity = { userActivity() },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 48.dp, bottom = nextBottomPadding)
            )
        }

        if (showSubtitleModal) {
            AudioSubtitlesModal(
                exoPlayer = exoPlayer,
                playerTracks = playerTracks,
                activeStream = activeStream,
                selectedSubLang = selectedSubLang,
                onSelectSubtitle = { lang ->
                    userActivity()
                    viewModel.setSelectedSubtitleLanguage(lang)
                },
                onClose = { showSubtitleModal = false },
                onUserActivity = { userActivity() }
            )
        }

        if (!selectedSubLang.equals("Off", ignoreCase = true)) {
            SubtitleOverlay(
                exoPlayer = exoPlayer,
                cues = currentSubtitleCues,
                exoText = exoPlayerSubtitleText,
                showControls = showControls,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

        val currentMediaId = try { exoPlayer.currentMediaItem?.mediaId } catch (_: IllegalStateException) { null } catch (_: Exception) { null }
        val isTargetMediaReady = ((currentMediaId == "${movie.id}_${currentSeason}_${currentEpisode}") || (currentMediaId == "${movie.id}_preview")) && !isLoading
        val showLoadingOverlay = playbackError == null && (isLoading || isBuffering || !isTargetMediaReady)
        AnimatedVisibility(
            visible = showLoadingOverlay,
            enter = fadeIn(animationSpec = tween(180, easing = FastOutSlowInEasing)),
            exit = fadeOut(animationSpec = tween(220, easing = FastOutSlowInEasing))
        ) {
            PlayerLoadingOverlay(
                isLoading = isLoading,
                isBuffering = isBuffering,
                exoPlayer = exoPlayer,
                isTargetMediaReady = isTargetMediaReady
            )
        }
        if (playbackError != null) {
            PlayerErrorOverlay(
                onRetry = {
                    sessionRecoveryAttempts = 0
                    // If resolution never produced a stream, a rejected cookie may
                    // have looked like empty search results. Retry with a fresh session.
                    if (activeStream == null && playbackError?.contains("rate limited", ignoreCase = true) != true) {
                        viewModel.reportBadSession(null)
                    }
                    if (playbackError?.contains("rate limited", ignoreCase = true) == true) {
                        viewModel.evictCachedStream(movie, currentSeason, currentEpisode)
                    } else {
                        viewModel.invalidateStream(movie, currentSeason, currentEpisode)
                    }
                    restartPlaybackResolution()
                }
            )
        }
    }
}
