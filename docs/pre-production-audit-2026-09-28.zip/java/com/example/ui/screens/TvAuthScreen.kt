package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.util.Log
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.input.key.type
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.painterResource
import androidx.tv.material3.Button
import androidx.tv.material3.ButtonDefaults
import androidx.tv.material3.Surface
import androidx.compose.material3.Text
import com.example.ui.NetflixViewModel
import com.example.R
import com.example.ui.theme.AnimationSpecs
import com.example.ui.theme.TvAuthErrorText
import com.example.ui.theme.TvAuthFieldOutline
import com.example.ui.theme.TvAuthRed
import com.example.ui.theme.TvAuthRedScrim
import com.example.ui.theme.TvAuthSecondaryBg
import com.example.ui.theme.TvAuthStatusPaired
import com.example.ui.theme.TvAuthStatusPairedBg
import com.example.ui.theme.TvAuthTertiaryBg
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.delay
import org.json.JSONArray
import kotlin.random.Random

@Composable
fun TvAuthScreen(
    viewModel: NetflixViewModel,
    onAuthenticated: (email: String) -> Unit,
    onSkipToGuest: () -> Unit
) {
    // perf: persist the session code across recomposition + config change so
    // the user doesn't see a new code after rotating the TV. The code itself
    // is non-sensitive (no credentials), so rememberSaveable is appropriate.
    var sessionCode by rememberSaveable { mutableStateOf(generateRandomTvCode()) }
    var qrBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var pairStatus by rememberSaveable { mutableStateOf("PENDING") } // PENDING, PAIRED, ERROR
    var pairedEmail by rememberSaveable { mutableStateOf<String?>(null) }

    // Direct TV Email / Password Form Toggle
    var showDirectTvSignIn by rememberSaveable { mutableStateOf(false) }
    // perf: do NOT use rememberSaveable for credentials — credentials must never
    // be persisted to the saved-instance Bundle. Keep them in plain remember (RAM
    // only) and let the user re-enter on process death; this matches the
    // "credentials in memory only" rule.
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var tvAuthError by remember { mutableStateOf<String?>(null) }
    var isAuthenticating by remember { mutableStateOf(false) }
    // Auto-dismiss the error after 5s once the user resumes typing — see spec.
    var lastErrorShownAt by remember { mutableLongStateOf(0L) }

    // Generate QR code whenever code changes
    LaunchedEffect(sessionCode) {
        val cleanCode = sessionCode.trim().uppercase()
        val rawCodeNoPrefix = cleanCode.removePrefix("NF-").removePrefix("NET-")
        // Don't put any credential or user identifier in the pairing URL.
        // The URL only carries the random session code; auth happens on the
        // Firestore doc keyed by the same code.
        val pairUrl = "netflixpro://pair?code=$cleanCode"
        qrBitmap = generateQrCode(pairUrl, 420, 420)

        // Initialize Firestore session document for real-time TV unlock
        try {
            if (FirebaseApp.getApps(viewModel.getApplication()).isNotEmpty()) {
                val db = FirebaseFirestore.getInstance()
                val initialData = mapOf(
                    "sessionCode" to cleanCode,
                    "status" to "PENDING",
                    "createdAt" to System.currentTimeMillis(),
                    "deviceName" to "Living Room Android TV"
                )
                db.collection("tv_sessions").document(cleanCode).set(initialData, SetOptions.merge())
                if (rawCodeNoPrefix != cleanCode) {
                    db.collection("tv_sessions").document(rawCodeNoPrefix).set(initialData, SetOptions.merge())
                }
            }
        } catch (e: Exception) {
            Log.e("TvAuthScreen", "Firestore session init error: ${e.message}")
        }
    }

    // Real-time listener on Firestore tv_sessions/{sessionCode}
    // perf: read pairStatus via a stable lambda over the latest state so the
    // listener body doesn't capture a stale value. The DisposableEffect's key
    // is still sessionCode; onDispose tears down both listeners.
    DisposableEffect(sessionCode) {
        val cleanCode = sessionCode.trim().uppercase()
        val rawCodeNoPrefix = cleanCode.removePrefix("NF-").removePrefix("NET-")
        var listenerPrimary: com.google.firebase.firestore.ListenerRegistration? = null
        var listenerSecondary: com.google.firebase.firestore.ListenerRegistration? = null

        val handleSnapshot: (com.google.firebase.firestore.DocumentSnapshot?) -> Unit = { snapshot ->
            if (snapshot != null && snapshot.exists() && pairStatus != "PAIRED") {
                val status = snapshot.getString("status") ?: "PENDING"
                if (status == "PAIRED") {
                    val email = snapshot.getString("userEmail") ?: "member@netflix.pro"
                    val profilesJsonStr = snapshot.getString("profilesJson")
                    val userId = snapshot.getString("userId") ?: "user_netflix_pro_primary"
                    val planId = snapshot.getString("planId") ?: snapshot.getString("plan") ?: "plan_standard"
                    val planName = snapshot.getString("planName") ?: "Standard"
                    val subStatus = snapshot.getString("subscriptionStatus") ?: "ACTIVE"
                    val expiresAt = snapshot.getLong("expiresAt") ?: 0L

                    pairStatus = "PAIRED"
                    pairedEmail = email

                    viewModel.setPairedUser(
                        userId = userId,
                        email = email,
                        planId = planId,
                        planName = planName,
                        status = subStatus,
                        expiresAt = expiresAt
                    )

                    // Fallback import profiles from paired JSON if needed
                    if (!profilesJsonStr.isNullOrBlank()) {
                        try {
                            val jsonArr = JSONArray(profilesJsonStr)
                            for (i in 0 until jsonArr.length()) {
                                val pObj = jsonArr.getJSONObject(i)
                                val pName = pObj.optString("name", "User")
                                val pAvatar = pObj.optString("avatarUrl", null)
                                val pIsKids = pObj.optBoolean("isKids", false)
                                val pPin = pObj.optString("pin", null).takeIf { !it.isNullOrEmpty() }

                                if (viewModel.profiles.value.none { it.name.equals(pName, ignoreCase = true) }) {
                                    viewModel.addProfile(
                                        name = pName,
                                        avatarUrl = pAvatar,
                                        isKid = pIsKids,
                                        pin = pPin
                                    )
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("TvAuthScreen", "Error parsing paired profiles: ${e.message}")
                        }
                    }

                    onAuthenticated(email)
                }
            }
        }

        try {
            if (FirebaseApp.getApps(viewModel.getApplication()).isNotEmpty()) {
                val db = FirebaseFirestore.getInstance()
                listenerPrimary = db.collection("tv_sessions").document(cleanCode)
                    .addSnapshotListener { snapshot, error ->
                        if (error == null) handleSnapshot(snapshot)
                    }
                if (rawCodeNoPrefix != cleanCode) {
                    listenerSecondary = db.collection("tv_sessions").document(rawCodeNoPrefix)
                        .addSnapshotListener { snapshot, error ->
                            if (error == null) handleSnapshot(snapshot)
                        }
                }
            }
        } catch (e: Exception) {
            Log.e("TvAuthScreen", "Error attaching listener: ${e.message}")
        }

        onDispose {
            listenerPrimary?.remove()
            listenerSecondary?.remove()
        }
    }

    // perf: auto-dismiss the error banner 5s after it was first shown, so it
    // doesn't linger forever if the user abandons the field. Capture the
    // timestamp at launch so a fresh error doesn't re-trigger the dismiss
    // before its own 5s window has elapsed.
    LaunchedEffect(lastErrorShownAt) {
        if (lastErrorShownAt > 0L) {
            val captured = lastErrorShownAt
            delay(5_000L)
            if (tvAuthError != null && lastErrorShownAt == captured) {
                tvAuthError = null
            }
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .testTag("tv_auth_screen_surface")
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(48.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // LEFT COLUMN: Instructions & Code
                Column(
                    modifier = Modifier
                        .weight(1.2f)
                        .verticalScroll(rememberScrollState())
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.Center
                ) {
                    // Netflix Branding Header
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_netflix_logo),
                            contentDescription = "Netflix Logo",
                            tint = Color.Unspecified,
                            modifier = Modifier.width(130.dp).height(38.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "PRO",
                            color = TvAuthRed,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    Text(
                        text = "Sign in to watch on TV",
                        color = Color.White,
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Unlimited movies, TV shows, and personalized profiles",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 18.sp
                    )

                    Spacer(modifier = Modifier.height(28.dp))

                    if (!showDirectTvSignIn) {
                        // Steps
                        TvStepItem(stepNum = "1", text = "Open Netflix Pro on your phone")
                        Spacer(modifier = Modifier.height(10.dp))
                        TvStepItem(stepNum = "2", text = "Go to My Netflix → Pair TV")
                        Spacer(modifier = Modifier.height(10.dp))
                        TvStepItem(stepNum = "3", text = "Scan this QR code or tap \"Enter Code\" and type:")

                        Spacer(modifier = Modifier.height(16.dp))

                        // TV Activation Pin Box
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(TvAuthRedScrim)
                                .border(2.dp, TvAuthRed, RoundedCornerShape(12.dp))
                                .padding(horizontal = 28.dp, vertical = 14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = sessionCode,
                                    color = Color.White,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 6.sp
                                )
                                Spacer(modifier = Modifier.width(20.dp))
                                Icon(
                                    imageVector = Icons.Default.LockOpen,
                                    contentDescription = null,
                                    tint = TvAuthRed,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Status Badge
                        TvPulseStatusBadge(status = pairStatus, email = pairedEmail)

                        Spacer(modifier = Modifier.height(32.dp))

                        // Actions Row
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Button(
                                onClick = { showDirectTvSignIn = true },
                                colors = ButtonDefaults.colors(
                                    containerColor = TvAuthSecondaryBg,
                                    contentColor = Color.White
                                )
                            ) {
                                Text("Sign In with Email on TV", fontSize = 14.sp)
                            }

                            Button(
                                onClick = {
                                    sessionCode = generateRandomTvCode()
                                },
                                colors = ButtonDefaults.colors(
                                    containerColor = TvAuthTertiaryBg,
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("New Code", fontSize = 14.sp)
                            }

                            Button(
                                onClick = {
                                    viewModel.setGuestMode()
                                    onSkipToGuest()
                                },
                                colors = ButtonDefaults.colors(
                                    containerColor = Color.Transparent,
                                    contentColor = Color.White.copy(alpha = 0.7f)
                                )
                            ) {
                                Text("Browse as Guest", fontSize = 14.sp)
                            }
                        }
                    } else {
                        // Direct TV Sign In Form
                        val focusManager = LocalFocusManager.current
                        Column(modifier = Modifier.width(420.dp)) {
                            Text(
                                text = "TV Direct Email Sign In",
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // a11y: error row exposes semantics to TalkBack so
                            // screen readers announce the failure on the field.
                            if (tvAuthError != null) {
                                Text(
                                    text = tvAuthError.orEmpty(),
                                    color = TvAuthErrorText,
                                    fontSize = 14.sp,
                                    modifier = Modifier
                                        .padding(bottom = 10.dp)
                                        .semantics { contentDescription = "Sign in error: ${tvAuthError.orEmpty()}" }
                                )
                            }

                            OutlinedTextField(
                                value = emailInput,
                                onValueChange = {
                                    emailInput = it
                                    // Clear the stale error as soon as the user
                                    // starts editing — don't make them re-type
                                    // their email just to retry.
                                    if (tvAuthError != null) {
                                        tvAuthError = null
                                    }
                                },
                                label = { androidx.compose.material3.Text("Email Address") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    capitalization = KeyboardCapitalization.None,
                                    keyboardType = KeyboardType.Email
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = TvAuthRed,
                                    unfocusedBorderColor = TvAuthFieldOutline,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onPreviewKeyEvent { keyEvent ->
                                        if (keyEvent.type == KeyEventType.KeyDown) {
                                            val keyCode = keyEvent.nativeKeyEvent.keyCode
                                            if (keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN) {
                                                focusManager.moveFocus(FocusDirection.Down)
                                                return@onPreviewKeyEvent true
                                            } else if (keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP) {
                                                focusManager.moveFocus(FocusDirection.Up)
                                                return@onPreviewKeyEvent true
                                            }
                                        }
                                        false
                                    }
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = passwordInput,
                                onValueChange = {
                                    passwordInput = it
                                    if (tvAuthError != null) {
                                        tvAuthError = null
                                    }
                                },
                                label = { androidx.compose.material3.Text("Password") },
                                singleLine = true,
                                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(
                                    capitalization = KeyboardCapitalization.None,
                                    keyboardType = KeyboardType.Password
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = TvAuthRed,
                                    unfocusedBorderColor = TvAuthFieldOutline,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onPreviewKeyEvent { keyEvent ->
                                        if (keyEvent.type == KeyEventType.KeyDown) {
                                            val keyCode = keyEvent.nativeKeyEvent.keyCode
                                            if (keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN) {
                                                focusManager.moveFocus(FocusDirection.Down)
                                                return@onPreviewKeyEvent true
                                            } else if (keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP) {
                                                focusManager.moveFocus(FocusDirection.Up)
                                                return@onPreviewKeyEvent true
                                            }
                                        }
                                        false
                                    }
                            )

                            Spacer(modifier = Modifier.height(20.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Button(
                                    onClick = {
                                        // perf: validate on submit, not on every
                                        // keystroke — see the form-validation rule.
                                        val trimmed = emailInput.trim()
                                        val pwd = passwordInput
                                        if (trimmed.isBlank() || !isPlausibleEmail(trimmed)) {
                                            tvAuthError = "Please enter a valid email address."
                                            lastErrorShownAt = System.currentTimeMillis()
                                            return@Button
                                        }
                                        if (pwd.isBlank() || pwd.length < 6) {
                                            tvAuthError = "Password must be at least 6 characters."
                                            lastErrorShownAt = System.currentTimeMillis()
                                            return@Button
                                        }
                                        isAuthenticating = true
                                        tvAuthError = null
                                        viewModel.signInWithEmail(
                                            email = trimmed,
                                            password = pwd,
                                            onSuccess = { authedEmail ->
                                                isAuthenticating = false
                                                onAuthenticated(authedEmail)
                                            },
                                            onError = { err ->
                                                isAuthenticating = false
                                                tvAuthError = err
                                                lastErrorShownAt = System.currentTimeMillis()
                                            }
                                        )
                                    },
                                    enabled = !isAuthenticating,
                                    colors = ButtonDefaults.colors(containerColor = TvAuthRed)
                                ) {
                                    if (isAuthenticating) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(16.dp),
                                            color = Color.White,
                                            strokeWidth = 2.dp
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Signing In...", fontWeight = FontWeight.Bold)
                                    } else {
                                        Text("Sign In on TV", fontWeight = FontWeight.Bold)
                                    }
                                }

                                Button(
                                    onClick = { showDirectTvSignIn = false },
                                    enabled = !isAuthenticating,
                                    colors = ButtonDefaults.colors(containerColor = TvAuthSecondaryBg)
                                ) {
                                    Text("Back to QR Code")
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.width(32.dp))

                // RIGHT COLUMN: QR Code Card
                Column(
                    modifier = Modifier
                        .weight(0.8f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.White)
                            .border(4.dp, TvAuthRed.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // perf: AnimatedVisibility now has explicit enter/exit
                        // tweens so the QR cross-fade is smooth (and so the
                        // placeholder spinner doesn't pop). The QR regenerates
                        // any time the session code changes (LaunchedEffect above)
                        // so a rotation produces a fresh bitmap, not a stale one.
                        androidx.compose.animation.AnimatedVisibility(
                            visible = qrBitmap != null,
                            enter = fadeIn(animationSpec = AnimationSpecs.QrFadeIn),
                            exit = fadeOut(animationSpec = AnimationSpecs.QrFadeIn)
                        ) {
                            val safeBitmap = qrBitmap
                            if (safeBitmap != null) {
                                Image(
                                    bitmap = safeBitmap.asImageBitmap(),
                                    contentDescription = "Scan QR Code to unlock TV Sign In",
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                        if (qrBitmap == null) {
                            CircularProgressIndicator(color = TvAuthRed)
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Scan with Netflix Pro App",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // a11y: the "How do I scan?" hint makes the QR pairing
                    // discoverable for first-time TV users.
                    Text(
                        text = "How do I scan?  Open Netflix Pro on your phone, tap My Netflix → Pair TV, then point your camera at this code.",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth(0.85f)
                    )
                }
            }
        }
    }
}

@Composable
private fun TvStepItem(stepNum: String, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(TvAuthRed),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stepNum,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Text(
            text = text,
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 16.sp
        )
    }
}

@Composable
private fun TvPulseStatusBadge(status: String, email: String?) {
    // perf: gate the infinite pulse on the actual pending state. When paired
    // we hold alpha at 1f without spinning a transition at all — saves the
    // rememberInfiniteTransition frame budget after the pairing handshake.
    if (status == "PENDING") {
        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
        val alpha by infiniteTransition.animateFloat(
            initialValue = 0.4f,
            targetValue = 1.0f,
            animationSpec = infiniteRepeatable(
                animation = tween(1000, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "alpha"
        )
        TvPulseStatusBadgeContent(status = status, email = email, dotAlpha = alpha)
    } else {
        TvPulseStatusBadgeContent(status = status, email = email, dotAlpha = 1f)
    }
}

@Composable
private fun TvPulseStatusBadgeContent(status: String, email: String?, dotAlpha: Float) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                if (status == "PAIRED") TvAuthStatusPairedBg
                else Color.White.copy(alpha = 0.1f)
            )
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .alpha(dotAlpha)
                .background(
                    if (status == "PAIRED") TvAuthStatusPaired
                    else TvAuthRed
                )
        )

        Spacer(modifier = Modifier.width(10.dp))

        Text(
            text = if (status == "PAIRED") "TV Unlocked by ${email ?: "Phone"}!" else "Waiting for phone sign in...",
            color = if (status == "PAIRED") TvAuthStatusPaired else Color.White.copy(alpha = 0.85f),
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

// Lightweight email format check. Intentionally permissive: matches the
// pattern `local@domain.tld` where local contains at least one non-space
// char, domain contains at least one dot, and tld is 2+ chars. Rejects `a@`
// and accepts `a+tag@example.co.uk` per the spec.
private fun isPlausibleEmail(input: String): Boolean {
    if (input.isBlank()) return false
    val at = input.indexOf('@')
    if (at <= 0 || at == input.length - 1) return false
    val local = input.substring(0, at)
    val domain = input.substring(at + 1)
    if (local.isBlank() || local.any { it.isWhitespace() }) return false
    if (domain.isBlank() || domain.any { it.isWhitespace() }) return false
    val lastDot = domain.lastIndexOf('.')
    if (lastDot <= 0 || lastDot == domain.length - 1) return false
    val tld = domain.substring(lastDot + 1)
    if (tld.length < 2) return false
    return true
}

private fun generateRandomTvCode(): String {
    // Exclude easily-confused characters: 0/O, 1/I/L.
    val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    val code = (1..6).map { chars[Random.nextInt(chars.length)] }.joinToString("")
    return "NF-$code"
}

private fun generateQrCode(content: String, width: Int, height: Int): Bitmap? {
    return try {
        val writer = QRCodeWriter()
        val bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, width, height)
        // High contrast: black on white — the standard QR convention, and the
        // easiest pattern for a phone camera to read from across a living room.
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
        for (x in 0 until width) {
            for (y in 0 until height) {
                bmp.setPixel(x, y, if (bitMatrix.get(x, y)) AndroidColor.BLACK else AndroidColor.WHITE)
            }
        }
        bmp
    } catch (e: Exception) {
        null
    }
}
