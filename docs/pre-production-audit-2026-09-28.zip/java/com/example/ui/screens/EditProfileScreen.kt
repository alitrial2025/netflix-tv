@file:OptIn(androidx.tv.material3.ExperimentalTvMaterial3Api::class, androidx.tv.foundation.ExperimentalTvFoundationApi::class)
package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.compose.ui.input.key.*
import android.view.KeyEvent
import androidx.tv.material3.*
import coil.compose.AsyncImage
import android.graphics.Bitmap
import com.example.model.Profile
import com.example.ui.NetflixViewModel
import com.example.ui.components.ProfileIcons
import com.example.ui.theme.NetflixBlack
import com.example.ui.theme.NetflixRed
import com.example.ui.theme.NetflixWhite

enum class EditProfileSubScreen {
    MAIN,
    ICON_PICKER,
    LANGUAGE_PICKER,
    NAME_EDITOR,
    GAME_HANDLE_EDITOR,
    DELETE_CONFIRM,
    PIN_EDITOR
}

// 32 Languages arranged into 4 columns matching Image 3
private val LANGUAGE_COLUMNS = listOf(
    listOf("Dansk", "Deutsch", "English", "Español", "Filipino", "Français", "Hrvatski"),
    listOf("Indonesia", "Italiano", "Magyar", "Melayu", "Nederlands", "Norsk bokmål", "Polski", "Português"),
    listOf("Română", "Suomi", "Svenska", "Tiếng Việt", "Türkçe", "Čeština", "Ελληνικά", "Русский"),
    listOf("Українська", "עברית", "العربية", "हिन्दी", "ไทย", "中文", "日本語", "한국어")
)

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun EditProfileScreen(
    profileId: String,
    viewModel: NetflixViewModel,
    onBack: () -> Unit
) {
    val isNewProfile = profileId == "new"
    val profiles by viewModel.profiles.collectAsState()
    val initialProfile = remember(profiles, profileId) {
        if (isNewProfile) {
            Profile(
                id = "new",
                name = "Home",
                avatarColor = Color(0xFFE50914),
                isKid = false,
                avatarUrl = ProfileIcons.ICONS.firstOrNull(),
                pin = null,
                language = "English",
                autoplayNext = true,
                autoplayPreviews = true,
                maturityRating = "18+",
                gameHandle = null
            )
        } else {
            // If the profile was deleted out from under us, fall back to defaults
            // for the legacy id so the screen still renders without a crash, but
            // `isNewProfile` stays false so we know not to call addProfile.
            profiles.find { it.id == profileId }
                ?: Profile(
                    id = profileId,
                    name = "Home",
                    avatarColor = Color(0xFFE50914),
                    isKid = false,
                    avatarUrl = ProfileIcons.ICONS.firstOrNull(),
                    pin = null,
                    language = "English",
                    autoplayNext = true,
                    autoplayPreviews = true,
                    maturityRating = "18+",
                    gameHandle = null
                )
        }
    }

    var currentSubScreen by remember { mutableStateOf(EditProfileSubScreen.MAIN) }

    var name by remember { mutableStateOf(initialProfile.name) }
    var language by remember { mutableStateOf(initialProfile.language) }
    var gameHandle by remember { mutableStateOf(initialProfile.gameHandle ?: "") }
    var avatarUrl by remember { mutableStateOf(initialProfile.avatarUrl ?: ProfileIcons.ICONS.firstOrNull()) }
    var avatarColor by remember { mutableStateOf(initialProfile.avatarColor) }
    var isKid by remember { mutableStateOf(initialProfile.isKid) }
    var maturityRating by remember { mutableStateOf(initialProfile.maturityRating) }
    var autoplayNext by remember { mutableStateOf(initialProfile.autoplayNext) }
    var autoplayPreviews by remember { mutableStateOf(initialProfile.autoplayPreviews) }
    var pin by remember { mutableStateOf(initialProfile.pin ?: "") }

    // Back handling
    BackHandler {
        if (currentSubScreen != EditProfileSubScreen.MAIN) {
            currentSubScreen = EditProfileSubScreen.MAIN
        } else {
            onBack()
        }
    }

    fun saveProfileAndExit() {
        // Validate the name: require 1..25 chars, fall back to "Profile" if blank,
        // and reject pure-whitespace or control-character names.
        val rawName = name.trim()
        val sanitizedName = if (rawName.isEmpty()) "Profile"
            else rawName.filterNot { it.isISOControl() }.take(25).ifBlank { "Profile" }
        // Validate the optional PIN: must be exactly 4 digits or empty (to clear)
        val rawPin = pin.filter { it.isDigit() }
        val sanitizedPin = if (rawPin.isEmpty()) null
            else if (rawPin.length == 4) rawPin
            else rawPin.take(4)
        val finalGameHandle = if (gameHandle.isBlank()) null else gameHandle.trim().take(20)
        if (isNewProfile) {
            viewModel.addProfile(
                name = sanitizedName,
                avatarUrl = avatarUrl,
                avatarColor = avatarColor,
                isKid = isKid,
                pin = sanitizedPin,
                language = language,
                maturityRating = maturityRating,
                gameHandle = finalGameHandle
            )
        } else {
            viewModel.updateProfile(
                initialProfile.copy(
                    name = sanitizedName,
                    language = language,
                    isKid = isKid,
                    maturityRating = maturityRating,
                    autoplayNext = autoplayNext,
                    autoplayPreviews = autoplayPreviews,
                    pin = sanitizedPin,
                    avatarUrl = avatarUrl,
                    avatarColor = avatarColor,
                    gameHandle = finalGameHandle
                )
            )
        }
        onBack()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0F0F))
    ) {
        AnimatedContent(
            targetState = currentSubScreen,
            transitionSpec = {
                if (targetState != EditProfileSubScreen.MAIN) {
                    (slideInHorizontally(
                        animationSpec = tween(280, easing = FastOutSlowInEasing),
                        initialOffsetX = { fullWidth -> (fullWidth * 0.12f).toInt() }
                    ) + fadeIn(animationSpec = tween(240, easing = FastOutSlowInEasing)))
                    .togetherWith(
                        slideOutHorizontally(
                            animationSpec = tween(220, easing = FastOutSlowInEasing),
                            targetOffsetX = { fullWidth -> (-fullWidth * 0.08f).toInt() }
                        ) + fadeOut(animationSpec = tween(180, easing = FastOutSlowInEasing))
                    )
                } else {
                    (slideInHorizontally(
                        animationSpec = tween(280, easing = FastOutSlowInEasing),
                        initialOffsetX = { fullWidth -> (-fullWidth * 0.12f).toInt() }
                    ) + fadeIn(animationSpec = tween(240, easing = FastOutSlowInEasing)))
                    .togetherWith(
                        slideOutHorizontally(
                            animationSpec = tween(220, easing = FastOutSlowInEasing),
                            targetOffsetX = { fullWidth -> (fullWidth * 0.08f).toInt() }
                        ) + fadeOut(animationSpec = tween(180, easing = FastOutSlowInEasing))
                    )
                }
            },
            label = "EditProfileNavigation"
        ) { subScreen ->
            when (subScreen) {
                EditProfileSubScreen.MAIN -> {
                    EditProfileMainView(
                        name = name,
                        language = language,
                        gameHandle = gameHandle,
                        avatarUrl = avatarUrl,
                        avatarColor = avatarColor,
                        isKid = isKid,
                        pin = pin,
                        canDelete = !isNewProfile && profiles.size > 1,
                        onNameClick = { currentSubScreen = EditProfileSubScreen.NAME_EDITOR },
                        onIconClick = { currentSubScreen = EditProfileSubScreen.ICON_PICKER },
                        onKidsToggle = {
                            isKid = !isKid
                            if (isKid) {
                                maturityRating = "7+"
                                if (avatarColor == Color(0xFFE50914)) {
                                    avatarColor = Color(0xFFFF9D2B)
                                }
                            } else {
                                maturityRating = "18+"
                            }
                        },
                        onGameHandleClick = { currentSubScreen = EditProfileSubScreen.GAME_HANDLE_EDITOR },
                        onLanguageClick = { currentSubScreen = EditProfileSubScreen.LANGUAGE_PICKER },
                        onPinClick = { currentSubScreen = EditProfileSubScreen.PIN_EDITOR },
                        onDoneClick = { saveProfileAndExit() },
                        onDeleteClick = { currentSubScreen = EditProfileSubScreen.DELETE_CONFIRM }
                    )
                }

                EditProfileSubScreen.PIN_EDITOR -> {
                    ProfilePinEditorScreen(
                        profileName = name,
                        currentPin = pin,
                        onDismiss = { currentSubScreen = EditProfileSubScreen.MAIN },
                        onSavePin = { newPin ->
                            pin = newPin ?: ""
                            currentSubScreen = EditProfileSubScreen.MAIN
                        }
                    )
                }

                EditProfileSubScreen.ICON_PICKER -> {
                    UpdateProfileIconView(
                        currentProfileName = name,
                        currentAvatarUrl = avatarUrl,
                        currentAvatarColor = avatarColor,
                        onSelectIcon = { selectedUrl ->
                            avatarUrl = selectedUrl
                        },
                        onDone = {
                            currentSubScreen = EditProfileSubScreen.MAIN
                        }
                    )
                }

                EditProfileSubScreen.LANGUAGE_PICKER -> {
                    UpdateProfileLanguageView(
                        selectedLanguage = language,
                        onSelectLanguage = { selected ->
                            language = selected
                        },
                        onDone = {
                            currentSubScreen = EditProfileSubScreen.MAIN
                        }
                    )
                }

                EditProfileSubScreen.NAME_EDITOR -> {
                    ProfileTextEditorScreen(
                        title = "Edit Profile Name",
                        currentText = name,
                        label = "Profile Name",
                        quickSuggestions = listOf("Home", "Derrick", "Karan", "Mom", "Kids", "Family", "Guest"),
                        onDismiss = { currentSubScreen = EditProfileSubScreen.MAIN },
                        onSave = { newName ->
                            name = newName
                            currentSubScreen = EditProfileSubScreen.MAIN
                        }
                    )
                }

                EditProfileSubScreen.GAME_HANDLE_EDITOR -> {
                    ProfileTextEditorScreen(
                        title = "Edit Game Handle",
                        currentText = gameHandle,
                        label = "Game Handle",
                        quickSuggestions = listOf("GamerTag", "ProPlayer", "Shadow", "Speedy", "Legend", "Pixel"),
                        onDismiss = { currentSubScreen = EditProfileSubScreen.MAIN },
                        onSave = { newHandle ->
                            gameHandle = newHandle
                            currentSubScreen = EditProfileSubScreen.MAIN
                        }
                    )
                }

                EditProfileSubScreen.DELETE_CONFIRM -> {
                    DeleteProfileConfirmScreen(
                        profileName = name,
                        onDismiss = { currentSubScreen = EditProfileSubScreen.MAIN },
                        onConfirmDelete = {
                            viewModel.deleteProfile(profileId)
                            onBack()
                        }
                    )
                }
            }
        }
    }
}

// =============================================================================
// 1. MAIN SCREEN VIEW: Exactly matching Image 1
// =============================================================================
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun EditProfileMainView(
    name: String,
    language: String,
    gameHandle: String,
    avatarUrl: String?,
    avatarColor: Color,
    isKid: Boolean,
    pin: String,
    canDelete: Boolean,
    onNameClick: () -> Unit,
    onIconClick: () -> Unit,
    onKidsToggle: () -> Unit,
    onGameHandleClick: () -> Unit,
    onLanguageClick: () -> Unit,
    onPinClick: () -> Unit,
    onDoneClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val initialFocusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(100)
        try { initialFocusRequester.requestFocus() } catch (_: Exception) {}
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 40.dp, bottom = 32.dp, start = 64.dp, end = 64.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left Column: Title, Subtitle, Menu Buttons, Age Rating, Done & Delete
        Column(
            modifier = Modifier
                .width(420.dp)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Edit profile",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Select what you want to change.",
                    fontSize = 15.sp,
                    color = Color(0xFFAAAAAA)
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Menu items
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // 1. Name Option
                    EditProfileMenuButton(
                        icon = Icons.Default.Person,
                        label = "Name",
                        modifier = Modifier.focusRequester(initialFocusRequester),
                        onClick = onNameClick
                    )

                    // 2. Icon Option
                    EditProfileMenuButton(
                        icon = Icons.Default.Mood,
                        label = "Icon",
                        onClick = onIconClick
                    )

                    // 3. Kids Experience Toggle Option
                    EditProfileMenuButton(
                        icon = Icons.Default.ChildCare,
                        label = if (isKid) "Kids experience (ON)" else "Kids experience (OFF)",
                        onClick = onKidsToggle
                    )

                    // 4. Game handle Option
                    EditProfileMenuButton(
                        icon = Icons.Default.SportsEsports,
                        label = if (gameHandle.isNotBlank()) "Game handle ($gameHandle)" else "Game handle",
                        onClick = onGameHandleClick
                    )

                    // 5. Language Option
                    EditProfileMenuButton(
                        icon = Icons.Default.Translate,
                        label = "Language",
                        onClick = onLanguageClick
                    )

                    // 6. Profile Lock PIN Option
                    EditProfileMenuButton(
                        icon = Icons.Default.Lock,
                        label = if (pin.isNotBlank()) "Profile lock (PIN On)" else "Profile lock (PIN Off)",
                        onClick = onPinClick
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Age Rating Tag
                Box(
                    modifier = Modifier
                        .background(
                            if (isKid) Color(0xFFFF9D2B) else Color(0xFF333333),
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (isKid) "12 and under (TV-Y, TV-G, PG, 12)" else "All Age Ratings (18+)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isKid) Color.Black else Color.White
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (isKid) "Only shows titles rated 12 and under for kids and family. Adult and mature content is restricted."
                           else "Showing titles of all age ratings for this profile.",
                    fontSize = 13.sp,
                    color = Color(0xFF999999),
                    lineHeight = 18.sp
                )
                Text(
                    text = "Visit netflix.com/YourAccount to change viewing restrictions.",
                    fontSize = 13.sp,
                    color = Color(0xFF999999),
                    lineHeight = 18.sp
                )
            }

            // Bottom Buttons: Done & Delete Profile
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Done Button (Pill shaped)
                var isDoneFocused by remember { mutableStateOf(false) }
                Surface(
                    onClick = onDoneClick,
                    shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(24.dp)),
                    colors = ClickableSurfaceDefaults.colors(
                        containerColor = Color(0xFF2A2A2A),
                        focusedContainerColor = Color.White
                    ),
                    modifier = Modifier
                        .heightIn(min = 48.dp) // a11y minimum tap target
                        .semantics {
                            contentDescription = "Done"
                            role = Role.Button
                        }
                        .onFocusChanged { isDoneFocused = it.isFocused }
                ) {
                    Text(
                        text = "Done",
                        color = if (isDoneFocused) Color.Black else Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 32.dp, vertical = 10.dp)
                    )
                }

                // Delete Profile Button
                if (canDelete) {
                    var isDeleteFocused by remember { mutableStateOf(false) }
                    Surface(
                        onClick = onDeleteClick,
                        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(24.dp)),
                        colors = ClickableSurfaceDefaults.colors(
                            containerColor = Color.Transparent,
                            focusedContainerColor = Color.White.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier
                            .heightIn(min = 48.dp) // a11y minimum tap target
                            .semantics {
                                contentDescription = "Delete Profile"
                                role = Role.Button
                            }
                            .onFocusChanged { isDeleteFocused = it.isFocused }
                    ) {
                        Text(
                            text = "Delete Profile",
                            color = if (isDeleteFocused) NetflixRed else Color(0xFFCCCCCC),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                        )
                    }
                }
            }
        }

        // Right Column: Profile Avatar Preview with Radial Ambient Glow
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            contentAlignment = Alignment.Center
        ) {
            val glowColor = if (isKid) Color(0xFFFF9D2B) else Color(0xFFE50914)
            val glowBrush = remember(isKid) {
                Brush.radialGradient(
                    colors = listOf(
                        glowColor.copy(alpha = 0.50f),
                        glowColor.copy(alpha = 0.20f),
                        Color.Transparent
                    )
                )
            }
            Box(
                modifier = Modifier
                    .size(360.dp)
                    .drawBehind {
                        drawCircle(
                            brush = glowBrush,
                            radius = size.minDimension / 1.5f
                        )
                    }
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Large Avatar Card
                Box(
                    modifier = Modifier
                        .size(175.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(avatarColor)
                        .shadow(16.dp, RoundedCornerShape(12.dp))
                ) {
                    if (!avatarUrl.isNullOrBlank()) {
                        val context = androidx.compose.ui.platform.LocalContext.current
                        val density = androidx.compose.ui.platform.LocalDensity.current
                        val avSizePx = remember(density) { with(density) { 175.dp.toPx().toInt().coerceAtLeast(1) } }
                        val avatarRequest = remember(avatarUrl, context, avSizePx) {
                            coil.request.ImageRequest.Builder(context)
                                .data(avatarUrl)
                                .size(avSizePx, avSizePx)
                                .bitmapConfig(Bitmap.Config.RGB_565)
                                .crossfade(false)
                                .memoryCacheKey("edit_main_avatar_${avatarUrl.hashCode()}")
                                .memoryCachePolicy(coil.request.CachePolicy.ENABLED)
                                .diskCachePolicy(coil.request.CachePolicy.ENABLED)
                                .allowHardware(true)
                                .build()
                        }
                        AsyncImage(
                            model = avatarRequest,
                            contentDescription = "Profile Avatar",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = name.take(1).uppercase(),
                                fontSize = 64.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    if (isKid) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .background(Color(0xFFFF9D2B).copy(alpha = 0.92f))
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "KIDS",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.Black,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Profile Name (e.g., "Home")
                Text(
                    text = name,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Profile Language (e.g., "English")
                Text(
                    text = language,
                    fontSize = 14.sp,
                    color = Color(0xFFAAAAAA),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

// Menu pill button component
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun EditProfileMenuButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }

    Surface(
        onClick = onClick,
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(24.dp)),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = Color(0xFF1E1E1E),
            focusedContainerColor = Color.White
        ),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.02f),
        modifier = modifier
            .fillMaxWidth(0.72f)
            .heightIn(min = 48.dp) // a11y minimum tap target
            .semantics(mergeDescendants = true) {
                contentDescription = label
                role = Role.Button
            }
            .onFocusChanged { isFocused = it.isFocused }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isFocused) Color.Black else Color.White,
                modifier = Modifier.size(20.dp)
            )

            Text(
                text = label,
                color = if (isFocused) Color.Black else Color.White,
                fontSize = 15.sp,
                fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

// =============================================================================
// 2. ICON PICKER VIEW: Exactly matching Image 2 with Grouped Categories & Smooth D-Pad Sliding
// =============================================================================
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun UpdateProfileIconView(
    currentProfileName: String,
    currentAvatarUrl: String?,
    currentAvatarColor: Color,
    onSelectIcon: (String) -> Unit,
    onDone: () -> Unit
) {
    val initialFocusRequester = remember { FocusRequester() }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    var focusedCategoryIndex by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(100)
        try { initialFocusRequester.requestFocus() } catch (_: Exception) {}
    }

    // Smoothly scroll the categories list when row changes
    LaunchedEffect(focusedCategoryIndex) {
        try {
            listState.animateScrollToItem(
                index = focusedCategoryIndex.coerceAtLeast(0),
                scrollOffset = -40
            )
        } catch (_: Exception) {}
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 36.dp, bottom = 16.dp, start = 56.dp, end = 56.dp)
    ) {
        // Header Row: Title & Subtitle on left, Profile mini preview on right
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Edit profile",
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Update your profile icon.",
                    fontSize = 15.sp,
                    color = Color(0xFFAAAAAA)
                )
            }

            // Top Right Mini Profile Indicator (Matching Image 2)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = currentProfileName,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(currentAvatarColor)
                ) {
                    if (!currentAvatarUrl.isNullOrBlank()) {
                        val ctx = androidx.compose.ui.platform.LocalContext.current
                        val density = androidx.compose.ui.platform.LocalDensity.current
                        val miniSize = remember(density) { with(density) { 48.dp.toPx().toInt().coerceAtLeast(1) } }
                        val miniRequest = remember(currentAvatarUrl, ctx, miniSize) {
                            coil.request.ImageRequest.Builder(ctx)
                                .data(currentAvatarUrl)
                                .size(miniSize, miniSize)
                                .bitmapConfig(Bitmap.Config.RGB_565)
                                .crossfade(false)
                                .memoryCacheKey("edit_mini_avatar_${currentAvatarUrl.hashCode()}")
                                .memoryCachePolicy(coil.request.CachePolicy.ENABLED)
                                .diskCachePolicy(coil.request.CachePolicy.ENABLED)
                                .allowHardware(true)
                                .build()
                        }
                        AsyncImage(
                            model = miniRequest,
                            contentDescription = "Current Avatar",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                text = currentProfileName.take(1).uppercase(),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Categories with Smooth Sliding Horizontal Rows of Icons
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(28.dp),
            contentPadding = PaddingValues(bottom = 48.dp)
        ) {
            items(
                count = ProfileIcons.CATEGORIES.size,
                key = { ProfileIcons.CATEGORIES[it].id },
                contentType = { "icon_category_row" }
            ) { catIdx ->
                val category = ProfileIcons.CATEGORIES[catIdx]
                IconCategoryRow(
                    category = category,
                    categoryIndex = catIdx,
                    isCurrentCategoryFocused = focusedCategoryIndex == catIdx,
                    selectedAvatarUrl = currentAvatarUrl,
                    isFirstCategory = catIdx == 0,
                    initialFocusRequester = initialFocusRequester,
                    onRowFocused = {
                        focusedCategoryIndex = catIdx
                    },
                    onSelectIcon = onSelectIcon
                )
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun IconCategoryRow(
    category: com.example.ui.components.ProfileIconCategory,
    categoryIndex: Int,
    isCurrentCategoryFocused: Boolean,
    selectedAvatarUrl: String?,
    isFirstCategory: Boolean,
    initialFocusRequester: FocusRequester,
    onRowFocused: () -> Unit,
    onSelectIcon: (String) -> Unit
) {
    val cardSize = 92.dp
    val gap = 14.dp

    var focusedIconIndex by remember { mutableIntStateOf(0) }
    var isRowFocused by remember { mutableStateOf(false) }

    val density = androidx.compose.ui.platform.LocalDensity.current

    // GPU-accelerated horizontal sliding — translationX instead of layout offset
    val targetScrollPx = remember(focusedIconIndex, isRowFocused) {
        if (isRowFocused && focusedIconIndex > 0) {
            with(density) { (focusedIconIndex * (cardSize.value + gap.value)).dp.toPx() }
        } else 0f
    }

    val animatedScrollPx by animateFloatAsState(
        targetValue = targetScrollPx,
        animationSpec = tween(durationMillis = 250, easing = FastOutSlowInEasing),
        label = "iconRowScroll_${category.id}"
    )

    val context = androidx.compose.ui.platform.LocalContext.current

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged {
                if (it.hasFocus) {
                    isRowFocused = true
                    onRowFocused()
                } else {
                    isRowFocused = false
                }
            },
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Category Name on Left
        Box(
            modifier = Modifier
                .width(150.dp)
                .padding(end = 16.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Text(
                text = category.title,
                fontSize = if (category.title == "COBRA KAI") 17.sp else 16.sp,
                fontWeight = FontWeight.Bold,
                color = if (isRowFocused) Color.White else Color(0xFFBBBBBB),
                lineHeight = 20.sp
            )
        }

        // GPU-accelerated Horizontal Sliding Row Container
        Box(
            modifier = Modifier
                .weight(1f)
                .height(cardSize + 28.dp)
                .clipToBounds()
        ) {
            Row(
                modifier = Modifier
                    .wrapContentWidth(align = Alignment.Start, unbounded = true)
                    .graphicsLayer { translationX = -animatedScrollPx }
                    .padding(vertical = 10.dp, horizontal = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(gap),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Hoist cardSize-in-px out of the per-icon loop so it's computed
                // once per row, not once per icon. Avoids redundant (density, cardSize)
                // lookups across ~10 icons per row.
                val iconSizePx = remember(density, cardSize) {
                    with(density) { cardSize.toPx().toInt().coerceAtLeast(1) }
                }
                category.icons.forEachIndexed { index, iconUrl ->
                    val isSelected = iconUrl == selectedAvatarUrl

                    // Only render icons that are near the viewport (±4 from focused)
                    val isNearViewport = kotlin.math.abs(index - focusedIconIndex) <= 6

                    if (isNearViewport) {
                        val iconRequest = remember(iconUrl, context, iconSizePx) {
                            coil.request.ImageRequest.Builder(context)
                                .data(iconUrl)
                                .size(iconSizePx, iconSizePx)
                                .bitmapConfig(Bitmap.Config.RGB_565)
                                .crossfade(false)
                                // Avatar icons are shared across many profile flows; using the URL
                                // as the cache key lets the same icon in different surfaces share
                                // a single bitmap.
                                .memoryCacheKey("profile_icon_${iconUrl.hashCode()}")
                                .memoryCachePolicy(coil.request.CachePolicy.ENABLED)
                                .diskCachePolicy(coil.request.CachePolicy.ENABLED)
                                .allowHardware(true)
                                .build()
                        }

                        Surface(
                            onClick = { onSelectIcon(iconUrl) },
                            shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(10.dp)),
                            colors = ClickableSurfaceDefaults.colors(
                                containerColor = Color(0xFF222222),
                                focusedContainerColor = Color(0xFF222222)
                            ),
                            border = ClickableSurfaceDefaults.border(
                                border = if (isSelected) Border(BorderStroke(3.dp, NetflixRed)) else Border.None,
                                focusedBorder = Border(BorderStroke(3.5.dp, Color.White))
                            ),
                            scale = ClickableSurfaceDefaults.scale(focusedScale = 1.08f),
                            modifier = Modifier
                                .size(cardSize)
                                .then(
                                    if (isFirstCategory && index == 0) Modifier.focusRequester(initialFocusRequester)
                                    else Modifier
                                )
                                .onFocusChanged {
                                    if (it.isFocused) {
                                        focusedIconIndex = index
                                        onRowFocused()
                                    }
                                }
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                AsyncImage(
                                    model = iconRequest,
                                    contentDescription = "${category.title} Icon",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )

                                // Kids badge overlay
                                if (category.id == "classics" && index in listOf(3, 4, 5, 6, 7)) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(4.dp)
                                            .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(2.dp))
                                            .padding(horizontal = 3.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = "kids",
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = NetflixRed
                                        )
                                    }
                                }

                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(4.dp)
                                            .size(18.dp)
                                            .background(NetflixRed, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = Color.White,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        // Placeholder spacer for off-screen icons to maintain correct positioning
                        Spacer(modifier = Modifier.size(cardSize))
                    }
                }
            }
        }
    }
}

// =============================================================================
// 3. LANGUAGE PICKER VIEW: Exactly matching Image 3 (4 Columns of Languages)
// =============================================================================
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun UpdateProfileLanguageView(
    selectedLanguage: String,
    onSelectLanguage: (String) -> Unit,
    onDone: () -> Unit
) {
    val initialFocusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(100)
        try { initialFocusRequester.requestFocus() } catch (_: Exception) {}
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 40.dp, bottom = 32.dp, start = 64.dp, end = 64.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = "Edit profile",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Update your language.",
                fontSize = 15.sp,
                color = Color(0xFFAAAAAA)
            )

            Spacer(modifier = Modifier.height(36.dp))

            // 4 Clean Columns of Languages (Matching Image 3)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(32.dp)
            ) {
                LANGUAGE_COLUMNS.forEachIndexed { colIndex, columnLanguages ->
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        columnLanguages.forEach { lang ->
                            val isSelected = lang.equals(selectedLanguage, ignoreCase = true)
                            var isFocused by remember { mutableStateOf(false) }

                            Surface(
                                onClick = { onSelectLanguage(lang) },
                                shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(20.dp)),
                                colors = ClickableSurfaceDefaults.colors(
                                    containerColor = if (isSelected) Color.White else Color.Transparent,
                                    focusedContainerColor = Color.White
                                ),
                                scale = ClickableSurfaceDefaults.scale(focusedScale = 1.03f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onFocusChanged { isFocused = it.isFocused }
                                    .then(
                                        if (isSelected) Modifier.focusRequester(initialFocusRequester)
                                        else Modifier
                                    )
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 7.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    Text(
                                        text = lang,
                                        fontSize = 14.sp,
                                        fontWeight = if (isSelected || isFocused) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected || isFocused) Color.Black else Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom Done Button (Pill shape on bottom left)
        var isDoneFocused by remember { mutableStateOf(false) }
        Surface(
            onClick = onDone,
            shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(24.dp)),
            colors = ClickableSurfaceDefaults.colors(
                containerColor = Color(0xFF2A2A2A),
                focusedContainerColor = Color.White
            ),
            modifier = Modifier.onFocusChanged { isDoneFocused = it.isFocused }
        ) {
            Text(
                text = "Done",
                color = if (isDoneFocused) Color.Black else Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 36.dp, vertical = 10.dp)
            )
        }
    }
}

// =============================================================================
// 4. TEXT EDITOR FULL SCREEN (For Name & Game Handle with TV Keyboard)
// =============================================================================
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun ProfileTextEditorScreen(
    title: String,
    currentText: String,
    label: String,
    quickSuggestions: List<String>,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var editedText by remember { mutableStateOf(currentText) }
    val textFieldRequester = remember { FocusRequester() }
    val firstKeyRequester = remember { FocusRequester() }
    val closeButtonRequester = remember { FocusRequester() }
    val backspaceRequester = remember { FocusRequester() }
    val saveButtonRequester = remember { FocusRequester() }

    val keyboardRows = listOf(
        listOf("A", "B", "C", "D", "E", "F", "G", "H", "I", "J"),
        listOf("K", "L", "M", "N", "O", "P", "Q", "R", "S", "T"),
        listOf("U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3"),
        listOf("4", "5", "6", "7", "8", "9", "-", "_", ".", " ")
    )

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(100)
        try { firstKeyRequester.requestFocus() } catch (_: Exception) {}
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NetflixBlack)
            .padding(horizontal = 64.dp, vertical = 36.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PROFILE SETTINGS",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = NetflixRed,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }

                Surface(
                    onClick = onDismiss,
                    shape = ClickableSurfaceDefaults.shape(CircleShape),
                    colors = ClickableSurfaceDefaults.colors(
                        containerColor = Color.White.copy(alpha = 0.1f),
                        focusedContainerColor = NetflixRed
                    ),
                    modifier = Modifier
                        .size(48.dp) // a11y minimum tap target
                        .semantics {
                            contentDescription = "Close"
                            role = Role.Button
                        }
                        .focusRequester(closeButtonRequester)
                        .onPreviewKeyEvent { keyEvent ->
                            if (keyEvent.type == androidx.compose.ui.input.key.KeyEventType.KeyDown &&
                                keyEvent.nativeKeyEvent.keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN) {
                                try { textFieldRequester.requestFocus() } catch (_: Exception) {}
                                true
                            } else false
                        }
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(22.dp))
                    }
                }
            }

            // Center: Text Input Box & Quick Suggestions & Keyboard
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.width(620.dp)
            ) {
                // Text Input Box
                OutlinedTextField(
                    value = editedText,
                    onValueChange = { input ->
                        // Strip control chars (newlines, tabs, etc.) so the name
                        // and PIN stay printable. Cap at 25 to match the on-screen
                        // keyboard's enforced length.
                        val sanitized = input.filterNot { it.isISOControl() }
                        if (sanitized.length <= 25) editedText = sanitized
                    },
                    label = { Text(label) },
                    singleLine = true,
                    maxLines = 1,
                    trailingIcon = {
                        if (editedText.isNotEmpty()) {
                            androidx.compose.material3.IconButton(onClick = { editedText = "" }) {
                                androidx.compose.material3.Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = NetflixWhite,
                        unfocusedBorderColor = Color.Gray,
                        focusedLabelColor = NetflixWhite,
                        unfocusedLabelColor = Color.Gray,
                        cursorColor = NetflixRed,
                        focusedContainerColor = Color.Black.copy(alpha = 0.6f),
                        unfocusedContainerColor = Color.Black.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(textFieldRequester)
                        .onPreviewKeyEvent { keyEvent ->
                            if (keyEvent.type == androidx.compose.ui.input.key.KeyEventType.KeyDown) {
                                when (keyEvent.nativeKeyEvent.keyCode) {
                                    android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                                        try { firstKeyRequester.requestFocus() } catch (_: Exception) {}
                                        true
                                    }
                                    android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                                        try { closeButtonRequester.requestFocus() } catch (_: Exception) {}
                                        true
                                    }
                                    else -> false
                                }
                            } else false
                        },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            if (editedText.isNotBlank()) onSave(editedText.trim())
                        }
                    )
                )

                if (quickSuggestions.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(14.dp))

                    // Quick Suggestions Chips
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(quickSuggestions, key = { it }) { suggestion ->
                            Surface(
                                onClick = { editedText = suggestion },
                                shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(16.dp)),
                                colors = ClickableSurfaceDefaults.colors(
                                    containerColor = Color.White.copy(alpha = 0.08f),
                                    focusedContainerColor = Color.White.copy(alpha = 0.3f)
                                ),
                                border = ClickableSurfaceDefaults.border(
                                    border = Border(BorderStroke(1.dp, Color.White.copy(alpha = 0.1f))),
                                    focusedBorder = Border(BorderStroke(1.5.dp, NetflixWhite))
                                ),
                                modifier = Modifier.onPreviewKeyEvent { keyEvent ->
                                    if (keyEvent.type == androidx.compose.ui.input.key.KeyEventType.KeyDown) {
                                        when (keyEvent.nativeKeyEvent.keyCode) {
                                            android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                                                try { textFieldRequester.requestFocus() } catch (_: Exception) {}
                                                true
                                            }
                                            android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                                                try { firstKeyRequester.requestFocus() } catch (_: Exception) {}
                                                true
                                            }
                                            else -> false
                                        }
                                    } else false
                                }
                            ) {
                                Text(
                                    text = suggestion,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // On-Screen TV Keyboard
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    keyboardRows.forEachIndexed { rowIdx, rowKeys ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            rowKeys.forEachIndexed { colIdx, key ->
                                val isFirstKey = rowIdx == 0 && colIdx == 0
                                var isKeyFocused by remember { mutableStateOf(false) }
                                Surface(
                                    onClick = {
                                        if (key == " ") {
                                            if (editedText.isNotEmpty() && !editedText.endsWith(" ")) {
                                                editedText += " "
                                            }
                                        } else {
                                            if (editedText.length < 25) editedText += key
                                        }
                                    },
                                    shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(4.dp)),
                                    colors = ClickableSurfaceDefaults.colors(
                                        containerColor = Color.White.copy(alpha = 0.1f),
                                        focusedContainerColor = Color.White
                                    ),
                                    modifier = Modifier
                                        .size(width = 46.dp, height = 48.dp) // 48dp tall = a11y min
                                        .then(if (isFirstKey) Modifier.focusRequester(firstKeyRequester) else Modifier)
                                        .onFocusChanged { isKeyFocused = it.isFocused }
                                        .onPreviewKeyEvent { keyEvent ->
                                            if (keyEvent.type == androidx.compose.ui.input.key.KeyEventType.KeyDown &&
                                                rowIdx == 0 && keyEvent.nativeKeyEvent.keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP) {
                                                try { textFieldRequester.requestFocus() } catch (_: Exception) {}
                                                true
                                            } else false
                                        }
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (key == " ") "SPACE" else key,
                                            color = if (isKeyFocused) Color.Black else Color.White,
                                            fontSize = if (key == " ") 10.sp else 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Keyboard Action Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        var isBackspaceFocused by remember { mutableStateOf(false) }
                        Surface(
                            onClick = {
                                if (editedText.isNotEmpty()) {
                                    editedText = editedText.dropLast(1)
                                }
                            },
                            shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(4.dp)),
                            colors = ClickableSurfaceDefaults.colors(
                                containerColor = Color.White.copy(alpha = 0.1f),
                                focusedContainerColor = Color.White
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp) // a11y minimum tap target
                                .focusRequester(backspaceRequester)
                                .onFocusChanged { isBackspaceFocused = it.isFocused }
                                .onPreviewKeyEvent { keyEvent ->
                                    if (keyEvent.type == androidx.compose.ui.input.key.KeyEventType.KeyDown &&
                                        keyEvent.nativeKeyEvent.keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN) {
                                        try { saveButtonRequester.requestFocus() } catch (_: Exception) {}
                                        true
                                    } else false
                                }
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(imageVector = Icons.Default.Backspace, contentDescription = "Backspace", tint = if (isBackspaceFocused) Color.Black else Color.White, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Backspace", color = if (isBackspaceFocused) Color.Black else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        var isClearAllFocused by remember { mutableStateOf(false) }
                        Surface(
                            onClick = { editedText = "" },
                            shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(4.dp)),
                            colors = ClickableSurfaceDefaults.colors(
                                containerColor = Color.White.copy(alpha = 0.1f),
                                focusedContainerColor = NetflixRed
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp) // a11y minimum tap target
                                .onFocusChanged { isClearAllFocused = it.isFocused }
                                .onPreviewKeyEvent { keyEvent ->
                                    if (keyEvent.type == androidx.compose.ui.input.key.KeyEventType.KeyDown &&
                                        keyEvent.nativeKeyEvent.keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN) {
                                        try { saveButtonRequester.requestFocus() } catch (_: Exception) {}
                                        true
                                    } else false
                                }
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Clear All", color = if (isClearAllFocused) Color.White else Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Bottom Action Row
            Row(
                modifier = Modifier.width(620.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .weight(1f)
                        .onPreviewKeyEvent { keyEvent ->
                            if (keyEvent.type == androidx.compose.ui.input.key.KeyEventType.KeyDown &&
                                keyEvent.nativeKeyEvent.keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP) {
                                try { backspaceRequester.requestFocus() } catch (_: Exception) {}
                                true
                            } else false
                        },
                    colors = ButtonDefaults.colors(
                        containerColor = Color.White.copy(alpha = 0.1f),
                        contentColor = Color.White,
                        focusedContainerColor = Color.White.copy(alpha = 0.25f),
                        focusedContentColor = Color.White
                    ),
                    shape = ButtonDefaults.shape(RoundedCornerShape(6.dp))
                ) {
                    Text("Cancel", modifier = Modifier.padding(vertical = 8.dp), fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        if (editedText.isNotBlank()) onSave(editedText.trim())
                    },
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(saveButtonRequester)
                        .onPreviewKeyEvent { keyEvent ->
                            if (keyEvent.type == androidx.compose.ui.input.key.KeyEventType.KeyDown &&
                                keyEvent.nativeKeyEvent.keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP) {
                                try { backspaceRequester.requestFocus() } catch (_: Exception) {}
                                true
                            } else false
                        },
                    colors = ButtonDefaults.colors(
                        containerColor = NetflixWhite,
                        contentColor = Color.Black,
                        focusedContainerColor = NetflixWhite,
                        focusedContentColor = Color.Black
                    ),
                    shape = ButtonDefaults.shape(RoundedCornerShape(6.dp))
                ) {
                    Text("Save", modifier = Modifier.padding(vertical = 8.dp), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// =============================================================================
// 5. DELETE PROFILE CONFIRMATION FULL SCREEN
// =============================================================================
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun DeleteProfileConfirmScreen(
    profileName: String,
    onDismiss: () -> Unit,
    onConfirmDelete: () -> Unit
) {
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(100)
        try { focusRequester.requestFocus() } catch (_: Exception) {}
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NetflixBlack)
            .padding(horizontal = 64.dp, vertical = 48.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .width(520.dp)
                .background(Color(0xFF1B1B1B), RoundedCornerShape(16.dp))
                .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                .padding(36.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .background(NetflixRed.copy(alpha = 0.2f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = NetflixRed, modifier = Modifier.size(36.dp))
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Delete Profile?",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Are you sure you want to delete '$profileName'? This profile's viewing history, ratings, and My List will be permanently removed. This action cannot be undone.",
                style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                color = Color.LightGray,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(28.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f).focusRequester(focusRequester),
                    colors = ButtonDefaults.colors(
                        containerColor = Color.White.copy(alpha = 0.1f),
                        contentColor = Color.White,
                        focusedContainerColor = Color.White,
                        focusedContentColor = Color.Black
                    ),
                    shape = ButtonDefaults.shape(RoundedCornerShape(6.dp))
                ) {
                    Text("Cancel", modifier = Modifier.padding(vertical = 10.dp), fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onConfirmDelete,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.colors(
                        containerColor = NetflixRed,
                        contentColor = Color.White,
                        focusedContainerColor = Color(0xFFB81D24),
                        focusedContentColor = Color.White
                    ),
                    shape = ButtonDefaults.shape(RoundedCornerShape(6.dp))
                ) {
                    Text("Delete", modifier = Modifier.padding(vertical = 10.dp), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// =============================================================================
// 6. PROFILE PIN EDITOR SCREEN
// =============================================================================
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun ProfilePinEditorScreen(
    profileName: String,
    currentPin: String,
    onDismiss: () -> Unit,
    onSavePin: (String?) -> Unit
) {
    var enteredPin by remember { mutableStateOf(currentPin.filter { it.isDigit() }.take(4)) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val firstKeyFocusRequester = remember { FocusRequester() }
    val okFocusRequester = remember { FocusRequester() }
    var isOkFocused by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(100)
        try { firstKeyFocusRequester.requestFocus() } catch (_: Exception) {}
    }

    // When 4 digits are completed, auto-focus OK button for immediate confirmation
    val isPinComplete = enteredPin.length == 4
    LaunchedEffect(isPinComplete) {
        if (isPinComplete) {
            kotlinx.coroutines.delay(80)
            try { okFocusRequester.requestFocus() } catch (_: Exception) {}
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(horizontal = 64.dp, vertical = 24.dp)
            .onPreviewKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyDown) {
                    when (keyEvent.nativeKeyEvent.keyCode) {
                        KeyEvent.KEYCODE_0, KeyEvent.KEYCODE_NUMPAD_0 -> {
                            if (enteredPin.length < 4) {
                                errorMessage = null
                                enteredPin += "0"
                            }
                            true
                        }
                        in KeyEvent.KEYCODE_1..KeyEvent.KEYCODE_9 -> {
                            val digit = (keyEvent.nativeKeyEvent.keyCode - KeyEvent.KEYCODE_1 + 1).toString()
                            if (enteredPin.length < 4) {
                                errorMessage = null
                                enteredPin += digit
                            }
                            true
                        }
                        in KeyEvent.KEYCODE_NUMPAD_1..KeyEvent.KEYCODE_NUMPAD_9 -> {
                            val digit = (keyEvent.nativeKeyEvent.keyCode - KeyEvent.KEYCODE_NUMPAD_1 + 1).toString()
                            if (enteredPin.length < 4) {
                                errorMessage = null
                                enteredPin += digit
                            }
                            true
                        }
                        KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                            if (enteredPin.length == 4) {
                                onSavePin(enteredPin)
                                true
                            } else {
                                errorMessage = "PIN must be 4 digits"
                                true
                            }
                        }
                        KeyEvent.KEYCODE_DEL -> {
                            if (enteredPin.isNotEmpty()) {
                                errorMessage = null
                                enteredPin = enteredPin.dropLast(1)
                            }
                            true
                        }
                        KeyEvent.KEYCODE_BACK -> {
                            onDismiss()
                            true
                        }
                        else -> false
                    }
                } else false
            },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .width(500.dp)
                .background(Color(0xFF0A0A0A), RoundedCornerShape(16.dp))
                .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                .padding(horizontal = 32.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(Color.White.copy(alpha = 0.12f), CircleShape)
                    .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = if (currentPin.isBlank()) "Create Profile Lock PIN" else "Change Profile PIN",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Enter a 4-digit PIN to lock $profileName's profile.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.LightGray,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 4 Pin Slots with glowing active focus
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until 4) {
                    val isFilled = i < enteredPin.length
                    val isCurrent = i == enteredPin.length
                    Box(
                        modifier = Modifier
                            .size(width = 44.dp, height = 50.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                when {
                                    isFilled -> Color.White.copy(alpha = 0.15f)
                                    isCurrent -> Color.White.copy(alpha = 0.08f)
                                    else -> Color.White.copy(alpha = 0.04f)
                                }
                            )
                            .border(
                                width = if (isCurrent) 2.dp else 1.dp,
                                color = when {
                                    isFilled -> Color.White
                                    isCurrent -> Color.White
                                    else -> Color.White.copy(alpha = 0.25f)
                                },
                                shape = RoundedCornerShape(10.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isFilled) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .background(Color.White, CircleShape)
                            )
                        }
                    }
                }
            }

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = errorMessage ?: "",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            } else {
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Keypad
            val keypad = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("Clear", "0", "Del")
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                keypad.forEachIndexed { rowIdx, row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEachIndexed { colIdx, digit ->
                            val isFirstBtn = (rowIdx == 0 && colIdx == 0)
                            var isKeyFocused by remember { mutableStateOf(false) }
                            Surface(
                                onClick = {
                                    errorMessage = null
                                    when (digit) {
                                        "Clear" -> enteredPin = ""
                                        "Del" -> if (enteredPin.isNotEmpty()) enteredPin = enteredPin.dropLast(1)
                                        else -> {
                                            if (enteredPin.length < 4) {
                                                enteredPin += digit
                                            }
                                        }
                                    }
                                },
                                shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(8.dp)),
                                colors = ClickableSurfaceDefaults.colors(
                                    containerColor = Color.White.copy(alpha = 0.08f),
                                    focusedContainerColor = Color.White
                                ),
                                scale = ClickableSurfaceDefaults.scale(focusedScale = 1.08f),
                                modifier = Modifier
                                    .size(width = 76.dp, height = 46.dp) // 46dp tall
                                    .then(if (isFirstBtn) Modifier.focusRequester(firstKeyFocusRequester) else Modifier)
                                    .onFocusChanged { isKeyFocused = it.isFocused }
                            ) {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = digit,
                                        color = if (isKeyFocused) Color.Black else Color.White,
                                        fontSize = if (digit.length > 1) 12.sp else 18.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Prominent OK Confirmation Button
            Button(
                onClick = {
                    if (isPinComplete) {
                        onSavePin(enteredPin)
                    } else {
                        errorMessage = "PIN must be 4 digits"
                    }
                },
                enabled = isPinComplete,
                modifier = Modifier
                    .fillMaxWidth()
                    .focusRequester(okFocusRequester)
                    .onFocusChanged { isOkFocused = it.isFocused },
                colors = ButtonDefaults.colors(
                    containerColor = if (isPinComplete) Color.White else Color.White.copy(alpha = 0.12f),
                    contentColor = if (isPinComplete) Color.Black else Color.White.copy(alpha = 0.4f),
                    focusedContainerColor = Color.White,
                    focusedContentColor = Color.Black,
                    disabledContainerColor = Color.White.copy(alpha = 0.08f),
                    disabledContentColor = Color.White.copy(alpha = 0.4f)
                ),
                shape = ButtonDefaults.shape(RoundedCornerShape(8.dp))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = if (isOkFocused || isPinComplete) Color.Black else Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (isPinComplete) "OK • Confirm & Set PIN" else "OK (Enter 4 digits)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons (Cancel / Turn Off)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.colors(
                        containerColor = Color.White.copy(alpha = 0.1f),
                        contentColor = Color.White,
                        focusedContainerColor = Color.White,
                        focusedContentColor = Color.Black
                    ),
                    shape = ButtonDefaults.shape(RoundedCornerShape(6.dp))
                ) {
                    Text("Cancel", modifier = Modifier.padding(vertical = 6.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                if (currentPin.isNotBlank()) {
                    Button(
                        onClick = { onSavePin(null) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.colors(
                            containerColor = Color.White.copy(alpha = 0.1f),
                            contentColor = Color.White,
                            focusedContainerColor = Color.White,
                            focusedContentColor = Color.Black
                        ),
                        shape = ButtonDefaults.shape(RoundedCornerShape(6.dp))
                    ) {
                        Text("Turn Off", modifier = Modifier.padding(vertical = 6.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
