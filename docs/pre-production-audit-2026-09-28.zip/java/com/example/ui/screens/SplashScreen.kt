package com.example.ui.screens

import android.media.MediaPlayer
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.NetflixBlack
import com.example.ui.theme.NetflixRed
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
fun SplashScreen(
    isWarmupFinished: Boolean = true,
    onSplashComplete: () -> Unit
) {
    val context = LocalContext.current.applicationContext
    var logoSize by remember { mutableStateOf(IntSize.Zero) }

    // perf: TV apps should not let Back exit the splash. Swallow Back here.
    BackHandler(enabled = true) { /* no-op: prevent exit on splash */ }

    // perf: log first-paint so cold-start latency is measurable in logcat.
    LaunchedEffect(Unit) {
        android.util.Log.i("AppStart", "splash shown")
    }

    // Guard against re-firing onSplashComplete on config change / recomposition.
    val hasNavigated = remember { mutableStateOf(false) }

    // Keep the latest warmup flag readable from inside the animation coroutine
    val warmupFinished by rememberUpdatedState(isWarmupFinished)

    // Create the MediaPlayer OFF the main thread so first-frame rendering is never
    // blocked by audio decoding. It has ~2.7s of animation lead time to be ready.
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    LaunchedEffect(Unit) {
        val player = withContext(Dispatchers.IO) {
            try {
                MediaPlayer.create(context, R.raw.netflix_tudum)
            } catch (_: Exception) {
                null
            }
        }
        mediaPlayer = player
    }
    DisposableEffect(Unit) {
        onDispose {
            try {
                mediaPlayer?.stop()
                mediaPlayer?.release()
            } catch (_: Exception) {}
            mediaPlayer = null
        }
    }

    // Mathematically calculated proportions of "N" within the NETFLIX logo
    val nLeftPercent = 0.043f
    val nWidthPercent = 0.0945f
    val nRightPercent = nLeftPercent + nWidthPercent // 0.1375f
    val nCenterPercent = nLeftPercent + nWidthPercent / 2f // 0.09025f

    // Animation states
    val introAlpha = remember { Animatable(0f) }
    val wipeProgress = remember { Animatable(1f) }
    val slideOffset = remember { Animatable(0f) }
    val crossfadeAlpha = remember { Animatable(0f) }
    val spinnerAlpha = remember { Animatable(0f) }
    val zoomAlpha = remember { Animatable(1f) }
    val tadumScale = remember { Animatable(1f) }
    val breathScale = remember { Animatable(1f) }
    val glowAlpha = remember { Animatable(0f) }

    // Reusable path for the wipe mask — zero per-frame allocations
    val wipeCoverPath = remember { Path() }

    // Radial red glow behind the N (ta-dum light bloom). Hardware-cheap:
    // one gradient fill + alpha via graphicsLayer, no saveLayer.
    val glowBrush = remember {
        Brush.radialGradient(
            colorStops = arrayOf(
                0.0f to NetflixRed.copy(alpha = 0.85f),
                0.35f to NetflixRed.copy(alpha = 0.35f),
                1.0f to Color.Transparent
            )
        )
    }

    LaunchedEffect(Unit) {
        // 0. Gentle cinematic fade-in of the full wordmark
        introAlpha.animateTo(1f, tween(durationMillis = 450, easing = FastOutSlowInEasing))

        // 1. Pause on the full logo for recognition & initial profile load time
        delay(850)

        // 2. Wipe ETFLIX from right to left, leaving ONLY the N intact at the end
        wipeProgress.animateTo(
            targetValue = nRightPercent,
            animationSpec = tween(durationMillis = 1350, easing = LinearEasing)
        )

        // 3. Slide N to the exact center smoothly while crossfading/morphing to the standalone N logo
        val targetShift = if (logoSize.width > 0) (logoSize.width * (0.50f - nCenterPercent)) else 300f
        launch {
            crossfadeAlpha.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 950, easing = FastOutSlowInEasing)
            )
        }
        slideOffset.animateTo(
            targetValue = targetShift,
            animationSpec = tween(durationMillis = 950, easing = FastOutSlowInEasing)
        )

        // Fade in the spinner below
        launch {
            spinnerAlpha.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 350)
            )
        }

        // 4. The "N" breathes: subtle scale-up + red glow bloom while holding center stage
        launch {
            glowAlpha.animateTo(0.75f, tween(durationMillis = 700, easing = FastOutSlowInEasing))
        }
        breathScale.animateTo(
            targetValue = 1.05f,
            animationSpec = tween(durationMillis = 750, easing = FastOutSlowInEasing)
        )

        // Extended hold on the N logo so profile selection & initial rows have plenty of time to prepare
        delay(900)

        // 5. Play the dramatic Netflix "Tadum" sound & zoom effect!
        try {
            mediaPlayer?.start()
        } catch (_: Exception) {}

        launch {
            spinnerAlpha.animateTo(
                targetValue = 0f,
                animationSpec = tween(durationMillis = 250)
            )
        }

        // Glow flares hard at the ta-dum hit, then burns out as we zoom through
        launch {
            glowAlpha.animateTo(1f, tween(durationMillis = 150, easing = LinearEasing))
            glowAlpha.animateTo(0f, tween(durationMillis = 700, easing = FastOutSlowInEasing))
        }

        // Rapid zoom in (scale up to 12x) to mimic zooming into the red ribbon portal
        launch {
            tadumScale.animateTo(
                targetValue = 12f,
                animationSpec = tween(durationMillis = 850, easing = CubicBezierEasing(0.5f, 0f, 0.1f, 1f))
            )
        }

        // Start fading out shortly after zoom starts
        delay(120)
        zoomAlpha.animateTo(
            targetValue = 0f,
            animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing)
        )

        // Never leave the splash before the app underneath is actually ready
        while (!warmupFinished) {
            delay(50)
        }

        android.util.Log.i("AppStart", "splash deciding next route")
        if (!hasNavigated.value) {
            hasNavigated.value = true
            onSplashComplete()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                alpha = zoomAlpha.value * introAlpha.value
            }
            .background(NetflixBlack),
        contentAlignment = Alignment.Center
    ) {
        // Red glow bloom behind the logo — pure alpha animation, GPU-cheap
        Box(
            modifier = Modifier
                .size(620.dp)
                .graphicsLayer {
                    alpha = glowAlpha.value
                    // Glow follows the zoom slightly for the "entering the portal" feel
                    val s = 1f + (tadumScale.value - 1f) * 0.35f
                    scaleX = s
                    scaleY = s
                }
                .background(glowBrush)
        )

        // Container for sliding
        Box(
            modifier = Modifier
                .offset { IntOffset(slideOffset.value.roundToInt(), 0) }
                .graphicsLayer {
                    val s = tadumScale.value * breathScale.value
                    scaleX = s
                    scaleY = s
                    transformOrigin = TransformOrigin(nCenterPercent, 0.5f)
                },
            contentAlignment = Alignment.Center
        ) {
            // Original NETFLIX logo with right-to-left Zigzag / Scissors wipe.
            // Instead of clipPath (offscreen saveLayer + per-frame Path allocation),
            // we draw the logo then cover the wiped region with a black zigzag polygon —
            // same visual, no saveLayer, path object is reused.
            Image(
                painter = painterResource(id = R.drawable.ic_netflix_logo),
                contentDescription = "Netflix Logo",
                modifier = Modifier
                    .width(280.dp)
                    .height(76.dp)
                    .onSizeChanged { logoSize = it }
                    .graphicsLayer {
                        alpha = 1f - crossfadeAlpha.value
                    }
                    .drawWithContent {
                        drawContent()
                        if (wipeProgress.value < 1f) {
                            val wipeX = size.width * wipeProgress.value

                            // Smoothly reduce zigzag tooth amplitude as we approach the end
                            // so that the final "N" left-behind edge is perfectly clean and straight
                            val currentToothWidth = if (wipeProgress.value > 0.22f) {
                                32f // Jagged zigzag amplitude in pixels
                            } else {
                                val ratio = (wipeProgress.value - nRightPercent) / (0.22f - nRightPercent)
                                32f * ratio.coerceIn(0f, 1f)
                            }

                            wipeCoverPath.rewind()
                            val steps = 12
                            val stepHeight = size.height / steps
                            wipeCoverPath.moveTo(size.width + 2f, -2f)
                            for (i in 0..steps) {
                                val y = i * stepHeight
                                // Scissors / Zigzag jagged edge
                                val x = if (i % 2 == 0) {
                                    wipeX + currentToothWidth
                                } else {
                                    wipeX - currentToothWidth
                                }
                                wipeCoverPath.lineTo(x, y)
                            }
                            wipeCoverPath.lineTo(size.width + 2f, size.height + 2f)
                            wipeCoverPath.close()
                            drawPath(wipeCoverPath, NetflixBlack)
                        }
                    }
            )

            // Standalone N logo (perfectly aligned and dynamically morphed to its natural aspect ratio)
            Box(
                modifier = Modifier
                    .width(280.dp)
                    .height(76.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_netflix_n),
                    contentDescription = "Netflix N",
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .layout { measurable, constraints ->
                            val alpha = crossfadeAlpha.value
                            val currentWidthDp = 26.46f + (44.7f - 26.46f) * alpha
                            val currentOffsetDp = 25.27f - currentWidthDp / 2f

                            val widthPx = currentWidthDp.dp.roundToPx()
                            val offsetPx = currentOffsetDp.dp.roundToPx()

                            val placeable = measurable.measure(
                                constraints.copy(minWidth = widthPx, maxWidth = widthPx)
                            )
                            layout(placeable.width, placeable.height) {
                                placeable.placeRelative(offsetPx, 0)
                            }
                        }
                        .height(76.dp)
                        .graphicsLayer {
                            alpha = crossfadeAlpha.value
                        },
                    contentScale = ContentScale.FillBounds
                )
            }
        }

        // The Spinner below the logo
        com.example.ui.components.NetflixSpinner(
            modifier = Modifier
                .offset(y = 100.dp)
                .graphicsLayer {
                    alpha = spinnerAlpha.value
                },
            size = 50.dp
        )
    }
}
