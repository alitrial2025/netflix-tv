package com.example.ui.screens.details

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.example.data.Caption
import com.example.data.ContinueWatchingEntity
import com.example.model.Movie
import com.example.ui.NetflixViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

suspend fun resolveAndPlayStream(
    context: Context,
    movie: Movie,
    currentSeason: Int,
    currentEpisode: Int,
    targetMediaId: String,
    viewModel: NetflixViewModel,
    exoPlayer: ExoPlayer,
    selectedSubLang: String,
    continueWatchingData: ContinueWatchingEntity?,
    onCaptions: (List<Caption>) -> Unit
) {
    onCaptions(emptyList())
    try { exoPlayer.volume = 0.25f } catch (_: Exception) {}

    if (exoPlayer.currentMediaItem?.mediaId != targetMediaId) {
        exoPlayer.stop()
        exoPlayer.clearMediaItems()
    }

    val stream = withContext(Dispatchers.IO) { viewModel.resolveStream(movie, currentSeason, currentEpisode) }
    if (stream == null) {
        val trailerStream = withContext(Dispatchers.IO) { viewModel.resolveTrailerStream(movie) }
        if (trailerStream != null && exoPlayer.currentMediaItem?.mediaId != targetMediaId) {
            val mediaItem = buildMediaItemFromTrailer(trailerStream.url, trailerStream.headers, targetMediaId)
            val httpDataSourceFactory = DefaultHttpDataSource.Factory()
                .setUserAgent(trailerStream.headers["User-Agent"] ?: "Mozilla/5.0 (Linux; Android 16; sdk_gphone64_x86_64 Build/BE2A.250530.026.D1; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/133.0.6943.137 Mobile Safari/537.36 /OS.Gatu v3.0")
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(15000)
                .setDefaultRequestProperties(trailerStream.headers)
            val dataSourceFactory = DefaultDataSource.Factory(context, httpDataSourceFactory)
            exoPlayer.setMediaSource(DefaultMediaSourceFactory(dataSourceFactory).createMediaSource(mediaItem))
            exoPlayer.prepare()
            try { exoPlayer.playWhenReady = true } catch (_: Exception) {}
            try { exoPlayer.play() } catch (_: Exception) {}
        }
        return
    }

    onCaptions(stream.captions)
    if (exoPlayer.currentMediaItem?.mediaId == targetMediaId) {
        try { exoPlayer.playWhenReady = true } catch (_: Exception) {}
        try { exoPlayer.play() } catch (_: Exception) {}
        return
    }

    val mediaItemBuilder = MediaItem.Builder()
        .setUri(stream.url)
        .setMediaId(targetMediaId)
    streamMimeTypeForUrl(stream.url)?.let(mediaItemBuilder::setMimeType)
    val mediaItem = mediaItemBuilder.build()

    val httpDataSourceFactory = DefaultHttpDataSource.Factory()
        .setUserAgent(stream.headers["User-Agent"] ?: "Mozilla/5.0 (Linux; Android 16; sdk_gphone64_x86_64 Build/BE2A.250530.026.D1; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/133.0.6943.137 Mobile Safari/537.36 /OS.Gatu v3.0")
        .setAllowCrossProtocolRedirects(true)
        .setConnectTimeoutMs(15000)
        .setReadTimeoutMs(15000)
        .setDefaultRequestProperties(stream.headers)
    val dataSourceFactory = DefaultDataSource.Factory(context, httpDataSourceFactory)
    try {
        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_AUDIO, false)
            .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_AUDIO)
            .setPreferredAudioLanguages("en", "eng")
            .build()
    } catch (_: Exception) {}
    exoPlayer.setMediaSource(DefaultMediaSourceFactory(dataSourceFactory).createMediaSource(mediaItem))
    exoPlayer.prepare()
    try { exoPlayer.playWhenReady = true } catch (_: Exception) {}
    try { exoPlayer.play() } catch (_: Exception) {}

    val cw = continueWatchingData ?: withContext(Dispatchers.IO) { viewModel.getContinueWatching(movie.id) }
    if (cw != null && cw.playbackPositionMs > 0) {
        if (movie.type != "Series" || (cw.season == currentSeason && cw.episode == currentEpisode)) {
            exoPlayer.seekTo(cw.playbackPositionMs)
        }
    }
}

fun buildMediaItemFromTrailer(
    url: String,
    headers: Map<String, String>,
    targetMediaId: String
): MediaItem {
    val mimeType = streamMimeTypeForUrl(url)
    val builder = MediaItem.Builder().setUri(url).setMediaId(targetMediaId)
    if (mimeType != null) builder.setMimeType(mimeType)
    return builder.build()
}

fun streamMimeTypeForUrl(url: String): String? {
    val cleanUrl = url.lowercase().substringBefore('?').substringBefore('#')
    return when {
        cleanUrl.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
        cleanUrl.contains(".mpd") -> MimeTypes.APPLICATION_MPD
        cleanUrl.contains(".mp4") -> MimeTypes.VIDEO_MP4
        else -> null
    }
}
