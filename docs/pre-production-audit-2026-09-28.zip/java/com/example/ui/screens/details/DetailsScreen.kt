package com.example.ui.screens.details

import android.view.KeyEvent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.example.data.Caption
import com.example.model.Episode
import com.example.model.Movie
import com.example.model.isKidSafeMovie
import com.example.ui.NetflixViewModel
import com.example.ui.theme.NetflixBlack
import com.example.ui.util.TvMotion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun DetailsScreen(
    movie: Movie,
    onBack: () -> Unit,
    onPlayMovie: (Movie, Int, Int, String) -> Unit,
    onNavigateToDetails: (Movie) -> Unit,
    viewModel: NetflixViewModel
) {
    val categoryRows by viewModel.categoryRows.collectAsStateWithLifecycle()
    val continueWatchingList by viewModel.continueWatchingList.collectAsStateWithLifecycle()
    val myListMovieIds by viewModel.myListMovieIds.collectAsStateWithLifecycle()
    val likedMovieIds by viewModel.likedMovieIds.collectAsStateWithLifecycle()
    val userSubscription by viewModel.userSubscription.collectAsStateWithLifecycle()

    val isMyListAdded = remember(movie.id, myListMovieIds) { myListMovieIds.contains(movie.id) }
    val isLiked = remember(movie.id, likedMovieIds) { likedMovieIds.contains(movie.id) }

    val selectedProfile by viewModel.selectedProfile.collectAsStateWithLifecycle()
    val isKidProfile = selectedProfile?.isKid == true
    val isKidContent = remember(movie.id, isKidProfile) { isKidProfile || isKidSafeMovie(movie) }

    val isTvSeries = remember(movie.id) {
        movie.type.equals("Series", ignoreCase = true) ||
        movie.type.equals("TV", ignoreCase = true) ||
        movie.duration.contains("Season", ignoreCase = true) ||
        movie.duration.contains("Episode", ignoreCase = true)
    }

    val recommendations = remember(movie.id, categoryRows, isKidContent, isTvSeries) {
        val all = categoryRows.flatMap { it.second }.distinctBy { it.id }
        val pool = if (isKidContent) {
            all.filter { isKidSafeMovie(it) && it.id != movie.id }
        } else {
            all.filter { it.id != movie.id }
        }
        val sorted = if (isTvSeries) {
            pool.sortedByDescending { it.type.equals("Series", ignoreCase = true) || it.duration.contains("Season", ignoreCase = true) }
        } else {
            pool.sortedByDescending { !it.type.equals("Series", ignoreCase = true) && !it.duration.contains("Season", ignoreCase = true) }
        }
        sorted.take(12)
    }

    val context = LocalContext.current
    val extraInfo = remember(movie.id) { getMovieExtraInfo(movie) }

    var activeTabName by remember(movie.id, isTvSeries) {
        mutableStateOf(if (isTvSeries) "Episodes" else "Details")
    }

    val initialCw = remember(movie.id) {
        continueWatchingList.find { it.movieId == movie.id }
    }
    var continueWatchingData by remember(movie.id) { mutableStateOf(initialCw) }
    var episodesList by remember(movie.id) { mutableStateOf<List<Episode>>(emptyList()) }
    var currentSeason by remember(movie.id) {
        mutableIntStateOf(if (isTvSeries && initialCw != null && initialCw.season > 0) initialCw.season else 1)
    }
    var currentEpisode by remember(movie.id) {
        mutableIntStateOf(if (isTvSeries && initialCw != null && initialCw.episode > 0) initialCw.episode else 1)
    }
    var availableSeasons by remember(movie.id) { mutableStateOf(listOf(1)) }

    LaunchedEffect(movie.id, isTvSeries) {
        if (isTvSeries) {
            val tvId = movie.id.toLongOrNull()
            if (tvId != null && tvId > 0L) {
                val seasons = withContext(Dispatchers.IO) { viewModel.getTvSeasons(tvId) }
                if (seasons.isNotEmpty()) {
                    availableSeasons = seasons
                }
            }
        }
    }

    val selectedSubLang by viewModel.selectedSubtitleLanguage.collectAsStateWithLifecycle()
    var streamCaptions by remember(movie.id) { mutableStateOf<List<Caption>>(emptyList()) }
    var showUpgradeModal by remember(movie.id) { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    var currentDetailsLogoUrl by remember(movie.id) {
        mutableStateOf(movie.logoUrl ?: viewModel.getCachedLogo(movie.id))
    }

    val entranceProgress = remember(movie.id) { Animatable(0f) }
    LaunchedEffect(movie.id) {
        entranceProgress.snapTo(0f)
        entranceProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = TvMotion.duration(950), easing = FastOutSlowInEasing)
        )
    }
    // Read the reveal only in child graphics layers, keeping the screen's content
    // and video view out of composition during the entrance.
    val entranceProgressProvider = remember(entranceProgress) { { entranceProgress.value } }

    LaunchedEffect(movie.id) {
        if (currentDetailsLogoUrl.isNullOrBlank()) {
            val isTv = movie.type.equals("Series", ignoreCase = true)
            val fetched = withContext(Dispatchers.IO) { viewModel.fetchLogoUrl(movie.id, isTv) }
            if (!fetched.isNullOrBlank()) {
                currentDetailsLogoUrl = fetched
            }
        }
    }

    LaunchedEffect(movie.id, continueWatchingList) {
        val cw = withContext(Dispatchers.IO) {
            continueWatchingList.find { it.movieId == movie.id } ?: viewModel.getContinueWatching(movie.id)
        }
        continueWatchingData = cw
        if (isTvSeries) {
            val s = cw?.season ?: currentSeason
            val ep = cw?.episode ?: currentEpisode
            if (currentSeason != s || currentEpisode != ep || episodesList.isEmpty()) {
                currentSeason = s
                currentEpisode = ep
                val tvId = movie.id.toLongOrNull()
                val fetched = if (tvId != null && tvId > 0L) {
                    withContext(Dispatchers.IO) { viewModel.getEpisodes(tvId, s) }
                } else {
                    emptyList()
                }
                episodesList = if (fetched.isNotEmpty()) {
                    fetched
                } else {
                    (1..12).map { epNum ->
                        Episode(
                            id = (epNum * 100).toLong(),
                            episodeNumber = epNum,
                            seasonNumber = s,
                            title = "Episode $epNum: Chapter $epNum",
                            description = "An unforgettable journey through mysteries and adventures.",
                            stillUrl = movie.backdropUrl.ifBlank { movie.posterUrl },
                            runtime = if (isKidContent) "24m" else "48m"
                        )
                    }
                }
            }
        } else {
            currentSeason = 1
            currentEpisode = 1
        }
    }

    var showModalScreen by remember(movie.id) { mutableStateOf(false) }
    var lastModalCloseTime by remember(movie.id) { mutableLongStateOf(0L) }
    var lastFocusedSourceRequester by remember(movie.id) { mutableStateOf<FocusRequester?>(null) }
    val seasonFetchHolder = remember(movie.id) { object { var job: kotlinx.coroutines.Job? = null } }

    val playButtonRequester = remember { FocusRequester() }
    val myListButtonRequester = remember { FocusRequester() }
    val likeButtonRequester = remember { FocusRequester() }
    val removeButtonRequester = remember { FocusRequester() }
    val tabRowRequester = remember { FocusRequester() }
    val modalUpRequester = remember { FocusRequester() }

    val exoPlayer = viewModel.sharedExoPlayer
    val targetMediaId = "${movie.id}_${currentSeason}_${currentEpisode}"
    var isStreamReady by remember(movie.id, currentSeason, currentEpisode) {
        mutableStateOf(
            try {
                exoPlayer.currentMediaItem?.mediaId == targetMediaId &&
                        (exoPlayer.playbackState == Player.STATE_READY || exoPlayer.playbackState == Player.STATE_BUFFERING)
            } catch (_: Exception) {
                false
            }
        )
    }

    LaunchedEffect(movie.id, currentSeason, currentEpisode) {
        if (exoPlayer.currentMediaItem?.mediaId == targetMediaId &&
            (exoPlayer.playbackState == Player.STATE_READY || exoPlayer.playbackState == Player.STATE_BUFFERING)) {
            isStreamReady = true
            try { exoPlayer.volume = 0.25f } catch (_: Exception) {}
            try { exoPlayer.playWhenReady = true } catch (_: Exception) {}
            try { exoPlayer.play() } catch (_: Exception) {}
            return@LaunchedEffect
        }
        isStreamReady = false
        viewModel.ensureStreamWarmed(immediate = true)
        try {
            resolveAndPlayStream(
                context = context,
                movie = movie,
                currentSeason = currentSeason,
                currentEpisode = currentEpisode,
                targetMediaId = targetMediaId,
                viewModel = viewModel,
                exoPlayer = exoPlayer,
                selectedSubLang = selectedSubLang,
                continueWatchingData = continueWatchingData,
                onCaptions = { streamCaptions = it }
            )
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (e: Exception) {
            android.util.Log.e("DetailsScreen", "stream resolve/play failed for ${movie.id}", e)
        }
    }

    var isNavigatingToPlayer by remember(movie.id) { mutableStateOf(false) }

    DisposableEffect(movie.id, currentSeason, currentEpisode) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && exoPlayer.currentMediaItem?.mediaId == targetMediaId) {
                    isStreamReady = true
                }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying && exoPlayer.currentMediaItem?.mediaId == targetMediaId) {
                    isStreamReady = true
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            if (!isNavigatingToPlayer) {
                exoPlayer.stop()
                exoPlayer.clearMediaItems()
            }
        }
    }

    LaunchedEffect(movie.id, currentSeason, currentEpisode) {
        delay(8000L)
        val hasReadyTarget = exoPlayer.currentMediaItem?.mediaId == targetMediaId &&
                exoPlayer.playbackState == Player.STATE_READY
        if (!showModalScreen && !isNavigatingToPlayer && hasReadyTarget) {
            isStreamReady = true
        }
    }

    val posterAlphaState = animateFloatAsState(
        targetValue = if (isStreamReady) 0f else 1f,
        animationSpec = tween(TvMotion.duration(1200), easing = FastOutSlowInEasing),
        label = "posterAlpha"
    )
    val showPoster by remember(posterAlphaState) { derivedStateOf { posterAlphaState.value > 0.01f } }

    var lastActivityTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var isUiVisible by remember { mutableStateOf(true) }

    LaunchedEffect(lastActivityTime) {
        isUiVisible = true
        delay(12000L)
        isUiVisible = false
    }

    val uiAlpha by animateFloatAsState(
        targetValue = if (isUiVisible) 1f else 0f,
        animationSpec = tween(TvMotion.duration(800), easing = FastOutSlowInEasing),
        label = "uiAlpha"
    )

    LaunchedEffect(showModalScreen) {
        if (showModalScreen) {
            delay(320)
            try { modalUpRequester.requestFocus() } catch (e: Exception) {
                android.util.Log.w("DetailsScreen", "modalUpRequester.requestFocus failed", e)
            }
        } else {
            delay(240)
            val toFocus = lastFocusedSourceRequester ?: playButtonRequester
            try { toFocus.requestFocus() } catch (e: Exception) {
                try { playButtonRequester.requestFocus() } catch (_: Exception) {}
            }
        }
    }

    var focusSettleKey by remember(movie.id) { mutableIntStateOf(0) }
    LaunchedEffect(focusSettleKey) {
        if (focusSettleKey == 0) {
            try {
                delay(600)
                playButtonRequester.requestFocus()
            } catch (e: Exception) {
                android.util.Log.w("DetailsScreen", "initial playButtonRequester.requestFocus failed", e)
            }
        } else {
            try {
                androidx.compose.runtime.withFrameNanos { /* commit first frame */ }
                playButtonRequester.requestFocus()
            } catch (e: Exception) {
                android.util.Log.w("DetailsScreen", "resume playButtonRequester.requestFocus failed", e)
            }
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                isNavigatingToPlayer = false
                focusSettleKey = focusSettleKey + 1
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    fun handleBack() {
        if (showUpgradeModal) {
            showUpgradeModal = false
        } else if (showModalScreen) {
            lastModalCloseTime = System.currentTimeMillis()
            showModalScreen = false
        } else if (!isUiVisible) {
            isUiVisible = true
            lastActivityTime = System.currentTimeMillis()
        } else {
            if (System.currentTimeMillis() - lastModalCloseTime > 450L) {
                exoPlayer.stop()
                exoPlayer.clearMediaItems()
                onBack()
            }
        }
    }

    BackHandler { handleBack() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NetflixBlack)
            .onPreviewKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyDown) {
                    lastActivityTime = System.currentTimeMillis()
                    val keyCode = keyEvent.nativeKeyEvent.keyCode
                    if (!isUiVisible) {
                        isUiVisible = true
                        return@onPreviewKeyEvent true
                    }
                    if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                        handleBack()
                        return@onPreviewKeyEvent true
                    }
                }
                false
            }
            .pointerInput(Unit) {
                detectTapGestures {
                    lastActivityTime = System.currentTimeMillis()
                    isUiVisible = true
                }
            }
    ) {
        // 1. Live video stream playing in background
        AndroidView(
            factory = { ctx ->
                val view = android.view.LayoutInflater.from(ctx)
                    .inflate(com.example.R.layout.media_player_view, null) as PlayerView
                view.apply {
                    player = exoPlayer
                    useController = false
                    subtitleView?.visibility = android.view.View.GONE
                    setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                    setBackgroundColor(android.graphics.Color.TRANSPARENT)
                    layoutParams = android.view.ViewGroup.LayoutParams(
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { playerView ->
                if (playerView.player != exoPlayer) {
                    playerView.player = exoPlayer
                }
            },
            onRelease = { playerView ->
                playerView.player = null
            },
            modifier = Modifier.fillMaxSize()
        )

        // 2. Poster layer
        if (showPoster) {
            val ctx = LocalContext.current
            val posterUrl = remember(movie.backdropUrl, movie.posterUrl) {
                movie.backdropUrl.ifBlank { movie.posterUrl }
            }
            val posterRequest = remember(ctx, posterUrl) {
                ImageRequest.Builder(ctx)
                    .data(posterUrl)
                    .crossfade(true)
                    .bitmapConfig(android.graphics.Bitmap.Config.RGB_565)
                    .diskCachePolicy(CachePolicy.ENABLED)
                    .memoryCachePolicy(CachePolicy.ENABLED)
                    .build()
            }
            AsyncImage(
                model = posterRequest,
                contentDescription = movie.title,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = posterAlphaState.value },
                contentScale = ContentScale.Crop
            )
        }

        // 3. Cinematic Multi-Layer Gradient Overlays for Details Screen
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.35f)
                        ),
                        radius = 1800f
                    )
                )
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = uiAlpha }
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            colorStops = arrayOf(
                                0.00f to Color(0xFF040406).copy(alpha = 0.98f),
                                0.30f to Color(0xFF060608).copy(alpha = 0.94f),
                                0.48f to Color(0xFF08080C).copy(alpha = 0.84f),
                                0.62f to Color(0xFF0A0A10).copy(alpha = 0.58f),
                                0.78f to Color.Black.copy(alpha = 0.25f),
                                1.00f to Color.Transparent
                            )
                        )
                    )
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colorStops = arrayOf(
                                0.00f to Color.Black.copy(alpha = 0.85f),
                                0.16f to Color.Black.copy(alpha = 0.40f),
                                0.35f to Color.Transparent,
                                0.55f to Color.Transparent,
                                0.75f to Color.Black.copy(alpha = 0.65f),
                                1.00f to Color(0xFF050507).copy(alpha = 0.98f)
                            )
                        )
                    )
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colorStops = arrayOf(
                                0.00f to Color(0xFFE50914).copy(alpha = 0.09f),
                                0.28f to Color(0xFF630B12).copy(alpha = 0.05f),
                                0.55f to Color(0xFF14080B).copy(alpha = 0.02f),
                                1.00f to Color.Transparent
                            ),
                            center = Offset(140f, 200f),
                            radius = 950f
                        )
                    )
            )
        }

        // 4. Details Screen Content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = uiAlpha }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 40.dp, vertical = 24.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                DetailsHeaderRow()

                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DetailsLeftInfoColumn(
                        modifier = Modifier
                            .weight(0.58f)
                            .fillMaxHeight()
                            .padding(bottom = 12.dp),
                        movie = movie,
                        extraInfo = extraInfo,
                        currentDetailsLogoUrl = currentDetailsLogoUrl,
                        isKidContent = isKidContent,
                        isTvSeries = isTvSeries,
                        continueWatchingData = continueWatchingData,
                        continueWatchingList = continueWatchingList,
                        currentSeason = currentSeason,
                        currentEpisode = currentEpisode,
                        isMyListAdded = isMyListAdded,
                        isLiked = isLiked,
                        entranceProgressProvider = entranceProgressProvider,
                        playButtonRequester = playButtonRequester,
                        myListButtonRequester = myListButtonRequester,
                        likeButtonRequester = likeButtonRequester,
                        removeButtonRequester = removeButtonRequester,
                        tabRowRequester = tabRowRequester,
                        exoPlayer = exoPlayer,
                        viewModel = viewModel,
                        onPlayClick = { playSeason, playEpisode, playEpName ->
                            isNavigatingToPlayer = true
                            onPlayMovie(movie, playSeason, playEpisode, playEpName)
                        },
                        onClearProgress = {
                            continueWatchingData = null
                        },
                        onShowUpgradeModal = { showUpgradeModal = true }
                    )

                    DetailsRightTriviaColumn(
                        modifier = Modifier
                            .weight(0.42f)
                            .fillMaxHeight()
                            .padding(start = 32.dp, bottom = 20.dp),
                        extraInfo = extraInfo
                    )
                }

                DetailsBottomTabsRow(
                    isTvSeries = isTvSeries,
                    entranceProgressProvider = entranceProgressProvider,
                    tabRowRequester = tabRowRequester,
                    playButtonRequester = playButtonRequester,
                    onTabClick = { tabName ->
                        lastFocusedSourceRequester = tabRowRequester
                        activeTabName = tabName
                        showModalScreen = true
                    }
                )
            }
        }

        AnimatedVisibility(
            visible = showModalScreen,
            enter = fadeIn(animationSpec = tween(TvMotion.duration(280), easing = FastOutSlowInEasing)) +
                    slideInVertically(
                        initialOffsetY = { it / 6 },
                        animationSpec = tween(TvMotion.duration(280), easing = FastOutSlowInEasing)
                    ),
            exit = fadeOut(animationSpec = tween(TvMotion.duration(220), easing = FastOutSlowInEasing)) +
                    slideOutVertically(
                        targetOffsetY = { it / 6 },
                        animationSpec = tween(TvMotion.duration(220), easing = FastOutSlowInEasing)
                    )
        ) {
            DetailsModalOverlay(
                movie = movie,
                isTvSeries = isTvSeries,
                activeTabName = activeTabName,
                onActiveTabChange = { activeTabName = it },
                onCloseModal = {
                    lastModalCloseTime = System.currentTimeMillis()
                    showModalScreen = false
                },
                episodesList = episodesList,
                currentSeason = currentSeason,
                currentEpisode = currentEpisode,
                availableSeasons = availableSeasons,
                continueWatchingData = continueWatchingData,
                onSeasonSelected = { newSeason ->
                    if (currentSeason != newSeason) {
                        exoPlayer.stop()
                        exoPlayer.clearMediaItems()
                        currentSeason = newSeason
                        currentEpisode = 1
                        seasonFetchHolder.job?.cancel()
                        seasonFetchHolder.job = coroutineScope.launch {
                            val tvId = movie.id.toLongOrNull()
                            val fetched = if (tvId != null && tvId > 0L) {
                                withContext(Dispatchers.IO) { viewModel.getEpisodes(tvId, newSeason) }
                            } else {
                                emptyList()
                            }
                            episodesList = if (fetched.isNotEmpty()) {
                                fetched
                            } else {
                                (1..10).map { epNum ->
                                    Episode(
                                        id = (newSeason * 1000 + epNum).toLong(),
                                        episodeNumber = epNum,
                                        seasonNumber = newSeason,
                                        title = "Season $newSeason Episode $epNum",
                                        description = "A gripping episode in season $newSeason.",
                                        stillUrl = movie.backdropUrl.ifBlank { movie.posterUrl },
                                        runtime = "45m"
                                    )
                                }
                            }
                        }
                    }
                },
                onEpisodeClick = { ep ->
                    if (currentEpisode != ep.episodeNumber) {
                        exoPlayer.stop()
                        exoPlayer.clearMediaItems()
                        currentEpisode = ep.episodeNumber
                    }
                    isNavigatingToPlayer = true
                    onPlayMovie(movie, currentSeason, ep.episodeNumber, ep.title)
                },
                extraInfo = extraInfo,
                recommendations = recommendations,
                onNavigateToDetails = onNavigateToDetails,
                exoPlayer = exoPlayer,
                streamCaptions = streamCaptions,
                selectedSubLang = selectedSubLang,
                onSetSelectedSubLang = { viewModel.setSelectedSubtitleLanguage(it) },
                onPlayMovie = { selectedMovie, selectedSeason, selectedEpisode, selectedEpisodeName ->
                    if (selectedMovie.id != movie.id) {
                        exoPlayer.stop()
                        exoPlayer.clearMediaItems()
                    }
                    isNavigatingToPlayer = true
                    onPlayMovie(selectedMovie, selectedSeason, selectedEpisode, selectedEpisodeName)
                },
                modalUpRequester = modalUpRequester
            )
        }

        AnimatedVisibility(
            visible = showUpgradeModal,
            enter = fadeIn(animationSpec = tween(TvMotion.duration(260), easing = FastOutSlowInEasing)) +
                    slideInVertically(
                        initialOffsetY = { it / 8 },
                        animationSpec = tween(TvMotion.duration(260), easing = FastOutSlowInEasing)
                    ),
            exit = fadeOut(animationSpec = tween(TvMotion.duration(220), easing = FastOutSlowInEasing)) +
                    slideOutVertically(
                        targetOffsetY = { it / 8 },
                        animationSpec = tween(TvMotion.duration(220), easing = FastOutSlowInEasing)
                    )
        ) {
            UpgradePlanModal(
                currentPlanName = userSubscription.planName,
                lockReason = viewModel.getLockReason(movie),
                onDismiss = { showUpgradeModal = false },
                onUpgradeConfirm = { planId, planName ->
                    viewModel.upgradePlan(planId, planName)
                    showUpgradeModal = false
                },
                onWatchTrailer = {
                    showUpgradeModal = false
                    val playSeason = currentSeason
                    val cw = continueWatchingData
                    val playEpisode = if (isTvSeries && cw != null && cw.season == currentSeason) {
                        cw.episode
                    } else {
                        currentEpisode
                    }
                    val playEpName = if (cw != null && cw.season == currentSeason) cw.episodeName else ""
                    isNavigatingToPlayer = true
                    onPlayMovie(movie, playSeason, playEpisode, playEpName)
                }
            )
        }
    }
}
