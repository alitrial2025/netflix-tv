package com.example.ui.components


import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.tv.material3.Surface
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Border
import coil.compose.AsyncImage
import com.example.model.Movie
import com.example.ui.NetflixViewModel
import com.example.ui.theme.RatingDefaults
import com.example.ui.util.TvImagePolicy
import com.example.ui.util.TvArtworkKind
import com.example.ui.util.HomeStartupGate
import com.example.ui.util.TvMotion
import com.example.ui.util.awaitPreviewCompletion



import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt



@Composable
fun BillboardSection(
    movie: Movie,
    featuredMovies: List<Movie> = emptyList(),
    height: Dp,
    alpha: () -> Float = { 1f },
    playFocusRequester: FocusRequester? = null,
    moreInfoFocusRequester: FocusRequester? = null,
    isBillboardFocused: Boolean = true,
    modifier: Modifier = Modifier,
    onPlayClick: () -> Unit = {},
    onInfoClick: () -> Unit = {},
    onFocused: () -> Unit = {},
    onMovieSelected: ((Movie) -> Unit)? = null,
    viewModel: NetflixViewModel? = null,
    onArtworkReady: () -> Unit = {},
    waitForHomeReadyBeforeLogo: Boolean = false
) {
    // The selected movie is owned by the parent. A second carousel index used
    // to show a different hero for one frame after catalogue refreshes.
    val currentMovie = movie
    val internalIndex = remember(movie.id, featuredMovies) {
        featuredMovies.indexOfFirst { it.id == movie.id }.coerceAtLeast(0)
    }

    val backdropUrl = currentMovie.backdropUrl.ifBlank { currentMovie.posterUrl }
    val currentOnArtworkReady by rememberUpdatedState(onArtworkReady)
    LaunchedEffect(currentMovie.id, backdropUrl) {
        if (backdropUrl.isBlank()) currentOnArtworkReady()
    }
    val moreInfoRequester = moreInfoFocusRequester ?: remember { FocusRequester() }

    var isPlayButtonFocused by remember { mutableStateOf(false) }
    var isInfoButtonFocused by remember { mutableStateOf(false) }
    var isPreviewPlaying by remember { mutableStateOf(false) }
    var previewPlayer by remember { mutableStateOf<ExoPlayer?>(null) }
    var previewFirstFrameReady by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val isLowMemoryDevice = remember(ctx) { TvImagePolicy.isLowMemoryDevice(ctx) }
    val density = LocalDensity.current
    val configuration = LocalConfiguration.current
    val (backdropWidthPx, backdropHeightPx) = remember(configuration.screenWidthDp, density.density, height, isLowMemoryDevice) {
        with(density) {
            val requested = TvImagePolicy.backdropSize(
                (configuration.screenWidthDp.dp - 32.dp).roundToPx(),
                (height - 10.dp).roundToPx(),
                isLowMemoryDevice
            )
            // TMDB backdrops top out at 1280px. Decoding a larger bitmap only
            // spends heap and upload time; give small-memory TVs a lower ceiling.
            val widthLimit = if (isLowMemoryDevice) 960 else 1280
            if (requested.first <= widthLimit) requested else {
                widthLimit to (requested.second * widthLimit.toFloat() / requested.first)
                    .roundToInt().coerceAtLeast(1)
            }
        }
    }
    val logoWidthPx = with(density) { 340.dp.roundToPx() }.coerceAtMost(500)
    val logoHeightPx = with(density) { 88.dp.roundToPx() }
    val lifecycleOwner = LocalLifecycleOwner.current
    var isResumed by remember(lifecycleOwner) {
        mutableStateOf(lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED))
    }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, _ ->
            isResumed = lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Dynamic TMDB Logo for billboard movie title
    var billboardLogoUrl by remember(currentMovie.id) {
        mutableStateOf(
            currentMovie.logoUrl
                ?: viewModel?.getCachedLogo(currentMovie.id)
                ?: com.example.data.TmdbRepository.getCachedLogo(currentMovie.id)
        )
    }

    LaunchedEffect(currentMovie.id, waitForHomeReadyBeforeLogo) {
        if (!billboardLogoUrl.isNullOrBlank()) return@LaunchedEffect
        val cached = viewModel?.getCachedLogo(currentMovie.id)
            ?: com.example.data.TmdbRepository.getCachedLogo(currentMovie.id)
        if (!cached.isNullOrBlank()) {
            billboardLogoUrl = cached
        } else {
            // The cached logo path stays immediate. Network enrichment waits
            // until Home's first artwork and rows are ready and input is quiet.
            if (waitForHomeReadyBeforeLogo) HomeStartupGate.awaitIdle()
            else HomeStartupGate.awaitBrowsingIdle()
            val isTv = currentMovie.type.equals("Series", ignoreCase = true) ||
                currentMovie.type.equals("TV", ignoreCase = true) ||
                currentMovie.duration.contains("Season", ignoreCase = true)
            val fetched = withContext(Dispatchers.IO) {
                viewModel?.fetchLogoUrl(currentMovie.id, isTv)
                    ?: com.example.data.TmdbRepository().fetchLogoUrl(currentMovie.id.toLongOrNull() ?: 0L, isTv)
            }
            if (!fetched.isNullOrBlank()) {
                billboardLogoUrl = fetched
                com.example.data.TmdbRepository.putCachedLogo(currentMovie.id, fetched)
            }
        }
    }

    // Ambient auto-rotation across curated billboard candidates: waits 60 seconds (1 minute) per item
    // and never collides with or interrupts active video preview playback
    val currentOnMovieSelected by rememberUpdatedState(onMovieSelected)
    LaunchedEffect(featuredMovies, currentMovie.id, isBillboardFocused, isResumed) {
        if (featuredMovies.size > 1 && isBillboardFocused && isResumed) {
            while (true) {
                delay(60000L) // Full 1 minute candidate display cycle

                // If a preview is actively playing, wait until the 1-minute preview finishes
                while (isPreviewPlaying) {
                    delay(1000L)
                }

                // If user is actively focused on Billboard primary actions, hold rotation
                if (isBillboardFocused && (isPlayButtonFocused || isInfoButtonFocused)) {
                    delay(5000L)
                    continue
                }

                val nextIdx = (internalIndex + 1) % featuredMovies.size
                val nextMovie = featuredMovies[nextIdx]
                currentOnMovieSelected?.invoke(nextMovie)
            }
        }
    }

    // Warm compressed artwork only after entry has settled. execute() is cancelled
    // with this effect when the user leaves the hero; no full-size bitmap is retained.
    LaunchedEffect(internalIndex, featuredMovies, isBillboardFocused, isResumed, isLowMemoryDevice) {
        if (featuredMovies.size > 1 && isBillboardFocused && isResumed && !isLowMemoryDevice) {
            // Rotation is a minute away. Do not download the next hero during landing.
            delay(45_000L)
            HomeStartupGate.awaitBrowsingIdle()
            val nextMovie = featuredMovies.getOrNull((internalIndex + 1) % featuredMovies.size)
            if (nextMovie != null) {
                val nextBackdrop = nextMovie.backdropUrl.ifBlank { nextMovie.posterUrl }
                if (nextBackdrop.isNotBlank()) {
                    val prefetchReq = coil.request.ImageRequest.Builder(ctx)
                        .data(TvImagePolicy.artworkUrl(
                            nextBackdrop,
                            backdropWidthPx,
                            if (nextMovie.backdropUrl.isNotBlank()) TvArtworkKind.BACKDROP else TvArtworkKind.POSTER
                        ))
                        .bitmapConfig(android.graphics.Bitmap.Config.RGB_565)
                        .allowRgb565(true)
                        .size(1, 1)
                        .precision(coil.size.Precision.EXACT)
                        .memoryCachePolicy(coil.request.CachePolicy.DISABLED)
                        .diskCachePolicy(coil.request.CachePolicy.ENABLED)
                        .build()
                    coil.Coil.imageLoader(ctx).execute(prefetchReq)
                }
                viewModel?.fetchLogoForMovie(nextMovie)
            }
        }
    }

    DisposableEffect(viewModel) {
        onDispose {
            viewModel?.isBillboardPlaying?.value = false
        }
    }

    var resolvedStream by remember(currentMovie.id) { mutableStateOf<com.example.data.TrailerStream?>(null) }

    // Resolve and allocate video only for a settled, visible Play focus. Every exit
    // (scroll, tab/profile change, activity pause, error or timeout) releases the decoder.
    LaunchedEffect(isPlayButtonFocused, isBillboardFocused, isResumed, currentMovie.id, viewModel, isLowMemoryDevice) {
        if (!isPlayButtonFocused || !isBillboardFocused || !isResumed || viewModel == null || isLowMemoryDevice) {
            return@LaunchedEffect
        }
        // Stream resolvers may cold-initialize a WebView. Leave the first few
        // seconds to entry/scrolling, then require a genuinely idle viewport.
        delay(5_000L)
        HomeStartupGate.awaitBrowsingIdle()
        if (viewModel.isMovieLocked(currentMovie)) return@LaunchedEffect

        val stream = resolvedStream ?: try {
            withContext(Dispatchers.IO) { viewModel.resolveTrailerStream(currentMovie) }
                ?.also { resolvedStream = it }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            android.util.Log.w("BillboardPreview", "Trailer resolution failed for ${currentMovie.id}", error)
            null
        } ?: return@LaunchedEffect

        var player: ExoPlayer? = null
        var frameListener: Player.Listener? = null
        try {
            val renderersFactory = androidx.media3.exoplayer.DefaultRenderersFactory(ctx).apply {
                setEnableDecoderFallback(true)
            }
            val tvLoadControl = androidx.media3.exoplayer.DefaultLoadControl.Builder()
                .setBufferDurationsMs(
                    2500,
                    8000,
                    1000,
                    2000
                )
                .setBackBuffer(0, false)
                .setTargetBufferBytes(8 * 1024 * 1024)
                .setPrioritizeTimeOverSizeThresholds(false)
                .build()

            val activePlayer = ExoPlayer.Builder(ctx, renderersFactory)
                .setLoadControl(tvLoadControl)
                .build()
            player = activePlayer
            previewFirstFrameReady = false
            previewPlayer = activePlayer
            val listener = object : Player.Listener {
                override fun onRenderedFirstFrame() {
                    if (previewPlayer === activePlayer) previewFirstFrameReady = true
                }
            }
            frameListener = listener
            activePlayer.addListener(listener)
            activePlayer.apply {
                    playWhenReady = true
                    repeatMode = Player.REPEAT_MODE_OFF
                    volume = 0.5f
                    trackSelectionParameters = trackSelectionParameters.buildUpon()
                        .setMaxVideoSize(1280, 720)
                        .setMaxVideoBitrate(2_500_000)
                        .setMaxVideoFrameRate(30)
                        .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
                        .build()
            }
            val dataSourceFactory = DefaultHttpDataSource.Factory().apply {
                setDefaultRequestProperties(stream.headers)
            }
            val streamMimeType = when {
                stream.url.contains(".m3u8", ignoreCase = true) -> MimeTypes.APPLICATION_M3U8
                stream.url.contains(".mpd", ignoreCase = true) -> MimeTypes.APPLICATION_MPD
                stream.url.contains(".mp4", ignoreCase = true) -> MimeTypes.VIDEO_MP4
                else -> null
            }
            val mediaItemBuilder = MediaItem.Builder()
                .setUri(stream.url)
            if (streamMimeType != null) {
                mediaItemBuilder.setMimeType(streamMimeType)
            }
            val mediaItem = mediaItemBuilder.build()
            val mediaSource = DefaultMediaSourceFactory(dataSourceFactory)
                .createMediaSource(mediaItem)

            activePlayer.setMediaSource(mediaSource)
            activePlayer.prepare()
            isPreviewPlaying = true
            viewModel.isBillboardPlaying.value = true
            awaitPreviewCompletion(activePlayer)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            android.util.Log.w("BillboardPreview", "Preview could not start for ${currentMovie.id}", error)
        } finally {
            if (previewPlayer === player) {
                previewFirstFrameReady = false
                previewPlayer = null
            }
            frameListener?.let { listener -> player?.removeListener(listener) }
            try { player?.release() } catch (_: Exception) {}
            isPreviewPlaying = false
            viewModel.isBillboardPlaying.value = false
        }
    }


    val previewAlpha = animateFloatAsState(
        targetValue = if (previewFirstFrameReady && previewPlayer != null) 1f else 0f,
        animationSpec = tween(TvMotion.duration(240), easing = LinearOutSlowInEasing),
        label = "billboardFirstFrame"
    )
    val cardShape = remember { RoundedCornerShape(18.dp) }
    val contentWidth = (configuration.screenWidthDp.dp * 0.48f).coerceIn(280.dp, 480.dp)
    val metadata = remember(currentMovie.year, currentMovie.type, currentMovie.duration, currentMovie.quality) {
        (listOf(currentMovie.year, currentMovie.type, currentMovie.duration) +
            currentMovie.quality.filter { it.isNotBlank() }.distinct().take(2))
            .filter { it.isNotBlank() }.joinToString("  ·  ")
    }

    Box(
        modifier = modifier.fillMaxWidth().height(height)
            .graphicsLayer { this.alpha = alpha() }
            .padding(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 8.dp)
    ) {
        Box(Modifier.fillMaxSize().clip(cardShape).background(Color(0xFF101216))) {
            if (backdropUrl.isNotBlank()) {
                val artworkKind = if (currentMovie.backdropUrl.isNotBlank()) TvArtworkKind.BACKDROP else TvArtworkKind.POSTER
                val heroRequest = remember(ctx, backdropUrl, artworkKind, backdropWidthPx, backdropHeightPx) {
                    coil.request.ImageRequest.Builder(ctx)
                        .data(TvImagePolicy.artworkUrl(backdropUrl, backdropWidthPx, artworkKind))
                        .size(backdropWidthPx, backdropHeightPx)
                        .precision(coil.size.Precision.EXACT)
                        .scale(coil.size.Scale.FILL)
                        .crossfade(false)
                        .bitmapConfig(android.graphics.Bitmap.Config.RGB_565)
                        .allowRgb565(true)
                        .memoryCachePolicy(coil.request.CachePolicy.ENABLED)
                        .diskCachePolicy(coil.request.CachePolicy.ENABLED)
                        .build()
                }
                ReadyArtwork(
                    request = heroRequest,
                    contentDescription = currentMovie.title,
                    modifier = Modifier.fillMaxSize(),
                    animateReplacement = !isLowMemoryDevice,
                    onReady = { currentOnArtworkReady() }
                )
            }

            // The poster covers buffering until the preview has decoded its first frame.
            val activePreviewPlayer = previewPlayer
            if (activePreviewPlayer != null) {
                AndroidView(
                    factory = { viewContext ->
                        (android.view.LayoutInflater.from(viewContext)
                            .inflate(com.example.R.layout.media_player_view, null) as PlayerView).apply {
                            player = activePreviewPlayer
                            useController = false
                            resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            subtitleView?.visibility = android.view.View.GONE
                            setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                            setBackgroundColor(android.graphics.Color.TRANSPARENT)
                            layoutParams = android.view.ViewGroup.LayoutParams(
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        }
                    },
                    update = { if (it.player !== activePreviewPlayer) it.player = activePreviewPlayer },
                    onRelease = { it.player = null },
                    modifier = Modifier.fillMaxSize().graphicsLayer { this.alpha = previewAlpha.value }
                )
            }

            // Cached scrims protect the copy while leaving the artwork open on the right.
            // The large shadow, glass sheen and specular border no longer need drawing.
            Box(
                Modifier.fillMaxSize().drawWithCache {
                    val horizontal = Brush.horizontalGradient(
                        0f to Color(0xFF090B10).copy(alpha = 0.97f),
                        0.34f to Color(0xFF090B10).copy(alpha = 0.88f),
                        0.58f to Color(0xFF090B10).copy(alpha = 0.40f),
                        0.78f to Color.Transparent,
                        endX = size.width
                    )
                    val vertical = Brush.verticalGradient(
                        0f to Color.Transparent,
                        0.55f to Color.Transparent,
                        1f to Color(0xFF090B10).copy(alpha = 0.84f),
                        endY = size.height
                    )
                    onDrawBehind { drawRect(horizontal); drawRect(vertical) }
                }
            )

            Column(
                modifier = Modifier.align(Alignment.BottomStart)
                    .padding(start = 32.dp, bottom = 28.dp).width(contentWidth)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Box(Modifier.width(3.dp).height(13.dp).background(Color(0xFFE50914), RoundedCornerShape(2.dp)))
                    Text(
                        text = if (currentMovie.isComingSoon) "COMING SOON" else "FEATURED",
                        color = Color(0xFFE5E5E8), fontSize = 11.sp,
                        fontWeight = FontWeight.Bold, letterSpacing = 2.sp
                    )
                }
                Spacer(Modifier.height(14.dp))
                BillboardTitleArtwork(currentMovie.title, billboardLogoUrl, logoWidthPx, logoHeightPx)
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().height(24.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = metadata, color = Color(0xFFCFD0D5), fontSize = 13.sp,
                        fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Text(
                        text = currentMovie.rating.ifBlank { RatingDefaults.MISSING },
                        color = Color(0xFFE3E4E8), fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                        modifier = Modifier.border(1.dp, Color.White.copy(alpha = 0.30f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))
                // Fixed copy space prevents decoded logos or focus changes from shifting actions.
                Text(
                    text = currentMovie.description, color = Color(0xFFD1D2D6),
                    fontSize = 14.sp, lineHeight = 20.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth().height(42.dp)
                )
                Spacer(Modifier.height(18.dp))
                Row(
                    modifier = if (isBillboardFocused) Modifier else Modifier.clearAndSetSemantics { },
                    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
                ) {
                    val isLoggedIn = viewModel?.isUserLoggedIn() ?: true
                    val isLocked = viewModel?.isMovieLocked(currentMovie) ?: false
                    BillboardButton(
                        text = when { !isLoggedIn -> "Play Trailer"; isLocked -> "Unlock"; else -> "Play" },
                        icon = if (isLocked && isLoggedIn) Icons.Default.Lock else Icons.Default.PlayArrow,
                        isPrimary = true, focusRequester = playFocusRequester,
                        modifier = Modifier.focusProperties { left = FocusRequester.Cancel; right = moreInfoRequester },
                        onClick = { if (isLocked && isLoggedIn) onInfoClick() else onPlayClick() },
                        onFocusChange = { isPlayButtonFocused = it }, onFocused = onFocused
                    )
                    BillboardButton(
                        text = "More Info", icon = Icons.Default.Info,
                        isPrimary = false, focusRequester = moreInfoRequester,
                        modifier = Modifier.focusProperties {
                            left = playFocusRequester ?: FocusRequester.Default
                            right = FocusRequester.Cancel
                        },
                        onClick = onInfoClick,
                        onFocusChange = { isInfoButtonFocused = it }, onFocused = onFocused
                    )
                }
            }

            val isPreviewShowing = isPreviewPlaying && previewFirstFrameReady && previewPlayer != null
            if (featuredMovies.size > 1) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 28.dp, bottom = 28.dp),
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "${internalIndex + 1}/${featuredMovies.size}",
                        color = Color.White.copy(alpha = 0.70f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp
                    )
                    val markerCount = minOf(featuredMovies.size, 5)
                    val selectedMarker = internalIndex * markerCount / featuredMovies.size

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .height(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xCC1A1C20))
                                .padding(horizontal = 14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                repeat(markerCount) { index ->
                                    if (index == selectedMarker) {
                                        Box(
                                            modifier = Modifier
                                                .width(28.dp)
                                                .height(5.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFE5E5E8))
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(5.dp)
                                                .clip(CircleShape)
                                                .background(Color.White.copy(alpha = 0.35f))
                                        )
                                    }
                                }
                            }
                        }

                        AnimatedVisibility(
                            visible = isPreviewShowing,
                            enter = fadeIn(animationSpec = tween(260)) +
                                    expandHorizontally(animationSpec = tween(260)),
                            exit = fadeOut(animationSpec = tween(260)) +
                                   shrinkHorizontally(animationSpec = tween(260))
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xCC1A1C20)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Preview Playing",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            } else if (isPreviewShowing) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 28.dp, bottom = 28.dp)
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(0xCC1A1C20)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Preview Playing",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun BillboardTitleArtwork(title: String, logoUrl: String?, widthPx: Int, heightPx: Int) {
    val context = LocalContext.current
    var logoReady by remember(title, logoUrl) { mutableStateOf(false) }
    val request = remember(context, logoUrl, widthPx, heightPx) {
        logoUrl?.takeIf { it.isNotBlank() }?.let {
            coil.request.ImageRequest.Builder(context)
                .data(TvImagePolicy.artworkUrl(it, widthPx, TvArtworkKind.LOGO))
                .size(widthPx, heightPx)
                .bitmapConfig(android.graphics.Bitmap.Config.ARGB_8888)
                .allowRgb565(false).crossfade(false).build()
        }
    }
    Box(Modifier.fillMaxWidth().height(88.dp), contentAlignment = Alignment.CenterStart) {
        // A failed or slow logo never leaves an empty title. Both versions reserve
        // the same area so loading cannot move the metadata or the buttons.
        if (!logoReady) {
            Text(
                text = title, color = Color.White, fontSize = 36.sp, lineHeight = 40.sp,
                fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.6).sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
        }
        if (request != null) {
            AsyncImage(
                model = request, contentDescription = title,
                modifier = Modifier.fillMaxHeight().widthIn(max = 340.dp),
                contentScale = ContentScale.Fit, alignment = Alignment.CenterStart,
                onSuccess = { logoReady = true }, onError = { logoReady = false }
            )
        }
    }
}

@Composable
fun BillboardButton(
    text: String,
    icon: ImageVector,
    isPrimary: Boolean,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null,
    onClick: () -> Unit,
    onFocusChange: ((Boolean) -> Unit)? = null,
    onFocused: () -> Unit = {}
) {
    var isFocused by remember { mutableStateOf(false) }
    val scale = animateFloatAsState(
        targetValue = if (isFocused) 1.05f else 1f,
        animationSpec = tween(TvMotion.duration(140), easing = LinearOutSlowInEasing),
        label = "billboardActionScale"
    )
    val containerColor = if (isPrimary) {
        Color(0xFFFFFFFF)
    } else {
        if (isFocused) Color(0xFFFFFFFF) else Color(0x6654565C)
    }
    val contentColor = if (isPrimary) {
        Color(0xFF000000)
    } else {
        if (isFocused) Color(0xFF000000) else Color(0xFFFFFFFF)
    }

    Box(
        modifier = Modifier
            .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
            .border(2.dp, if (isFocused) Color.White else Color.Transparent, CircleShape)
            .padding(2.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            onClick = onClick,
            modifier = modifier
                .height(38.dp)
                .widthIn(min = if (isPrimary) 90.dp else 110.dp)
                .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
                .onFocusChanged {
                    isFocused = it.isFocused
                    onFocusChange?.invoke(it.isFocused)
                    if (it.isFocused) onFocused()
                },
            shape = ClickableSurfaceDefaults.shape(shape = CircleShape),
            colors = ClickableSurfaceDefaults.colors(
                containerColor = containerColor,
                focusedContainerColor = Color(0xFFFFFFFF)
            ),
            border = ClickableSurfaceDefaults.border(border = Border.None, focusedBorder = Border.None),
            scale = ClickableSurfaceDefaults.scale(focusedScale = 1f)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = text,
                    color = contentColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.2.sp,
                    maxLines = 1
                )
            }
        }
    }
}
