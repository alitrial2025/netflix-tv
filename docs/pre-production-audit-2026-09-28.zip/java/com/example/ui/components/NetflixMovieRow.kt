package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import coil.compose.AsyncImage
import com.example.model.Movie
import com.example.ui.theme.NetflixRed
import com.example.ui.theme.RatingDefaults
import com.example.ui.util.TvMotion
import com.example.ui.util.TvKeyPacer

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive

import androidx.compose.ui.input.key.*
import android.view.KeyEvent
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.zIndex
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.C
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.imageLoader
import coil.request.ImageRequest
import com.example.ui.NetflixViewModel
import com.example.ui.util.TvImagePolicy
import com.example.ui.util.TvArtworkKind
import com.example.ui.util.HomeStartupGate
import kotlinx.coroutines.CancellationException
import com.example.ui.util.awaitPreviewCompletion
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.withContext

/**
 * Reusable Netflix-style Horizontal Movie Carousel Component.
 * Features:
 * - Infinite horizontal wrap-around carousel loop
 * - Smooth interpolated index animation (FastOutSlowInEasing)
 * - Dynamic card expansion (2.3x focused width slot)
 * - Fixed/slid white selection frame/ring
 * - Metadata & synopsis details updated dynamically for focused movie
 */

private val CardOverlayGradient = Brush.verticalGradient(
    colors = listOf(
        Color.Transparent,
        Color.Black.copy(alpha = 0.15f),
        Color.Black.copy(alpha = 0.60f),
        Color.Black.copy(alpha = 0.95f)
    ),
    startY = 50f
)

private val CardCornerShape = RoundedCornerShape(8.dp)
private val BadgeShape3 = RoundedCornerShape(3.dp)
private val BadgeShape4 = RoundedCornerShape(4.dp)
private val BadgeShape12 = RoundedCornerShape(12.dp)
// perf: pre-built brush for the Netflix Pro badge. Was allocated inside the
// Row composable on every recomposition; with ~5 visible rows that's 5 brush
// allocations per focus change for a value that never changes.
private val ProBadgeBrush = Brush.horizontalGradient(
    listOf(NetflixRed, Color(0xFFB81D24))
)
private val cardLogoRepository = com.example.data.TmdbRepository()

private fun Movie.cardImageUrl(isPortrait: Boolean): String =
    if (isPortrait) posterUrl.ifBlank { backdropUrl } else backdropUrl.ifBlank { posterUrl }

private fun Movie.cardArtworkKind(isPortrait: Boolean): TvArtworkKind =
    if (if (isPortrait) posterUrl.isNotBlank() else backdropUrl.isBlank()) TvArtworkKind.POSTER
    else TvArtworkKind.BACKDROP

// Share request sizing/configuration with prefetch, so warming a neighboring hero
// never creates a different bitmap variant from the one that will be displayed.
private fun cardImageRequest(
    context: android.content.Context,
    imageUrl: String,
    isExpanded: Boolean,
    isPortrait: Boolean,
    artworkKind: TvArtworkKind
): ImageRequest {
    val widthPx = if (isExpanded) (if (isPortrait) 380 else 640) else 240
    val heightPx = if (isExpanded) (if (isPortrait) 540 else 360) else 340
    return ImageRequest.Builder(context)
        .data(TvImagePolicy.artworkUrl(imageUrl, widthPx, artworkKind))
        // The expanded slot remains visible on unfocused rows too. Avoid keeping
        // a four-byte photo copy for every such row; logos request alpha separately.
        .bitmapConfig(android.graphics.Bitmap.Config.RGB_565)
        .allowRgb565(true)
        .crossfade(false)
        .memoryCachePolicy(coil.request.CachePolicy.ENABLED)
        .diskCachePolicy(coil.request.CachePolicy.ENABLED)
        .size(widthPx, heightPx)
        .build()
}

private fun releasePreviewPlayer(player: ExoPlayer?) {
    if (player == null) return
    runCatching { player.stop() }
    runCatching { player.clearMediaItems() }
    runCatching { player.release() }
}

@Composable
fun NetflixMovieRow(
    title: String,
    movies: List<Movie>,
    modifier: Modifier = Modifier,
    isPortrait: Boolean = true,
    rowFocusRequester: FocusRequester? = null,
    height: Dp = 375.dp,
    alpha: () -> Float = { 1f },
    isVisible: Boolean = true,
    continueWatchingProgressMap: Map<String, Float>? = null,
    remindedMovieIds: Set<String> = emptySet(),
    isMovieLocked: ((Movie) -> Boolean)? = null,
    onToggleReminder: ((Movie) -> Unit)? = null,
    onMovieFocused: (Movie) -> Unit = {},
    onMovieClick: (Movie) -> Unit = {},
    onRowFocused: () -> Unit = {},
    onDpadUp: () -> Boolean = { false },
    onDpadDown: () -> Boolean = { false },
    viewModel: NetflixViewModel? = null,
    verticalRingOffsetProvider: () -> Float = { 0f },
    showSelectionRing: Boolean = true,
    onSelectionFrameTopMeasured: (Int) -> Unit = {}
) {
    if (movies.isEmpty() || height <= 2.dp) return

    if (!isVisible) {
        // Lightweight static skeleton: grey card outlines instead of black void.
        // No shimmer animation — pure static draw, near-zero GPU cost.
        Column(
            modifier = modifier
                .fillMaxWidth()
                .height(height)
        ) {
            // Title bar placeholder
            Box(
                modifier = Modifier
                    .padding(start = 16.dp, bottom = 8.dp)
                    .width(150.dp)
                    .height(20.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF1A1A1A))
            )
            // Card strip placeholder
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                repeat(5) {
                    Box(
                        modifier = Modifier
                            .width(190.dp)
                            .height(270.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1A1A1A))
                    )
                }
            }
        }
        return
    }

    // perf: hoist the title parsing out of the hot path. title.contains runs
    // on every recomposition; the result is constant for the lifetime of the
    // row's title.
    val isInfinite = remember(title, movies.size) { !title.contains("Continue Watching", ignoreCase = true) && movies.size >= 4 }
    val initialIndex = remember(title, isInfinite, movies.size) { if (isInfinite) 1000 * movies.size else 0 }
    var focusedIndex by androidx.compose.runtime.saveable.rememberSaveable(title) { mutableIntStateOf(initialIndex) }
    val horizontalKeyPacer = remember { TvKeyPacer() }
    var savedMovieCount by androidx.compose.runtime.saveable.rememberSaveable(title) { mutableIntStateOf(movies.size) }
    var isRowFocused by remember { mutableStateOf(false) }

    val context = androidx.compose.ui.platform.LocalContext.current
    val isLowMemoryDevice = remember(context) { TvImagePolicy.isLowMemoryDevice(context) }
    val currentMovies by rememberUpdatedState(movies)
    val currentOnRowFocused by rememberUpdatedState(onRowFocused)

    // Visible posters already load themselves. Only warm the two possible next
    // heroes, sequentially, after focus settles. execute() belongs to this effect:
    // navigating away cancels in-flight work instead of leaving enqueued decodes.
    LaunchedEffect(focusedIndex, movies, isRowFocused, isPortrait, isInfinite, isLowMemoryDevice) {
        if (!isRowFocused || isLowMemoryDevice) return@LaunchedEffect
        delay(1_200)
        HomeStartupGate.awaitBrowsingIdle()
        for (offset in intArrayOf(1, -1)) {
            HomeStartupGate.awaitBrowsingIdle()
            val index = focusedIndex + offset
            if (!isInfinite && index !in movies.indices) continue
            val movie = movies[((index % movies.size) + movies.size) % movies.size]
            val imageUrl = movie.cardImageUrl(isPortrait)
            if (imageUrl.isNotBlank()) {
                context.imageLoader.execute(cardImageRequest(context, imageUrl, true, isPortrait, movie.cardArtworkKind(isPortrait)))
            }
        }
    }

    // Debounce notifying parent of focused movie change during rapid left/right sliding
    val currentOnMovieFocused by rememberUpdatedState(onMovieFocused)
    LaunchedEffect(focusedIndex, isRowFocused, movies) {
        if (isRowFocused && movies.isNotEmpty()) {
            kotlinx.coroutines.delay(180) // Settle before propagating full movie focus to billboard & palette
            val movieIndex = ((focusedIndex % movies.size) + movies.size) % movies.size
            movies.getOrNull(movieIndex)?.let { currentOnMovieFocused(it) }
        }
    }

    // Inline previews are intentionally scoped to the settled focused card. This avoids
    // resolving or attaching media while the user is still moving through the carousel.
    var previewMovieId by remember { mutableStateOf<String?>(null) }
    var previewPlayer by remember { mutableStateOf<ExoPlayer?>(null) }
    val previewViewHolder = remember { object { var view: PlayerView? = null } }
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    var isLifecycleResumed by remember(lifecycleOwner) {
        mutableStateOf(lifecycleOwner.lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED))
    }
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { owner, _ ->
            isLifecycleResumed = owner.lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(focusedIndex, isRowFocused, movies, viewModel, isLifecycleResumed, isLowMemoryDevice) {
        var ownedPlayer: ExoPlayer? = null
        try {
            val previewViewModel = viewModel ?: return@LaunchedEffect
            if (!isRowFocused || !isLifecycleResumed || isLowMemoryDevice || movies.isEmpty()) return@LaunchedEffect

            // Preview only after focus settles; D-pad repeats cancel this work.
            delay(5_000)
            HomeStartupGate.awaitBrowsingIdle()
            val selectedIndex = ((focusedIndex % movies.size) + movies.size) % movies.size
            val selectedMovie = movies.getOrNull(selectedIndex) ?: return@LaunchedEffect
            val stream = try {
                withContext(kotlinx.coroutines.Dispatchers.IO) {
                    previewViewModel.resolveTrailerStream(selectedMovie)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                android.util.Log.w("RowPreview", "Unable to resolve ${selectedMovie.id}", error)
                null
            } ?: return@LaunchedEffect

            // Resolution may finish after the focus has moved to another card.
            val latestIndex = ((focusedIndex % movies.size) + movies.size) % movies.size
            if (!isRowFocused || movies.getOrNull(latestIndex)?.id != selectedMovie.id) return@LaunchedEffect

            val loadControl = DefaultLoadControl.Builder()
                .setBufferDurationsMs(1_500, 4_000, 1_500, 2_000)
                .setTargetBufferBytes(4 * 1024 * 1024)
                .setPrioritizeTimeOverSizeThresholds(false)
                .setBackBuffer(0, false)
                .build()
            val player = ExoPlayer.Builder(
                context,
                DefaultRenderersFactory(context).setEnableDecoderFallback(true)
            )
                .setLoadControl(loadControl)
                .build()
            ownedPlayer = player

            val mimeType = when {
                stream.url.contains(".m3u8", ignoreCase = true) -> MimeTypes.APPLICATION_M3U8
                stream.url.contains(".mpd", ignoreCase = true) -> MimeTypes.APPLICATION_MPD
                stream.url.contains(".mp4", ignoreCase = true) -> MimeTypes.VIDEO_MP4
                else -> null
            }
            val mediaItem = MediaItem.Builder()
                .setUri(stream.url)
                .apply { if (mimeType != null) setMimeType(mimeType) }
                .build()
            val mediaSource = DefaultMediaSourceFactory(
                DefaultHttpDataSource.Factory().setDefaultRequestProperties(stream.headers)
            ).createMediaSource(mediaItem)

            player.apply {
                trackSelectionParameters = trackSelectionParameters.buildUpon()
                    .setMaxVideoSize(1280, 720)
                    .setMaxVideoBitrate(2_500_000)
                    .setMaxVideoFrameRate(30)
                    .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
                volume = 0f
                repeatMode = androidx.media3.common.Player.REPEAT_MODE_OFF
                setMediaSource(mediaSource)
                prepare()
                playWhenReady = true
            }
            previewMovieId = selectedMovie.id
            previewPlayer = player

            // Completion/errors release just as promptly as focus/lifecycle changes.
            awaitPreviewCompletion(player)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            android.util.Log.w("RowPreview", "Preview setup failed", error)
        } finally {
            previewViewHolder.view?.let { playerView ->
                if (playerView.player === ownedPlayer) playerView.player = null
            }
            if (previewPlayer === ownedPlayer) {
                previewPlayer = null
                previewMovieId = null
            }
            releasePreviewPlayer(ownedPlayer)
        }
    }

    // A restored row begins at its saved card, with no jump through the first item.
    val animIndex = remember(title) { Animatable(focusedIndex.toFloat()) }
    val animatedFloor by remember(animIndex) {
        derivedStateOf { kotlin.math.floor(animIndex.value).toInt() }
    }
    val showIncomingHero by remember(animIndex) {
        derivedStateOf { animIndex.value - kotlin.math.floor(animIndex.value) > 0.01f }
    }
    val isHeroSettled by remember(animIndex) {
        derivedStateOf { kotlin.math.abs(animIndex.value - focusedIndex.toFloat()) < 0.01f }
    }
    val canShowPreview by remember(animIndex) {
        derivedStateOf { animIndex.value - kotlin.math.floor(animIndex.value) < 0.05f }
    }
    LaunchedEffect(movies.size, isInfinite) {
        if (savedMovieCount != movies.size || (!isInfinite && focusedIndex !in movies.indices)) {
            val previousCount = savedMovieCount.coerceAtLeast(1)
            val movieIndex = (((focusedIndex % previousCount) + previousCount) % previousCount)
                .coerceAtMost(movies.lastIndex)
            focusedIndex = if (isInfinite) initialIndex + movieIndex else movieIndex
            savedMovieCount = movies.size
            animIndex.snapTo(focusedIndex.toFloat())
        }
    }
    LaunchedEffect(animIndex) {
        snapshotFlow { focusedIndex }.collect { targetIndex ->
            // Start the new target before cancelling the old animation so
            // Animatable can preserve its velocity during D-pad repeats.
            launch {
                val diff = kotlin.math.abs(animIndex.value - targetIndex)
                if (diff <= 2.5f && diff > 0.001f) {
                    animIndex.animateTo(
                        targetValue = targetIndex.toFloat(),
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = TvMotion.stiffness(550f),
                            visibilityThreshold = 0.005f
                        )
                    )
                } else if (diff > 0.001f) {
                    // Catalogue rebasing and large jumps stay within the
                    // bounded poster window instead of traversing every title.
                    animIndex.snapTo(targetIndex.toFloat())
                }
            }
        }
    }

    val baseWidth = 190.dp
    val expandedWidth = 437.dp
    val cardHeight = 270.dp
    val gap = 16.dp
    val itemSpacing = baseWidth + gap
    val ringStart = 16.dp

    val density = androidx.compose.ui.platform.LocalDensity.current
    val stripTopPaddingPx = with(density) { 4.dp.roundToPx() }
    val currentOnSelectionFrameTopMeasured by rememberUpdatedState(onSelectionFrameTopMeasured)
    val itemSpacingPx = remember(density, itemSpacing) { with(density) { itemSpacing.toPx() } }
    val ringStartPx = remember(density, ringStart) { with(density) { ringStart.toPx() } }
    val gapPx = remember(density, gap) { with(density) { gap.toPx() } }
    // Reduced hero slide distance: 35% of expanded card width (~150dp) for graceful, subtle glide
    val heroSlideDistancePx = remember(density, expandedWidth) { with(density) { (expandedWidth * 0.35f).toPx() } }
    val ringEnd = ringStart + expandedWidth
    val ringEndPx = remember(density, ringEnd) { with(density) { ringEnd.toPx() } }

    if (movies.isEmpty()) return

    val currentFocusedMovie = remember(focusedIndex, movies) {
        val movieIndex = ((focusedIndex % movies.size) + movies.size) % movies.size
        movies.getOrNull(movieIndex) ?: movies.first()
    }
    var metadataMovie by remember(title) { mutableStateOf(currentFocusedMovie) }
    LaunchedEffect(currentFocusedMovie, isRowFocused) {
        // Repeated keys move cards immediately, without retaining a stack of
        // outgoing synopsis layouts. The selected movie used for Play stays live.
        if (isRowFocused) delay(160)
        metadataMovie = currentFocusedMovie
    }

    val actualRowFocusRequester = rowFocusRequester ?: remember { FocusRequester() }

    val ringAlphaState = animateFloatAsState(
        targetValue = if (isRowFocused) 1f else 0f,
        animationSpec = tween(durationMillis = TvMotion.duration(260), easing = FastOutSlowInEasing),
        label = "rowRingAlpha"
    )

    // perf: hoist these title checks into remember. The result depends only
    // on the row's title, but the original was recomputed on every recomposition.
    val isContinueWatchingRow = remember(title) {
        title.contains("Continue Watching", ignoreCase = true) || title.contains("Netflix Pro", ignoreCase = true)
    }
    val isComingSoonRowCached = remember(title) {
        title.contains("Coming Soon", ignoreCase = true) ||
            title.contains("Worth the Wait", ignoreCase = true) ||
            title.contains("Remind", ignoreCase = true)
    }
    val isTop10Row = remember(title) { title.contains("Top 10", ignoreCase = true) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .graphicsLayer { this@graphicsLayer.alpha = alpha() }
            .clipToBounds()
    ) {
        // Row Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .onSizeChanged { currentOnSelectionFrameTopMeasured(it.height + stripTopPaddingPx) }
                .padding(start = 16.dp, end = 20.dp, top = 4.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Active Row Vertical Accent Indicator (always present in layout so title never shifts)
                Box(
                    modifier = Modifier
                        .size(width = 3.5.dp, height = 18.dp)
                        .graphicsLayer { this.alpha = ringAlphaState.value }
                        .background(NetflixRed, RoundedCornerShape(2.dp))
                )

                if (isContinueWatchingRow) {
                    Text(
                        text = title,
                        fontSize = 22.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    
                    // Branded Netflix Pro Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ProBadgeBrush)
                            .border(1.dp, Color(0xFFB3363F), RoundedCornerShape(4.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "PRO",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.1.sp
                        )
                    }

                    // Per-movie quality chips
                    currentFocusedMovie.quality.forEach { tag ->
                        key(tag) {
                            Box(
                                modifier = Modifier
                                    .border(1.dp, Color(0xFF595959), RoundedCornerShape(3.dp))
                                    .padding(horizontal = 5.dp, vertical = 1.5.dp)
                            ) {
                                Text(
                                    text = tag,
                                    color = Color(0xFFCCCCCC),
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                } else if (isTop10Row) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(NetflixRed)
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "TOP 10",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }
                    Text(
                        text = title,
                        fontSize = 22.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text(
                        text = title,
                        fontSize = 22.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Sleek carousel position counter when row is focused (faded via ringAlpha, never causes layout shift)
            if (movies.isNotEmpty()) {
                val currentPos = remember(focusedIndex, movies.size) {
                    if (movies.isEmpty()) 1 else (((focusedIndex % movies.size) + movies.size) % movies.size) + 1
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .graphicsLayer { this.alpha = ringAlphaState.value }
                        .background(Color.White.copy(alpha = 0.10f), RoundedCornerShape(10.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 8.dp, vertical = 2.5.dp)
                ) {
                    Text(
                        text = "$currentPos / ${movies.size}",
                        color = Color.White.copy(alpha = 0.80f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(cardHeight + 28.dp)
                .padding(top = 4.dp, bottom = 4.dp)
                .onPreviewKeyEvent { keyEvent ->
                    if (isRowFocused && keyEvent.type == KeyEventType.KeyDown) {
                        when (keyEvent.nativeKeyEvent.keyCode) {
                            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                                if (movies.isEmpty()) return@onPreviewKeyEvent true
                                if (!isInfinite && focusedIndex >= movies.size - 1) return@onPreviewKeyEvent true
                                if (!horizontalKeyPacer.accept(1)) return@onPreviewKeyEvent true
                                focusedIndex++
                                onRowFocused()
                                true
                            }
                            KeyEvent.KEYCODE_DPAD_LEFT -> {
                                if (movies.isEmpty()) return@onPreviewKeyEvent true
                                if (!isInfinite && focusedIndex <= 0) return@onPreviewKeyEvent true
                                if (!horizontalKeyPacer.accept(-1)) return@onPreviewKeyEvent true
                                focusedIndex--
                                onRowFocused()
                                true
                            }
                            KeyEvent.KEYCODE_DPAD_DOWN -> onDpadDown()
                            KeyEvent.KEYCODE_DPAD_UP -> onDpadUp()
                            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                                // perf: isComingSoonRow was being recomputed on
                                // every keypress lambda creation (i.e. every
                                // recomposition). It's constant for the row's
                                // lifetime; hoist to remember.
                                if ((currentFocusedMovie.isComingSoon || isComingSoonRowCached) && onToggleReminder != null) {
                                    onToggleReminder(currentFocusedMovie)
                                } else {
                                    onMovieClick(currentFocusedMovie)
                                }
                                true
                            }
                            else -> false
                        }
                    } else false
                }
                .onFocusChanged { isRowFocused = it.hasFocus }
                .focusProperties {
                    left = FocusRequester.Cancel
                    right = FocusRequester.Cancel
                }
                .focusRequester(actualRowFocusRequester)
                .focusable()
                .clipToBounds()
                .pointerInput(movies.size, isInfinite) {
                    var accumulatedHorizontalDrag = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { accumulatedHorizontalDrag = 0f },
                        onDragEnd = { accumulatedHorizontalDrag = 0f },
                        onDragCancel = { accumulatedHorizontalDrag = 0f },
                        onHorizontalDrag = { change, dragAmount ->
                            change.consume()
                            accumulatedHorizontalDrag += dragAmount
                            val thresholdPx = 60f
                            if (accumulatedHorizontalDrag < -thresholdPx) {
                                if (movies.isNotEmpty() && (isInfinite || focusedIndex < movies.size - 1)) {
                                    focusedIndex++
                                    val movieIndex = ((focusedIndex % movies.size) + movies.size) % movies.size
                                    currentMovies.getOrNull(movieIndex)?.let { currentOnMovieFocused(it) }
                                    currentOnRowFocused()
                                }
                                accumulatedHorizontalDrag = 0f
                            } else if (accumulatedHorizontalDrag > thresholdPx) {
                                if (movies.isNotEmpty() && (isInfinite || focusedIndex > 0)) {
                                    focusedIndex--
                                    val movieIndex = ((focusedIndex % movies.size) + movies.size) % movies.size
                                    currentMovies.getOrNull(movieIndex)?.let { currentOnMovieFocused(it) }
                                    currentOnRowFocused()
                                }
                                accumulatedHorizontalDrag = 0f
                            }
                        }
                    )
                }
        ) {
            val baseIndex = focusedIndex
            // A settled preceding card is fully outside this clipped strip.
            // Retain it only while sliding right, when its final sliver remains visible.
            val startWindow = if (isRowFocused && animatedFloor < focusedIndex) {
                if (isInfinite) baseIndex - 1 else maxOf(0, baseIndex - 1)
            } else baseIndex
            val endWindow = if (isRowFocused) {
                if (isInfinite) baseIndex + 4 else minOf(movies.size - 1, baseIndex + 4)
            } else {
                if (isInfinite) baseIndex + 3 else minOf(movies.size - 1, baseIndex + 3)
            }

            // ── LAYER 1: Sliding portrait card strip (Zero recomposition on animation frames) ──
            // This calculation only runs at card/focus boundaries. Do not remember
            // lock answers: profile/rating state may change without the list size.
            val lockedMap = if (isMovieLocked == null) emptyMap() else {
                val out = HashMap<String, Boolean>(8)
                for (j in startWindow..endWindow) {
                    val movie = movies[((j % movies.size) + movies.size) % movies.size]
                    if (!out.containsKey(movie.id)) out[movie.id] = isMovieLocked(movie)
                }
                for (j in animatedFloor..animatedFloor + 1) {
                    val movie = movies[((j % movies.size) + movies.size) % movies.size]
                    if (!out.containsKey(movie.id)) out[movie.id] = isMovieLocked(movie)
                }
                out
            }
            for (i in startWindow..endWindow) {
                key("portrait_$i") {
                    val movieIndex = if (movies.isNotEmpty()) ((i % movies.size) + movies.size) % movies.size else 0
                    val movie = movies.getOrNull(movieIndex)

                    if (movie != null) {
                        Box(
                            modifier = Modifier
                                .graphicsLayer {
                                    val animVal = animIndex.value
                                    val f = kotlin.math.floor(animVal).toInt()
                                    val frac = animVal - f
                                    val offsetPx = when {
                                        i < f -> ringStartPx - itemSpacingPx * (f - i) - itemSpacingPx * frac
                                        i == f -> ringStartPx - itemSpacingPx * frac
                                        i == f + 1 -> {
                                            val startX = ringEndPx + gapPx
                                            val targetX = ringStartPx
                                            startX + (targetX - startX) * frac
                                        }
                                        else -> ringEndPx + gapPx + itemSpacingPx * (i - f - 1) - itemSpacingPx * frac
                                    }
                                    translationX = offsetPx
                                    // Subtle depth-of-field dimming for unfocused background cards
                                    this@graphicsLayer.alpha = if (isRowFocused) 0.82f else 1f
                                }
                                .zIndex(1f)
                        ) {
                            // perf: skip composition/draw when completely hidden underneath LAYER 2's 437dp hero card
                            val isHiddenUnderHero = i == focusedIndex && isHeroSettled
                            if (!isHiddenUnderHero) {
                                MovieCardItem(
                                    movie = movie,
                                    isPortrait = isPortrait,
                                    cardWidth = baseWidth,
                                    height = cardHeight,
                                    isExpanded = false,
                                    isFocused = false,
                                    progress = continueWatchingProgressMap?.get(movie.id),
                                    rank = if (isTop10Row) movieIndex + 1 else null,
                                    isLocked = lockedMap[movie.id] == true,
                                    onClick = {
                                        focusedIndex = i
                                        onMovieFocused(movie)
                                        onRowFocused()
                                        onMovieClick(movie)
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // ── LAYER 2: Expanded hero content inside ring viewport (35% subtle slide + soft crossfade) ──
            Box(
                modifier = Modifier
                    .offset(x = ringStart)
                    .width(expandedWidth)
                    .height(cardHeight)
                    .graphicsLayer {
                        this@graphicsLayer.alpha = if (isRowFocused) 1f else 0.85f
                    }
                    .shadow(
                        elevation = 8.dp,
                        shape = CardCornerShape,
                        clip = false,
                        spotColor = Color.Black.copy(alpha = 0.75f),
                        ambientColor = Color.Black.copy(alpha = 0.5f)
                    )
                    .clip(CardCornerShape)
                    .clipToBounds()
                    .zIndex(5f)
            ) {
                val animFloor = animatedFloor
                val heroEnd = if (showIncomingHero) animFloor + 1 else animFloor
                // A card keeps its image/composition as it moves from incoming to
                // outgoing. Fractions are read only by graphicsLayer, never by the
                // composition; the existing slide/crossfade now needs no per-frame
                // card, image-request, badge or text recomposition.
                for (heroIndex in animFloor..heroEnd) {
                    key("hero_$heroIndex") {
                        val movieIndex = ((heroIndex % movies.size) + movies.size) % movies.size
                        val movie = movies[movieIndex]
                        val isIncoming = heroIndex != animFloor
                        Box(
                            modifier = Modifier.graphicsLayer {
                                val fraction = (animIndex.value - animFloor).coerceIn(0f, 1f)
                                translationX = if (isIncoming) {
                                    heroSlideDistancePx * (1f - fraction)
                                } else {
                                    -heroSlideDistancePx * fraction
                                }
                                this.alpha = if (isIncoming) fraction else 1f - fraction
                            }
                        ) {
                            MovieCardItem(
                                movie = movie,
                                isPortrait = isPortrait,
                                cardWidth = expandedWidth,
                                height = cardHeight,
                                isExpanded = true,
                                isFocused = isRowFocused,
                                shouldFetchLogo = isRowFocused && isHeroSettled && heroIndex == focusedIndex,
                                progress = continueWatchingProgressMap?.get(movie.id),
                                rank = if (isTop10Row) movieIndex + 1 else null,
                                isLocked = lockedMap[movie.id] == true,
                                onClick = { onMovieClick(movie) }
                            )
                        }
                    }
                }

                val activePreviewPlayer = previewPlayer
                val displayedMovieId = movies.getOrNull(
                    ((animFloor % movies.size) + movies.size) % movies.size
                )?.id
                if (activePreviewPlayer != null && previewMovieId == displayedMovieId && canShowPreview) {
                    AndroidView(
                        factory = { playerContext ->
                            PlayerView(playerContext).also { playerView ->
                                previewViewHolder.view = playerView
                                playerView.useController = false
                                playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                playerView.subtitleView?.visibility = android.view.View.GONE
                                playerView.setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                                playerView.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                            }
                        },
                        update = { playerView ->
                            if (playerView.player !== activePreviewPlayer) {
                                playerView.player = activePreviewPlayer
                            }
                        },
                        onRelease = { playerView ->
                            playerView.player = null
                            previewViewHolder.view = null
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Home draws its shared frame above the moving viewport. Other callers
            // keep a local frame, fully visible as soon as the row takes focus.
            if (showSelectionRing) Box(
                modifier = Modifier
                    .offset(x = ringStart)
                    .width(expandedWidth)
                    .height(cardHeight)
                    .graphicsLayer {
                        this@graphicsLayer.alpha = if (isRowFocused) 1f else 0f
                        this@graphicsLayer.translationY = verticalRingOffsetProvider()
                    }
                    .border(3.5.dp, Color.White, CardCornerShape)
                    .zIndex(10f)
            )
        }

        // Active Movie Metadata & Synopsis below row — slides in matching card direction when row is focused
        if (isRowFocused) {
            AnimatedContent(
                targetState = metadataMovie,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(68.dp)
                    .padding(start = 16.dp, top = 4.dp, end = 40.dp, bottom = 6.dp),
                transitionSpec = {
                    (slideInHorizontally(
                        animationSpec = tween(TvMotion.duration(240), easing = LinearOutSlowInEasing),
                        initialOffsetX = { fullWidth -> (fullWidth * 0.12f).toInt() }
                    ) + fadeIn(animationSpec = tween(TvMotion.duration(240), easing = LinearOutSlowInEasing)))
                    .togetherWith(
                        slideOutHorizontally(
                            animationSpec = tween(TvMotion.duration(240), easing = LinearOutSlowInEasing),
                            targetOffsetX = { fullWidth -> (-fullWidth * 0.08f).toInt() }
                        ) + fadeOut(animationSpec = tween(TvMotion.duration(150), easing = FastOutSlowInEasing))
                    )
                },
                label = "rowMetadataSlide"
            ) { movie ->
                MovieMetadataDetails(movie = movie)
            }
        }
    }
}

@Composable
private fun MovieMetadataDetails(movie: Movie) {
    // perf: use Arrangement.spacedBy(2.dp) on the parent Column instead of a
    // dedicated Spacer composable. One less child to compose, lay out, and
    // remember. With ~20 rows on screen this is 20 fewer layout nodes.
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = movie.type.ifBlank { "Movie" },
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Text("•", color = Color.Gray, fontSize = 13.sp)
            Text(
                text = movie.year.ifBlank { "2025" },
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text("•", color = Color.Gray, fontSize = 13.sp)
            Text(
                text = movie.duration.ifBlank { "Feature" },
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text("•", color = Color.Gray, fontSize = 13.sp)

            Box(
                modifier = Modifier
                    .background(NetflixRed, BadgeShape3)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = movie.rating.ifBlank { RatingDefaults.MISSING },
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Text(
            text = movie.description,
            color = Color(0xFFD9D9D9),
            fontSize = 12.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 15.sp,
            modifier = Modifier.fillMaxWidth(0.65f)
        )
    }
}

@Composable
fun MovieCardItem(
    movie: Movie,
    isPortrait: Boolean,
    cardWidth: Dp,
    height: Dp = 270.dp,
    isExpanded: Boolean = false,
    isFocused: Boolean = false,
    shouldFetchLogo: Boolean = false,
    progress: Float? = null,
    rank: Int? = null,
    isComingSoonRow: Boolean = false,
    isReminded: Boolean = false,
    isLocked: Boolean = false,
    onClick: () -> Unit
) {
    val baseWidth = 190.dp
    val expandedWidth = baseWidth * 2.3f
    val expandedProgress = ((cardWidth - baseWidth) / (expandedWidth - baseWidth)).coerceIn(0f, 1f)

    // Netflix uses ONE consistent high-resolution image per card (seamlessly cropped across expansion)
    val imageUrl = remember(movie, isPortrait) {
        movie.cardImageUrl(isPortrait)
    }

    val cardCtx = androidx.compose.ui.platform.LocalContext.current
    val artworkKind = movie.cardArtworkKind(isPortrait)
    val imageRequest = remember(imageUrl, cardCtx, isExpanded, isPortrait, artworkKind) {
        cardImageRequest(cardCtx, imageUrl, isExpanded, isPortrait, artworkKind)
    }

    // Dynamic TMDB Logo for expanded/focused card
    var dynamicLogoUrl by remember(movie.id, movie.logoUrl, isExpanded) {
        mutableStateOf(if (isExpanded) (movie.logoUrl ?: com.example.data.TmdbRepository.getCachedLogo(movie.id)) else null)
    }

    if (isExpanded && shouldFetchLogo && dynamicLogoUrl.isNullOrBlank()) {
        LaunchedEffect(movie.id, shouldFetchLogo) {
            // Avoid logo work while the user is still moving through cards.
            delay(1_800)
            HomeStartupGate.awaitBrowsingIdle()
            val cached = com.example.data.TmdbRepository.getCachedLogo(movie.id)
            if (!cached.isNullOrBlank()) {
                dynamicLogoUrl = cached
            } else {
                val isTv = movie.type.equals("Series", ignoreCase = true) || movie.type.equals("TV", ignoreCase = true) || movie.duration.contains("Season", ignoreCase = true)
                val fetched = cardLogoRepository.fetchLogoUrl(movie.id.toLongOrNull() ?: 0L, isTv)
                if (!fetched.isNullOrBlank()) {
                    dynamicLogoUrl = fetched
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .width(cardWidth)
            .height(height)
            .clip(CardCornerShape)
            .background(Color(0xFF0D0D0D))
            .clickable { onClick() }
    ) {
        // 1. Single Rock-Solid Image (No swapping/flickering)
        AsyncImage(
            model = imageRequest,
            contentDescription = movie.title,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alignment = Alignment.Center
        )

        // perf: hoist the rank-in-1..10 check. Used 4x in the body (badge,
        // lock alignment, big number, title padding); with 10 cards in LAYER 1
        // and 2 in LAYER 2 that's 60 redundant checks per focus change.
        val isTop10Rank = rank != null && rank in 1..10

        // Top 10 Badge
        if (isTop10Rank) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .background(NetflixRed, BadgeShape3)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "TOP 10",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
            }
        }

        // Lock Badge Overlay
        if (isLocked) {
            Box(
                modifier = Modifier
                    .align(if (isTop10Rank) Alignment.TopStart else Alignment.TopEnd)
                    .padding(8.dp)
                    .background(Color(0xFF1A1A1A), BadgeShape4)
                    .border(1.dp, Color(0xFFCC9A06), BadgeShape4)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Locked Title",
                        tint = Color(0xFFFFC107),
                        modifier = Modifier.size(10.dp)
                    )
                    Text(
                        text = "LOCK",
                        color = Color(0xFFFFC107),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        // Expanded 2.3x Hero Slot Decorator: Top-Left Netflix N Logo + Resume Tag
        // Audit §4g: drop the standalone N icon and merge "N · RESUME" into a single chip.
        if (expandedProgress > 0.05f) {
            if (progress != null && progress > 0f) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp)
                        .background(NetflixRed, BadgeShape3)
                        .graphicsLayer { this.alpha = expandedProgress }
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "N · RESUME",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.8.sp
                    )
                }
            }
        }

        // Bottom Gradient Overlay (Only on Expanded Hero Card to keep vertical posters clean & fast)
        if (expandedProgress > 0.02f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { this.alpha = expandedProgress }
                    .background(CardOverlayGradient)
            )
        }

        // Giant Stylized Netflix Top 10 Outline Number in Bottom-Left
        if (isTop10Rank) {
            Top10RankNumber(
                rank = rank!!,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(
                        start = 6.dp,
                        bottom = if (isLocked) 20.dp else 4.dp
                    )
                    .zIndex(4f)
            )
        }

        val titlePaddingStart = if (isTop10Rank && expandedProgress < 0.2f) 52.dp else 12.dp
        val bottomContentPadding = if (progress != null && progress > 0f) 20.dp else 12.dp

        // Expanded Hero Card Title & Micro-Metadata Deck (only composed for expanded cards)
        if (isExpanded && expandedProgress > 0.01f) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = titlePaddingStart, end = 12.dp, bottom = bottomContentPadding)
                    .graphicsLayer {
                        alpha = expandedProgress
                        translationY = (1f - expandedProgress) * 10f
                    }
            ) {
                if (!dynamicLogoUrl.isNullOrBlank()) {
                    val logoCtx = androidx.compose.ui.platform.LocalContext.current
                    val logoImageRequest = remember(dynamicLogoUrl, logoCtx) {
                        coil.request.ImageRequest.Builder(logoCtx)
                            .data(TvImagePolicy.artworkUrl(dynamicLogoUrl.orEmpty(), 210, TvArtworkKind.LOGO))
                            .crossfade(false)
                            .bitmapConfig(android.graphics.Bitmap.Config.ARGB_8888)
                            .allowRgb565(false)
                            .size(210, 42)
                            .memoryCachePolicy(coil.request.CachePolicy.ENABLED)
                            .diskCachePolicy(coil.request.CachePolicy.ENABLED)
                            .build()
                    }
                    AsyncImage(
                        model = logoImageRequest,
                        contentDescription = movie.title,
                        modifier = Modifier
                            .height(36.dp)
                            .widthIn(max = 210.dp),
                        contentScale = ContentScale.Fit,
                        alignment = Alignment.CenterStart
                    )
                } else {
                    Text(
                        text = movie.title,
                        color = Color.White,
                        fontSize = 17.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = androidx.compose.ui.text.TextStyle(
                            shadow = androidx.compose.ui.graphics.Shadow(
                                color = Color(0xFF0D0D0D),
                                blurRadius = 8f
                            )
                        )
                    )
                }

                if (expandedProgress > 0.15f) {
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "98% Match",
                            color = Color(0xFF46D369),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(2.5.dp))
                                .border(0.8.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(2.5.dp))
                                .padding(horizontal = 4.5.dp, vertical = 0.5.dp)
                        ) {
                            Text(
                                text = movie.rating.ifBlank { "18+" },
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (movie.duration.isNotBlank()) {
                            Text(
                                text = movie.duration,
                                color = Color.White.copy(alpha = 0.80f),
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        val qualityTag = movie.quality.firstOrNull() ?: if (movie.type.contains("Series", true)) "HD" else "4K"
                        Box(
                            modifier = Modifier
                                .border(0.8.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(2.5.dp))
                                .padding(horizontal = 4.dp, vertical = 0.5.dp)
                        ) {
                            Text(
                                text = qualityTag,
                                color = Color.White.copy(alpha = 0.80f),
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Remind Me / Reminded / Release Date Badge Overlay
        val showBellBadge = movie.isComingSoon || isComingSoonRow || isReminded || movie.releaseDateBadge != null
        if (showBellBadge) {
            val badgeText = when {
                isReminded -> "Reminded"
                movie.releaseDateBadge != null -> movie.releaseDateBadge!!
                else -> "Remind Me"
            }
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .zIndex(6f)
            ) {
                Box(
                    modifier = Modifier
                        .clip(BadgeShape12)
                        .background(if (isReminded) NetflixRed else Color(0xFF262626))
                        .border(
                            width = if (isReminded) 1.5.dp else 1.dp,
                            color = Color(0xFFA0A0A0),
                            shape = BadgeShape12
                        )
                        .padding(horizontal = 7.dp, vertical = 2.5.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = if (isReminded) Icons.Default.NotificationsActive else Icons.Default.Notifications,
                            contentDescription = badgeText,
                            tint = Color.White,
                            modifier = Modifier.size(11.dp)
                        )
                        Text(
                            text = badgeText,
                            color = Color.White,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        if (progress != null && progress > 0f) {
            // Elegant Netflix Continue Watching progress bar with dark track and red indicator
            val progressHeight = if (isFocused || isExpanded) 5.dp else 3.5.dp
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(progressHeight)
                    .background(Color(0x80000000))
                    .align(Alignment.BottomCenter)
            ) {
                // Inactive dark track
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x40FFFFFF))
                )
                // Active vibrant red progress
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(progress.coerceIn(0.04f, 1f))
                        .background(NetflixRed, RoundedCornerShape(topEnd = 2.dp, bottomEnd = 2.dp))
                )
            }
        }
    }
}

@Composable
fun Top10RankNumber(
    rank: Int,
    modifier: Modifier = Modifier
) {
    val rankText = rank.toString()

    Box(
        modifier = modifier,
        contentAlignment = Alignment.BottomStart
    ) {
        // Deep shadow layer for high contrast over any poster art
        Text(
            text = rankText,
            fontSize = 90.sp,
            fontWeight = FontWeight.Black,
            color = Color.Black.copy(alpha = 0.95f),
            letterSpacing = (-6).sp,
            modifier = Modifier.offset(x = 2.dp, y = 2.dp)
        )
        // Dark Obsidian Body Fill
        Text(
            text = rankText,
            fontSize = 90.sp,
            fontWeight = FontWeight.Black,
            color = Color(0xFF141416),
            letterSpacing = (-6).sp
        )
        // Authentic Silver-White Outline Stroke (Netflix Style)
        Text(
            text = rankText,
            fontSize = 90.sp,
            fontWeight = FontWeight.Black,
            color = Color(0xFFF5F5F5),
            letterSpacing = (-6).sp,
            style = androidx.compose.ui.text.TextStyle(
                drawStyle = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = 4.5f,
                    join = androidx.compose.ui.graphics.StrokeJoin.Round
                )
            )
        )
    }
}
