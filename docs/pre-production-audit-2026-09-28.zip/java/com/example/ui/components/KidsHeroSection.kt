package com.example.ui.components

import android.view.KeyEvent
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.tv.material3.Surface
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Border
import coil.compose.AsyncImage
import com.example.model.Movie
import com.example.ui.util.TvImagePolicy
import com.example.ui.util.TvArtworkKind
import com.example.ui.util.HomeStartupGate

@Composable
fun KidsHeroSection(
    featuredMovies: List<Movie>,
    activeMovie: Movie,
    onMovieSelected: (Movie) -> Unit,
    onPlayMovie: (Movie) -> Unit,
    onMovieClick: (Movie) -> Unit,
    focusRequester: FocusRequester,
    onDpadUp: () -> Boolean,
    onDpadDown: () -> Boolean,
    modifier: Modifier = Modifier,
    height: Dp = 340.dp,
    viewModel: com.example.ui.NetflixViewModel? = null
) {
    val effectiveMovies = remember(featuredMovies) {
        featuredMovies.distinctBy { it.id }.take(7)
    }

    // perf: hoist LocalContext.current once so every remember block downstream
    // captures the same context (avoids re-allocating the snapshot reader per key).
    val ctx = androidx.compose.ui.platform.LocalContext.current

    val density = androidx.compose.ui.platform.LocalDensity.current
    val avatarSizePx = with(density) { 56.dp.roundToPx() }
    val heroLogoSizePx = with(density) { 280.dp.roundToPx() to 58.dp.roundToPx() }
    val cardLogoSizePx = with(density) { 120.dp.roundToPx() to 32.dp.roundToPx() }
    val resolvedLogos = remember(effectiveMovies) { mutableStateMapOf<String, String>() }

    // One cancellable producer replaces overlapping fire-and-forget logo bursts.
    // Existing cached logos still paint immediately; missing logos resolve serially.
    LaunchedEffect(effectiveMovies, viewModel) {
        kotlinx.coroutines.delay(400)
        for (movie in effectiveMovies) {
            HomeStartupGate.awaitBrowsingIdle()
            val cached = movie.logoUrl?.takeIf { it.isNotBlank() } ?: viewModel?.getCachedLogo(movie.id)
            val logo = cached ?: kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                viewModel?.fetchLogoUrl(movie.id, movie.type.equals("Series", true) || movie.type.equals("TV", true))
            }
            if (!logo.isNullOrBlank()) resolvedLogos[movie.id] = logo
        }
    }
    LaunchedEffect(activeMovie.id, effectiveMovies, viewModel) {
        if (effectiveMovies.any { it.id == activeMovie.id }) return@LaunchedEffect
        val logo = activeMovie.logoUrl?.takeIf { it.isNotBlank() }
            ?: viewModel?.getCachedLogo(activeMovie.id)
            ?: kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                viewModel?.fetchLogoUrl(activeMovie.id, activeMovie.type.equals("Series", true) || activeMovie.type.equals("TV", true))
            }
        if (!logo.isNullOrBlank()) resolvedLogos[activeMovie.id] = logo
    }

    var focusedIndex by remember { mutableIntStateOf(0) }
    val itemFocusRequesters = remember(effectiveMovies.size, focusRequester) {
        List(effectiveMovies.size) { index -> if (index == 0) focusRequester else FocusRequester() }
    }

    // Clean Character Carousel Container directly over fullscreen background poster
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        // Active Movie Title Logo & Metadata in Hero Stage
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 48.dp, top = 8.dp)
        ) {
            val currentHeroLogoUrl = activeMovie.logoUrl?.takeIf { it.isNotBlank() }
                ?: resolvedLogos[activeMovie.id]
                ?: viewModel?.getCachedLogo(activeMovie.id)

            if (!currentHeroLogoUrl.isNullOrBlank()) {
                // perf: wrap raw URL in remember-keyed ImageRequest so recomposition
                // (frequent on the kids hero — multiple state writes per frame) does
                // not rebuild the request. Also bound decode to 280x58 (visible slot)
                // so TMDB's 500x281 logo doesn't decode full-size for a 58dp tall image.
                val heroLogoReq = remember(currentHeroLogoUrl, heroLogoSizePx, ctx) {
                    coil.request.ImageRequest.Builder(ctx)
                        .data(TvImagePolicy.artworkUrl(currentHeroLogoUrl.orEmpty(), heroLogoSizePx.first, TvArtworkKind.LOGO))
                        .crossfade(false)
                        .bitmapConfig(android.graphics.Bitmap.Config.RGB_565)
                        .allowRgb565(true)
                        .size(heroLogoSizePx.first, heroLogoSizePx.second)
                        .memoryCachePolicy(coil.request.CachePolicy.ENABLED)
                        .diskCachePolicy(coil.request.CachePolicy.ENABLED)
                        .build()
                }
                AsyncImage(
                    model = heroLogoReq,
                    contentDescription = activeMovie.title,
                    modifier = Modifier
                        .height(58.dp)
                        .widthIn(max = 280.dp),
                    contentScale = ContentScale.Fit,
                    alignment = Alignment.CenterStart
                )
            } else {
                Text(
                    text = activeMovie.title,
                    color = Color.White,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(Color(0xFFFF9D2B), RoundedCornerShape(3.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = activeMovie.rating.ifBlank { "TV-Y7" },
                        color = Color.Black,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Text(
                    text = activeMovie.year.ifBlank { "2025" },
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Text("•", color = Color.Gray, fontSize = 12.sp)

                Text(
                    text = activeMovie.duration.ifBlank { "Kids Feature" },
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Horizontal Character Cards Carousel — positioned lower down near movie rows
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 2.dp, start = 32.dp, end = 32.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.Bottom
        ) {
            effectiveMovies.forEachIndexed { index, movie ->
                val isFocused = (focusedIndex == index)
                val itemRequester = itemFocusRequesters.getOrNull(index) ?: focusRequester

                val cardScale by animateFloatAsState(
                    targetValue = if (isFocused) 1.10f else 0.96f,
                    animationSpec = tween(240, easing = FastOutSlowInEasing),
                    label = "cardScale_$index"
                )

                val subtitleTag = when (index) {
                    0 -> "New for you"
                    1 -> "Top Pick"
                    2 -> "Trending"
                    3 -> "Popular"
                    else -> "Kids Choice"
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .graphicsLayer {
                            scaleX = cardScale
                            scaleY = cardScale
                        }
                ) {
                    // Character Pop-out & Card Box
                    Box(
                        modifier = Modifier
                            .width(136.dp)
                            .height(88.dp),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        // 1. Character Pop-out Icon (sitting on top edge of card)
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .offset(y = (-6).dp)
                                .size(56.dp)
                                .zIndex(2f)
                                .shadow(8.dp, CircleShape)
                                .clip(CircleShape)
                                .background(Color(0xFF1E232D))
                                .border(
                                    2.dp,
                                    if (isFocused) Color.White else Color.White.copy(alpha = 0.35f),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            val characterImage = movie.posterUrl.ifBlank { movie.backdropUrl }
                            // perf: 56dp circular avatar — cap decode to 56x56 so we
                            // never decode the 2K poster for a thumbnail avatar.
                            // Wrap in remember to avoid per-recomposition request rebuilds.
                            val charReq = remember(characterImage, avatarSizePx, ctx) {
                                coil.request.ImageRequest.Builder(ctx)
                                    .data(TvImagePolicy.artworkUrl(characterImage, avatarSizePx,
                                        if (movie.posterUrl.isNotBlank()) TvArtworkKind.POSTER else TvArtworkKind.BACKDROP))
                                    .crossfade(false)
                                    .bitmapConfig(android.graphics.Bitmap.Config.RGB_565)
                                    .allowRgb565(true)
                                    .size(avatarSizePx, avatarSizePx)
                                    .memoryCachePolicy(coil.request.CachePolicy.ENABLED)
                                    .diskCachePolicy(coil.request.CachePolicy.ENABLED)
                                    .build()
                            }
                            AsyncImage(
                                model = charReq,
                                contentDescription = "${movie.title} Character",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }

                        // 2. Translucent Glass Title Card
                        Surface(
                            onClick = {
                                onPlayMovie(movie)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .focusRequester(itemRequester)
                                .onFocusChanged {
                                    if (it.isFocused) {
                                        focusedIndex = index
                                        onMovieSelected(movie)
                                    }
                                }
                                .onPreviewKeyEvent { keyEvent ->
                                    if (keyEvent.type == KeyEventType.KeyDown) {
                                        when (keyEvent.nativeKeyEvent.keyCode) {
                                            KeyEvent.KEYCODE_DPAD_UP -> onDpadUp()
                                            KeyEvent.KEYCODE_DPAD_DOWN -> onDpadDown()
                                            KeyEvent.KEYCODE_DPAD_LEFT -> {
                                                if (index > 0) {
                                                    try { itemFocusRequesters[index - 1].requestFocus() } catch (_: Exception) {}
                                                    true
                                                } else false
                                            }
                                            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                                                if (index < effectiveMovies.size - 1) {
                                                    try { itemFocusRequesters[index + 1].requestFocus() } catch (_: Exception) {}
                                                    true
                                                } else false
                                            }
                                            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                                                onPlayMovie(movie)
                                                true
                                            }
                                            else -> false
                                        }
                                    } else false
                                },
                            shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(8.dp)),
                            colors = ClickableSurfaceDefaults.colors(
                                containerColor = if (isFocused) Color(0xFF1E293B).copy(alpha = 0.95f) else Color.Black.copy(alpha = 0.65f),
                                focusedContainerColor = Color(0xFF1E293B).copy(alpha = 0.95f)
                            ),
                            border = ClickableSurfaceDefaults.border(
                                border = Border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))),
                                focusedBorder = Border(BorderStroke(2.5.dp, Color.White))
                            ),
                            scale = ClickableSurfaceDefaults.scale(focusedScale = 1.0f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                val currentLogoUrl = movie.logoUrl?.takeIf { it.isNotBlank() }
                                    ?: resolvedLogos[movie.id]
                                    ?: viewModel?.getCachedLogo(movie.id)

                                if (!currentLogoUrl.isNullOrBlank()) {
                                    // perf: 32dp tall logo, ~120dp wide; cap decode so
                                    // we don't waste RAM on the full 500x281 TMDB render.
                                    val cardLogoReq = remember(currentLogoUrl, cardLogoSizePx, ctx) {
                                        coil.request.ImageRequest.Builder(ctx)
                                            .data(TvImagePolicy.artworkUrl(currentLogoUrl.orEmpty(), cardLogoSizePx.first, TvArtworkKind.LOGO))
                                            .crossfade(false)
                                            .bitmapConfig(android.graphics.Bitmap.Config.RGB_565)
                                            .allowRgb565(true)
                                            .size(cardLogoSizePx.first, cardLogoSizePx.second)
                                            .memoryCachePolicy(coil.request.CachePolicy.ENABLED)
                                            .diskCachePolicy(coil.request.CachePolicy.ENABLED)
                                            .build()
                                    }
                                    AsyncImage(
                                        model = cardLogoReq,
                                        contentDescription = movie.title,
                                        modifier = Modifier
                                            .fillMaxWidth(0.92f)
                                            .height(32.dp),
                                        contentScale = ContentScale.Fit
                                    )
                                } else {
                                    Text(
                                        text = movie.title.uppercase(),
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        textAlign = TextAlign.Center,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Subtitle tag below card when focused (pushed lower)
                    if (isFocused) {
                        Text(
                            text = subtitleTag,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    } else {
                        Spacer(modifier = Modifier.height(17.dp))
                    }
                }
            }
        }
    }
}
