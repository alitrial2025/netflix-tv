package com.example.ui.components

import android.view.KeyEvent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.NightlightRound
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TheaterComedy
import androidx.compose.material.icons.filled.Theaters
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.util.TvMotion
import com.example.ui.util.TvKeyPacer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import kotlin.math.ceil
import kotlin.math.floor

fun getCategoryThemeColor(category: String): Color {
    val clean = category.trim().lowercase()
    return when {
        clean.contains("drama") -> Color(0xFFCC8CAA)
        clean.contains("comed") -> Color(0xFFE1B576)
        clean.contains("action") -> Color(0xFFE78C77)
        clean.contains("romance") -> Color(0xFFE89BB8)
        clean.contains("anime") -> Color(0xFFADA5EA)
        clean.contains("kid") || clean.contains("family") -> Color(0xFF88C9C2)
        clean.contains("sci-fi") || clean.contains("scifi") || clean.contains("fiction") -> Color(0xFF8CC6E5)
        clean.contains("thrill") || clean.contains("crime") -> Color(0xFFB1C59D)
        clean.contains("docu") -> Color(0xFFD2BD94)
        clean.contains("horror") -> Color(0xFFC493AC)
        clean.contains("fantasy") -> Color(0xFFC1A6DF)
        else -> Color(0xFF475569)
    }
}

fun getCategoryCardColor(category: String, isFocused: Boolean): Color {
    val base = getCategoryThemeColor(category)
    return if (isFocused) lerp(Color(0xFF1A202A), base, 0.24f) else lerp(Color(0xFF15181E), base, 0.10f)
}

@Suppress("UNUSED_PARAMETER")
@Composable
fun CategoriesBarSection(
    categoriesFocusRequester: FocusRequester? = null,
    height: Dp = 116.dp,
    alpha: () -> Float = { 1f },
    modifier: Modifier = Modifier,
    moodColor: Color = Color.Transparent,
    onCategorySelected: (String) -> Unit = {},
    onCategoryClick: (String) -> Unit = {},
    onFocused: () -> Unit = {},
    onDpadUp: () -> Boolean = { false },
    onDpadDown: () -> Boolean = { false },
    verticalRingOffsetProvider: () -> Float = { 0f },
    moodColorProvider: (() -> Color)? = null
) {
    val categories = remember {
        listOf(
            "Dramas", "Comedies", "Action", "Romance", "Anime",
            "Kids & Family", "Sci-Fi", "Thrillers", "Documentaries",
            "Horror", "Fantasy"
        )
    }
    val initialIndex = remember { 1000 * categories.size }
    var focusedIndex by rememberSaveable { mutableIntStateOf(initialIndex) }
    val keyPacer = remember { TvKeyPacer() }
    var isCategoriesFocused by remember { mutableStateOf(false) }
    // Retarget from the current position and velocity, even while a key is held.
    val animIndex = animateFloatAsState(
        targetValue = focusedIndex.toFloat(),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = TvMotion.stiffness(550f),
            visibilityThreshold = 0.005f
        ),
        label = "categoriesPosition"
    )
    val animatedFloor by remember { derivedStateOf { floor(animIndex.value).toInt() } }
    val localFocusRequester = remember { FocusRequester() }
    val actualFocusRequester = categoriesFocusRequester ?: localFocusRequester

    val onFocusedState = rememberUpdatedState(onFocused)
    val onCategoryClickState = rememberUpdatedState(onCategoryClick)
    val onCategorySelectedState = rememberUpdatedState(onCategorySelected)
    val onDpadUpState = rememberUpdatedState(onDpadUp)
    val onDpadDownState = rememberUpdatedState(onDpadDown)
    LaunchedEffect(isCategoriesFocused, focusedIndex) {
        if (isCategoriesFocused) {
            // Navigation responds immediately; a held key does not restart the
            // whole screen's colour blend for every title that passes through.
            delay(140)
            onCategorySelectedState.value(categories[Math.floorMod(focusedIndex, categories.size)])
        }
    }

    val pillWidth = 212.dp
    val pillHeight = 64.dp
    val gap = 12.dp
    val leftInset = 16.dp
    val pillsTop = 24.dp
    val density = LocalDensity.current
    val spacingPx = with(density) { (pillWidth + gap).toPx() }
    val leftInsetPx = with(density) { leftInset.toPx() }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .graphicsLayer { this.alpha = alpha() }
            .onPreviewKeyEvent { event ->
                if (!isCategoriesFocused || event.type != KeyEventType.KeyDown) {
                    false
                } else {
                    when (event.nativeKeyEvent.keyCode) {
                        KeyEvent.KEYCODE_DPAD_RIGHT -> {
                            if (keyPacer.accept(1)) focusedIndex++
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_LEFT -> {
                            if (keyPacer.accept(-1)) focusedIndex--
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                            if (event.nativeKeyEvent.repeatCount == 0) {
                                onCategoryClickState.value(categories[Math.floorMod(focusedIndex, categories.size)])
                            }
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_UP -> onDpadUpState.value()
                        KeyEvent.KEYCODE_DPAD_DOWN -> onDpadDownState.value()
                        else -> false
                    }
                }
            }
            .onFocusChanged { state ->
                val gainedFocus = state.hasFocus && !isCategoriesFocused
                isCategoriesFocused = state.hasFocus
                if (gainedFocus) onFocusedState.value()
            }
            .focusProperties {
                left = FocusRequester.Cancel
                right = FocusRequester.Cancel
            }
            .focusRequester(actualFocusRequester)
            .focusable()
            .semantics {
                contentDescription = "Explore categories"
                stateDescription = categories[Math.floorMod(focusedIndex, categories.size)]
            }
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = leftInset, end = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Explore categories",
                color = Color(0xFFBEC2CA),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 0.4.sp
            )
            Text(
                text = if (isCategoriesFocused) "${Math.floorMod(focusedIndex, categories.size) + 1} / ${categories.size}" else "${categories.size} genres",
                color = Color(0xFF9096A1),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }

        BoxWithConstraints(
            modifier = Modifier
                .offset(y = pillsTop)
                .fillMaxWidth()
                .height(pillHeight)
                .clipToBounds()
        ) {
            // Follow the animated viewport rather than the requested destination so
            // holding a D-pad key never removes pills that are still crossing the screen.
            val startIndex = animatedFloor - 1
            val visibleCount = ceil(maxWidth.value / (pillWidth + gap).value).toInt() + 2
            Row(
                modifier = Modifier
                    .wrapContentWidth(Alignment.Start, unbounded = true)
                    .graphicsLayer {
                        translationX = leftInsetPx + (startIndex - animIndex.value) * spacingPx
                    },
                horizontalArrangement = Arrangement.spacedBy(gap)
            ) {
                for (index in startIndex until startIndex + visibleCount) {
                    key(index) {
                        val category = categories[Math.floorMod(index, categories.size)]
                        CategoryChipItem(
                            title = category,
                            cardWidth = pillWidth,
                            height = pillHeight,
                            isExpanded = false,
                            isFocused = isCategoriesFocused && index == focusedIndex,
                            onClick = {
                                focusedIndex = index
                                actualFocusRequester.requestFocus()
                                onCategoryClickState.value(category)
                            }
                        )
                    }
                }
            }
        }

        // Home counter-translates this border while its content glides vertically.
        // Keep it outside the horizontal clipping viewport so it can stay on screen.
        Box(
            modifier = Modifier
                .offset(x = leftInset, y = pillsTop)
                .width(pillWidth)
                .height(pillHeight)
                .graphicsLayer {
                    this.alpha = if (isCategoriesFocused) 1f else 0f
                    translationY = verticalRingOffsetProvider()
                }
                .border(2.5.dp, Color.White, CategoryChipShape)
                .zIndex(2f)
        )
    }
}

private val CategoryChipShape = RoundedCornerShape(12.dp)
private val CategoryIconShape = RoundedCornerShape(10.dp)

private fun categoryCaption(title: String): String = when (title) {
    "Dramas" -> "Compelling stories"
    "Comedies" -> "Feel-good favourites"
    "Action" -> "High-stakes stories"
    "Romance" -> "Love & connection"
    "Anime" -> "Bold new worlds"
    "Kids & Family" -> "Watch together"
    "Sci-Fi" -> "Beyond our world"
    "Thrillers" -> "On the edge"
    "Documentaries" -> "Real stories"
    "Horror" -> "After dark"
    "Fantasy" -> "A little wonder"
    else -> "Find your next watch"
}

private fun categoryIcon(title: String): ImageVector = when (title) {
    "Dramas" -> Icons.Default.Theaters
    "Comedies" -> Icons.Default.TheaterComedy
    "Action" -> Icons.Default.Bolt
    "Romance" -> Icons.Default.Favorite
    "Anime" -> Icons.Default.Star
    "Kids & Family" -> Icons.Default.FamilyRestroom
    "Sci-Fi" -> Icons.Default.RocketLaunch
    "Thrillers" -> Icons.Default.Visibility
    "Documentaries" -> Icons.Default.Public
    "Horror" -> Icons.Default.NightlightRound
    else -> Icons.Default.AutoAwesome
}

@Suppress("UNUSED_PARAMETER")
@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
@Composable
fun CategoryChipItem(
    title: String,
    cardWidth: Dp,
    height: Dp,
    isExpanded: Boolean,
    isFocused: Boolean = false,
    moodColor: Color = Color.Transparent,
    moodColorProvider: (() -> Color)? = null,
    onClick: () -> Unit
) {
    val onClickState = rememberUpdatedState(onClick)
    val accent = remember(title) { getCategoryThemeColor(title) }
    val caption = remember(title) { categoryCaption(title) }
    val icon = remember(title) { categoryIcon(title) }
    val focusAmount = animateFloatAsState(
        targetValue = if (isFocused) 1f else 0f,
        animationSpec = tween(TvMotion.duration(180), easing = FastOutSlowInEasing),
        label = "categoryCardFocus"
    )
    val textMeasurer = rememberTextMeasurer()
    val typography = MaterialTheme.typography
    val titleStyle = remember(typography) {
        typography.bodyMedium.copy(
            fontSize = 14.sp,
            lineHeight = 17.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.sp
        )
    }
    val captionStyle = remember(typography) {
        typography.labelMedium.copy(
            fontSize = 11.sp,
            lineHeight = 14.sp,
            fontWeight = FontWeight.Normal,
            letterSpacing = 0.1.sp
        )
    }
    val badgeColor = remember(accent) { lerp(Color(0xFF11151C), accent, 0.16f) }
    Box(
        modifier = Modifier
            .width(cardWidth)
            .height(height)
            .clip(CategoryChipShape)
            .drawWithCache {
                val surface = Brush.verticalGradient(
                    listOf(lerp(Color(0xFF1A1E26), accent, 0.13f), getCategoryCardColor(title, false))
                )
                val radius = CornerRadius(12.dp.toPx())
                val stroke = Stroke(1.dp.toPx())
                val selectedSurface = getCategoryCardColor(title, true)
                onDrawBehind {
                    val progress = focusAmount.value
                    drawRoundRect(surface, cornerRadius = radius)
                    if (progress > 0f) drawRoundRect(selectedSurface, cornerRadius = radius, alpha = progress)
                    drawRoundRect(lerp(Color(0xFF414650), Color(0xFFF4F5F7), progress), cornerRadius = radius, style = stroke)
                }
            }
            // The rail owns keyboard focus; touch clicks must not create a second
            // independently navigable focus target inside it.
            .focusProperties { canFocus = false }
            .clickable(role = Role.Button, onClick = { onClickState.value() })
            .semantics(mergeDescendants = true) {
                contentDescription = "$title. $caption"
                selected = isFocused
            },
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(34.dp).background(badgeColor, CategoryIconShape), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(19.dp))
            }
            // Measure once per title/size. Colour changes only redraw the stored
            // glyphs; they never recompose Text or remeasure the horizontal rail.
            Box(
                Modifier.weight(1f).fillMaxHeight().drawWithCache {
                    val bounds = Constraints(maxWidth = size.width.toInt().coerceAtLeast(1))
                    val titleLayout = textMeasurer.measure(
                        AnnotatedString(title),
                        style = titleStyle,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        constraints = bounds
                    )
                    val captionLayout = textMeasurer.measure(
                        AnnotatedString(caption),
                        style = captionStyle,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        constraints = bounds
                    )
                    val gapPx = 3.dp.toPx()
                    val textTop = ((size.height - titleLayout.size.height - captionLayout.size.height - gapPx) * 0.5f).coerceAtLeast(0f)
                    onDrawBehind {
                        val progress = focusAmount.value
                        drawText(
                            titleLayout,
                            color = Color(0xFFF1F4F8),
                            topLeft = Offset(0f, textTop)
                        )
                        drawText(
                            captionLayout,
                            color = lerp(Color(0xFFADB5C3), Color(0xFFD0D7E2), progress),
                            topLeft = Offset(0f, textTop + titleLayout.size.height + gapPx)
                        )
                    }
                }
            )
        }
    }
}
