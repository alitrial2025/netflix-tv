package com.example.ui.components

import android.app.Activity
import android.view.KeyEvent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.MeasurePolicy
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.boundsInParent
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onPlaced
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.tv.material3.Surface
import androidx.tv.material3.ClickableSurfaceDefaults
import coil.compose.AsyncImage
import com.example.R
import com.example.model.Movie
import com.example.model.Profile
import com.example.ui.NetflixViewModel
import com.example.ui.screens.*
import com.example.ui.theme.NetflixBlack
import com.example.ui.theme.NetflixRed
import com.example.ui.theme.KidsAccent
import com.example.ui.util.TvMotion
import com.example.ui.util.TvKeyPacer
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

private fun FocusRequester.safeRequestFocus(): Boolean {
    return try {
        this.requestFocus()
        true
    } catch (_: Exception) {
        false
    }
}

// perf: hoisted enter/exit transitions for the dropdown AnimatedVisibility so
// they aren't rebuilt on every recomposition.
private val DropdownEnterTransition =
    fadeIn(animationSpec = tween(TvMotion.duration(220), easing = LinearOutSlowInEasing)) +
        scaleIn(initialScale = 0.96f, transformOrigin = TransformOrigin(0f, 0f), animationSpec = tween(TvMotion.duration(220), easing = LinearOutSlowInEasing))
private val DropdownExitTransition =
    fadeOut(animationSpec = tween(TvMotion.duration(120), easing = FastOutSlowInEasing)) +
        scaleOut(targetScale = 0.98f, animationSpec = tween(TvMotion.duration(120), easing = FastOutSlowInEasing))

@Composable
private fun NavigationFocusPill(
    horizontalOffset: State<Float>,
    width: State<Float>,
    alpha: State<Float>
) {
    Box(
        modifier = Modifier
            .offset { IntOffset(horizontalOffset.value.roundToInt(), 0) }
            .layout { measurable, constraints ->
                // Animate the footprint during measurement, without recomposing
                // the profile menu and every navigation tab on each frame.
                val widthPx = width.value.roundToInt()
                    .coerceIn(constraints.minWidth, constraints.maxWidth)
                val placeable = measurable.measure(
                    constraints.copy(minWidth = widthPx, maxWidth = widthPx)
                )
                layout(placeable.width, placeable.height) {
                    placeable.place(0, 0)
                }
            }
            .height(32.dp)
            .graphicsLayer { this.alpha = alpha.value }
            .shadow(
                elevation = 6.dp,
                shape = CircleShape,
                ambientColor = Color.LightGray,
                spotColor = Color.White
            )
            .background(Color.White, CircleShape)
    )
}

/**
 * perf: extracted the search-icon Surface so its local focus state
 * (`isSearchFocused`) does not invalidate the whole tabs Row.
 */
@androidx.compose.runtime.Composable
private fun SearchIcon(
    isSearchSelected: Boolean,
    isDropdownExpanded: Boolean,
    focusRequester: FocusRequester,
    leftFocusRequester: FocusRequester,
    rightFocusRequester: FocusRequester,
    onClick: () -> Unit,
    onFocused: () -> Unit,
    onUnfocused: () -> Unit,
    onPlaced: (androidx.compose.ui.geometry.Rect) -> Unit,
    onDpadUp: () -> Boolean,
    onDpadDown: () -> Boolean
) {
    var isSearchFocused by remember { mutableStateOf(false) }
    val onClickState = rememberUpdatedState(onClick)
    val onFocusedState = rememberUpdatedState(onFocused)
    val onUnfocusedState = rememberUpdatedState(onUnfocused)
    val onDpadUpState = rememberUpdatedState(onDpadUp)
    val onDpadDownState = rememberUpdatedState(onDpadDown)
    val onPlacedState = rememberUpdatedState(onPlaced)
    val leftRequesterState = rememberUpdatedState(leftFocusRequester)
    val rightRequesterState = rememberUpdatedState(rightFocusRequester)

    Surface(
        onClick = { onClickState.value() },
        modifier = Modifier
            .height(32.dp)
            .onPlaced { coords -> onPlacedState.value(coords.boundsInParent()) }
            .focusRequester(focusRequester)
            .focusProperties {
                left = if (isDropdownExpanded) FocusRequester.Cancel else leftRequesterState.value
                right = rightRequesterState.value
            }
            .onFocusChanged {
                isSearchFocused = it.isFocused
                if (it.isFocused) {
                    if (!isDropdownExpanded) {
                        onFocusedState.value()
                    }
                } else {
                    onUnfocusedState.value()
                }
            }
            .onPreviewKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyDown) {
                    when (keyEvent.nativeKeyEvent.keyCode) {
                        android.view.KeyEvent.KEYCODE_DPAD_DOWN -> onDpadDownState.value()
                        android.view.KeyEvent.KEYCODE_DPAD_UP -> onDpadUpState.value()
                        android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                            try { leftRequesterState.value.requestFocus(); true } catch (_: Exception) { false }
                        }
                        android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                            try { rightRequesterState.value.requestFocus(); true } catch (_: Exception) { false }
                        }
                        android.view.KeyEvent.KEYCODE_DPAD_CENTER, android.view.KeyEvent.KEYCODE_ENTER -> {
                            onClickState.value()
                            true
                        }
                        else -> false
                    }
                } else false
            },
        shape = ClickableSurfaceDefaults.shape(shape = CircleShape),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = Color.Transparent,
            focusedContainerColor = Color.Transparent
        ),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.04f)
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .padding(horizontal = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = if (isSearchFocused) Color.Black else Color.White,
                    modifier = Modifier.size(15.dp)
                )
                if (isSearchSelected && !isSearchFocused) {
                    Box(
                        modifier = Modifier
                            .padding(top = 2.dp)
                            .width(14.dp)
                            .height(2.5.dp)
                            .shadow(elevation = 3.dp, shape = RoundedCornerShape(1.5.dp), spotColor = NetflixRed, ambientColor = NetflixRed)
                            .background(NetflixRed, RoundedCornerShape(1.5.dp))
                    )
                }
            }
        }
    }
}

/**
 * perf: extracted tab Surface into its own composable. Per-tab focus state
 * (isTabFocused) is now scoped to the tab, so when the user D-pads between tabs
 * only the newly-focused and previously-focused tabs recompose — not the whole Row.
 */
@androidx.compose.runtime.Composable
private fun NavTab(
    tabName: String,
    isSelected: Boolean,
    isDropdownExpanded: Boolean,
    tabFocusRequester: FocusRequester,
    leftRequester: FocusRequester,
    rightRequester: FocusRequester,
    onClick: () -> Unit,
    onTabFocused: () -> Unit,
    onTabUnfocused: () -> Unit,
    onDpadUp: () -> Boolean,
    onDpadDown: () -> Boolean,
    onFocused: () -> Unit,
    onPlaced: (androidx.compose.ui.geometry.Rect) -> Unit
) {
    var isTabFocused by remember { mutableStateOf(false) }
    // perf: keep latest lambdas in rememberUpdatedState so the key event handler
    // below doesn't need to be re-allocated on every parent recomposition.
    val leftRequesterState = rememberUpdatedState(leftRequester)
    val rightRequesterState = rememberUpdatedState(rightRequester)
    val onClickState = rememberUpdatedState(onClick)
    val onDpadUpState = rememberUpdatedState(onDpadUp)
    val onDpadDownState = rememberUpdatedState(onDpadDown)
    val onPlacedState = rememberUpdatedState(onPlaced)

    Surface(
        onClick = { onClickState.value() },
        modifier = Modifier
            .height(32.dp)
            .onPlaced { coords -> onPlacedState.value(coords.boundsInParent()) }
            .focusRequester(tabFocusRequester)
            .focusProperties {
                left = if (isDropdownExpanded) FocusRequester.Cancel else leftRequesterState.value
                right = rightRequesterState.value
            }
            .onFocusChanged {
                isTabFocused = it.isFocused
                if (it.isFocused) {
                    if (!isDropdownExpanded) {
                        onTabFocused()
                        onFocused()
                    }
                } else {
                    onTabUnfocused()
                }
            }
            .onPreviewKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyDown) {
                    when (keyEvent.nativeKeyEvent.keyCode) {
                        android.view.KeyEvent.KEYCODE_DPAD_DOWN -> onDpadDownState.value()
                        android.view.KeyEvent.KEYCODE_DPAD_UP -> onDpadUpState.value()
                        android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                            try { leftRequesterState.value.requestFocus(); true } catch (_: Exception) { false }
                        }
                        android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                            val r = rightRequesterState.value
                            if (r != FocusRequester.Cancel) {
                                try { r.requestFocus(); true } catch (_: Exception) { false }
                            } else true
                        }
                        android.view.KeyEvent.KEYCODE_DPAD_CENTER, android.view.KeyEvent.KEYCODE_ENTER -> {
                            onClickState.value()
                            true
                        }
                        else -> false
                    }
                } else false
            },
        shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(16.dp)),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = Color.Transparent,
            focusedContainerColor = Color.Transparent
        ),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.04f)
    ) {
        Box(
            modifier = Modifier
                .height(32.dp)
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = tabName,
                    color = when {
                        isTabFocused -> Color.Black
                        isSelected -> Color.White
                        else -> Color(0xFFB3B3B3)
                    },
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.sp
                )

                if (isSelected && !isTabFocused) {
                    Box(
                        modifier = Modifier
                            .padding(top = 2.dp)
                            .width(18.dp)
                            .height(2.5.dp)
                            .shadow(elevation = 3.dp, shape = RoundedCornerShape(1.5.dp), spotColor = NetflixRed, ambientColor = NetflixRed)
                            .background(NetflixRed, RoundedCornerShape(1.5.dp))
                    )
                }
            }
        }
    }
}

@Composable
fun ProfileAvatar(
    profile: Profile,
    size: Dp = 32.dp,
    modifier: Modifier = Modifier
) {
    val fallbackUrl = if (profile.isKid) {
        ProfileIcons.KIDS_ANIMATION.firstOrNull() ?: ProfileIcons.CLASSICS.getOrNull(2)
    } else {
        ProfileIcons.CLASSICS.firstOrNull()
    }
    val targetUrl = profile.avatarUrl?.takeIf { it.isNotBlank() } ?: fallbackUrl

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(6.dp))
            .background(profile.avatarColor),
        contentAlignment = Alignment.Center
    ) {
        if (!targetUrl.isNullOrBlank()) {
            val context = LocalContext.current
            val request = remember(context, targetUrl) { profileAvatarRequest(context, targetUrl) }
            AsyncImage(
                model = request,
                contentDescription = "${profile.name} Avatar",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Text(
                text = profile.name.take(1).uppercase(),
                color = Color.White,
                fontSize = (size.value * 0.42f).sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun TopNavBar(
    selectedTab: String,
    onTabSelected: (String) -> Unit,
    onTabActivated: (String) -> Unit = onTabSelected,
    profileFocusRequester: FocusRequester,
    searchIconFocusRequester: FocusRequester,
    homeTabFocusRequester: FocusRequester,
    seriesTabFocusRequester: FocusRequester,
    filmsTabFocusRequester: FocusRequester,
    myNetflixTabFocusRequester: FocusRequester,
    modifier: Modifier = Modifier,
    onFocused: () -> Unit = {},
    selectedProfile: Profile? = null,
    profiles: List<Profile> = emptyList(),
    onProfileSelected: (Profile) -> Unit = {},
    onManageProfiles: () -> Unit = {},
    onDpadUp: () -> Boolean = { false },
    onDpadDown: () -> Boolean = { false }
) {
    val context = LocalContext.current
    val onTabActivatedState = rememberUpdatedState(onTabActivated)
    val navTabsList = remember { listOf("Home", "Series", "Films", "My Netflix") }
    // perf: removed dead `isTrackFocused` state (was written but never read).
    var showHelpDialog by remember { mutableStateOf(false) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left: Profile Dropdown (floating overlay that never pushes screen content or nav tabs)
        var isDropdownExpanded by remember { mutableStateOf(false) }
        var dropdownOpenTimestamp by remember { mutableLongStateOf(0L) }
        val effectiveProfiles = remember(profiles) {
            if (profiles.isNotEmpty()) profiles
            else listOf(
                Profile(id = "1", name = "Home", avatarColor = NetflixRed),
                Profile(id = "2", name = "Kids", avatarColor = Color(0xFFE50914), isKid = true)
            )
        }
        val currentProfile = selectedProfile ?: effectiveProfiles.firstOrNull() ?: Profile(id = "temp", name = "Profile", avatarColor = NetflixRed)

        val dropdownItems = remember(effectiveProfiles) {
            effectiveProfiles.map { "profile_${it.id}" } + listOf("help", "exit")
        }

        val itemFocusRequesters = remember(dropdownItems) {
            dropdownItems.associateWith { FocusRequester() }
        }

        val itemBounds = remember { mutableStateMapOf<String, Rect>() }
        val dropdownKeyPacer = remember { TvKeyPacer() }
        var currentlyFocusedItem by remember { mutableStateOf<String?>(null) }
        var wasDropdownExpanded by remember { mutableStateOf(false) }

        fun getDropdownFocusRequester(id: String): FocusRequester =
            itemFocusRequesters[id] ?: profileFocusRequester

        fun navigateDropdown(currentId: String, direction: Int) {
            if (!dropdownKeyPacer.accept(direction)) return
            val currentIndex = dropdownItems.indexOf(currentId)
            val index = if (currentIndex == -1) 0 else currentIndex
            val nextIndex = (index + direction).coerceIn(0, dropdownItems.size - 1)
            val nextId = dropdownItems[nextIndex]
            currentlyFocusedItem = nextId
            getDropdownFocusRequester(nextId).safeRequestFocus()
        }

        // BackHandler: Remote Back / Escape closes the dropdown cleanly
        val closeDropdownBack: () -> Unit = remember {
            {
                isDropdownExpanded = false
                profileFocusRequester.safeRequestFocus()
            }
        }
        BackHandler(enabled = isDropdownExpanded) {
            closeDropdownBack()
        }

        // Automatically transfer focus into appropriate dropdown item when expanded
        LaunchedEffect(isDropdownExpanded) {
            if (isDropdownExpanded) {
                wasDropdownExpanded = true
                val activeItemId = "profile_${currentProfile.id}"
                val initialItem = if (dropdownItems.contains(activeItemId)) activeItemId else dropdownItems.firstOrNull() ?: "help"
                currentlyFocusedItem = initialItem
                repeat(2) {
                    withFrameNanos { }
                    if (runCatching { getDropdownFocusRequester(initialItem).requestFocus() }.isSuccess) return@LaunchedEffect
                }
            } else if (wasDropdownExpanded) {
                profileFocusRequester.safeRequestFocus()
            }
        }

        Layout(
            content = {
                // Child 0: Trigger button — always composed, defines fixed footprint in the TopNavBar Row
                Surface(
                    onClick = {
                        dropdownOpenTimestamp = System.currentTimeMillis()
                        isDropdownExpanded = true
                    },
                    modifier = Modifier
                        .height(32.dp)
                        .focusRequester(profileFocusRequester)
                        .focusProperties {
                            right = if (isDropdownExpanded) FocusRequester.Cancel else searchIconFocusRequester
                        }
                        .onFocusChanged { state ->
                            if (state.isFocused && !isDropdownExpanded) {
                                onFocused()
                            }
                        }
                        .onPreviewKeyEvent { keyEvent ->
                            if (keyEvent.type == KeyEventType.KeyDown) {
                                when (keyEvent.nativeKeyEvent.keyCode) {
                                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                                        onDpadDown()
                                    }
                                    KeyEvent.KEYCODE_DPAD_UP -> {
                                        onDpadUp()
                                    }
                                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                                        searchIconFocusRequester.safeRequestFocus()
                                        true
                                    }
                                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                                        dropdownOpenTimestamp = System.currentTimeMillis()
                                        isDropdownExpanded = true
                                        true
                                    }
                                    else -> false
                                }
                            } else false
                        }
                        .graphicsLayer {
                            // Hide trigger when dropdown is expanded so it doesn't double-render beneath overlay
                            alpha = if (isDropdownExpanded) 0f else 1f
                        },
                    shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(8.dp)),
                    colors = ClickableSurfaceDefaults.colors(
                        containerColor = Color.Transparent,
                        focusedContainerColor = Color(0xFF333333)
                    ),
                    scale = ClickableSurfaceDefaults.scale(focusedScale = 1.05f)
                ) {
                    // Clean avatar + profile name + dropdown icon
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ProfileAvatar(
                            profile = currentProfile,
                            size = 24.dp
                        )

                        Text(
                            text = currentProfile.name,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1
                        )

                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Select Profile",
                            tint = Color.White.copy(alpha = 0.8f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Child 1: Dropdown overlay — floating card that matches the modern Netflix TV UI
                AnimatedVisibility(
                    visible = isDropdownExpanded,
                    enter = DropdownEnterTransition,
                    exit = DropdownExitTransition
                ) {
                    val targetBounds by remember {
                        derivedStateOf { itemBounds[currentlyFocusedItem] }
                    }
                    val animatedY = remember { Animatable(0f) }
                    val animatedHeight = remember { Animatable(0f) }
                    var highlightReady by remember { mutableStateOf(false) }
                    LaunchedEffect(isDropdownExpanded, targetBounds) {
                        val bounds = targetBounds ?: return@LaunchedEffect
                        if (!isDropdownExpanded) return@LaunchedEffect
                        if (!highlightReady) {
                            // First focus starts at the measured item; it never grows
                            // from a zero-height pill in the top corner of the menu.
                            animatedY.snapTo(bounds.top)
                            animatedHeight.snapTo(bounds.height)
                            highlightReady = true
                        } else {
                            launch { animatedY.animateTo(bounds.top, spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = TvMotion.stiffness(600f))) }
                            launch { animatedHeight.animateTo(bounds.height, tween(TvMotion.duration(180))) }
                        }
                    }
                    val animatedAlpha = animateFloatAsState(
                        targetValue = if (highlightReady && currentlyFocusedItem != null && targetBounds != null) 1f else 0f,
                        animationSpec = tween(durationMillis = TvMotion.duration(150), easing = FastOutSlowInEasing),
                        label = "dropdownSlidingAlpha"
                    )

                    Box(
                        modifier = Modifier
                            .width(260.dp)
                            .focusProperties {
                                left = FocusRequester.Cancel
                                right = FocusRequester.Cancel
                            }
                            .shadow(elevation = 24.dp, shape = RoundedCornerShape(20.dp), ambientColor = Color.Black, spotColor = Color.Black)
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF222222))
                            .border(1.dp, Color(0xFF2B2B2B), RoundedCornerShape(20.dp))
                            .padding(10.dp)
                            .drawWithCache {
                                val radius = CornerRadius(12.dp.toPx())
                                onDrawBehind {
                                    val pillHeight = animatedHeight.value
                                    val pillAlpha = animatedAlpha.value
                                    if (pillHeight > 0f && pillAlpha > 0f) {
                                        // Only the highlight redraws as it travels. The menu
                                        // and its measured profile rows stay unchanged.
                                        drawRoundRect(
                                            color = Color.White,
                                            topLeft = Offset(0f, animatedY.value),
                                            size = Size(size.width, pillHeight),
                                            cornerRadius = radius,
                                            alpha = pillAlpha
                                        )
                                    }
                                }
                            }
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // 1. Available Profiles List
                            effectiveProfiles.forEach { prof ->
                                val itemId = "profile_${prof.id}"
                                val isFocused = (currentlyFocusedItem == itemId)
                                val isCurrentActive = (prof.id == currentProfile.id)
                                val req = getDropdownFocusRequester(itemId)

                                Surface(
                                    onClick = {
                                        if (System.currentTimeMillis() - dropdownOpenTimestamp > 300L) {
                                            isDropdownExpanded = false
                                            if (isCurrentActive) {
                                                onManageProfiles()
                                            } else {
                                                onProfileSelected(prof)
                                            }
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .onPlaced { coords -> itemBounds[itemId] = coords.boundsInParent() }
                                        .focusRequester(req)
                                        .focusProperties {
                                            left = FocusRequester.Cancel
                                            right = FocusRequester.Cancel
                                        }
                                        .onFocusChanged { if (it.isFocused) currentlyFocusedItem = itemId }
                                        .onPreviewKeyEvent { keyEvent ->
                                            val isDown = keyEvent.type == KeyEventType.KeyDown
                                            val isUp = keyEvent.type == KeyEventType.KeyUp
                                            val code = keyEvent.nativeKeyEvent.keyCode
                                            when {
                                                (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) && isUp -> {
                                                    if (System.currentTimeMillis() - dropdownOpenTimestamp > 300L) {
                                                        isDropdownExpanded = false
                                                        if (isCurrentActive) {
                                                            onManageProfiles()
                                                        } else {
                                                            onProfileSelected(prof)
                                                        }
                                                    }
                                                    true
                                                }
                                                (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) && isDown -> true
                                                isDown -> when (code) {
                                                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                                                        navigateDropdown(itemId, 1)
                                                        true
                                                    }
                                                    KeyEvent.KEYCODE_DPAD_UP -> {
                                                        navigateDropdown(itemId, -1)
                                                        true
                                                    }
                                                    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> true
                                                    KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> {
                                                        isDropdownExpanded = false
                                                        profileFocusRequester.safeRequestFocus()
                                                        true
                                                    }
                                                    else -> false
                                                }
                                                else -> false
                                            }
                                        },
                                    shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(12.dp)),
                                    colors = ClickableSurfaceDefaults.colors(
                                        containerColor = Color.Transparent,
                                        focusedContainerColor = Color.Transparent
                                    ),
                                    scale = ClickableSurfaceDefaults.scale(focusedScale = 1.0f)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 7.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        ProfileAvatar(
                                            profile = prof,
                                            size = 34.dp
                                        )

                                        Column(
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Text(
                                                text = prof.name.ifBlank { if (prof.isKid) "Kids" else "Home" },
                                                color = if (isFocused) Color(0xFF111111) else Color.White,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            if (isCurrentActive) {
                                                Text(
                                                    text = "Switch Profiles",
                                                    color = if (isFocused) Color(0xFF555555) else Color(0xFF9E9E9E),
                                                    fontSize = 11.5.sp,
                                                    fontWeight = FontWeight.Normal
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // 2. Get Help
                            val isHelpFocused = (currentlyFocusedItem == "help")
                            val helpReq = getDropdownFocusRequester("help")
                            Surface(
                                onClick = {
                                    if (System.currentTimeMillis() - dropdownOpenTimestamp > 300L) {
                                        isDropdownExpanded = false
                                        showHelpDialog = true
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onPlaced { coords -> itemBounds["help"] = coords.boundsInParent() }
                                    .focusRequester(helpReq)
                                    .focusProperties {
                                        left = FocusRequester.Cancel
                                        right = FocusRequester.Cancel
                                    }
                                    .onFocusChanged { if (it.isFocused) currentlyFocusedItem = "help" }
                                    .onPreviewKeyEvent { keyEvent ->
                                        val isDown = keyEvent.type == KeyEventType.KeyDown
                                        val isUp = keyEvent.type == KeyEventType.KeyUp
                                        val code = keyEvent.nativeKeyEvent.keyCode
                                        when {
                                            (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) && isUp -> {
                                                if (System.currentTimeMillis() - dropdownOpenTimestamp > 300L) {
                                                    isDropdownExpanded = false
                                                    showHelpDialog = true
                                                }
                                                true
                                            }
                                            (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) && isDown -> true
                                            isDown -> when (code) {
                                                KeyEvent.KEYCODE_DPAD_UP -> {
                                                    navigateDropdown("help", -1)
                                                    true
                                                }
                                                KeyEvent.KEYCODE_DPAD_DOWN -> {
                                                    navigateDropdown("help", 1)
                                                    true
                                                }
                                                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> true
                                                KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> {
                                                    isDropdownExpanded = false
                                                    profileFocusRequester.safeRequestFocus()
                                                    true
                                                }
                                                else -> false
                                            }
                                            else -> false
                                        }
                                    },
                                shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(12.dp)),
                                colors = ClickableSurfaceDefaults.colors(
                                    containerColor = Color.Transparent,
                                    focusedContainerColor = Color.Transparent
                                ),
                                scale = ClickableSurfaceDefaults.scale(focusedScale = 1.0f)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.HelpOutline,
                                        contentDescription = "Get Help",
                                        tint = if (isHelpFocused) Color(0xFF111111) else Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )

                                    Text(
                                        text = "Get Help",
                                        color = if (isHelpFocused) Color(0xFF111111) else Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            // 3. Exit Netflix (Prominent rounded white pill card at bottom)
                            val isExitFocused = (currentlyFocusedItem == "exit")
                            val exitReq = getDropdownFocusRequester("exit")
                            Surface(
                                onClick = {
                                    if (System.currentTimeMillis() - dropdownOpenTimestamp > 300L) {
                                        isDropdownExpanded = false
                                        (context as? Activity)?.finishAffinity()
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onPlaced { coords -> itemBounds["exit"] = coords.boundsInParent() }
                                    .focusRequester(exitReq)
                                    .focusProperties {
                                        left = FocusRequester.Cancel
                                        right = FocusRequester.Cancel
                                        down = FocusRequester.Cancel
                                    }
                                    .onFocusChanged { if (it.isFocused) currentlyFocusedItem = "exit" }
                                    .onPreviewKeyEvent { keyEvent ->
                                        val isDown = keyEvent.type == KeyEventType.KeyDown
                                        val isUp = keyEvent.type == KeyEventType.KeyUp
                                        val code = keyEvent.nativeKeyEvent.keyCode
                                        when {
                                            (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) && isUp -> {
                                                if (System.currentTimeMillis() - dropdownOpenTimestamp > 300L) {
                                                    isDropdownExpanded = false
                                                    (context as? Activity)?.finishAffinity()
                                                }
                                                true
                                            }
                                            (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) && isDown -> true
                                            isDown -> when (code) {
                                                KeyEvent.KEYCODE_DPAD_UP -> {
                                                    navigateDropdown("exit", -1)
                                                    true
                                                }
                                                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> true
                                                KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> {
                                                    isDropdownExpanded = false
                                                    profileFocusRequester.safeRequestFocus()
                                                    true
                                                }
                                                else -> false
                                            }
                                            else -> false
                                        }
                                    },
                                shape = ClickableSurfaceDefaults.shape(shape = RoundedCornerShape(12.dp)),
                                colors = ClickableSurfaceDefaults.colors(
                                    containerColor = if (isExitFocused) Color.Transparent else Color(0xFFF2F2F2),
                                    focusedContainerColor = Color.Transparent
                                ),
                                scale = ClickableSurfaceDefaults.scale(focusedScale = 1.0f)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                                        contentDescription = "Exit Netflix",
                                        tint = Color(0xFF111111),
                                        modifier = Modifier.size(22.dp)
                                    )

                                    Text(
                                        text = "Exit Netflix",
                                        color = Color(0xFF111111),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            },
            measurePolicy = MeasurePolicy { measurables, constraints ->
                // Measure trigger (Child 0)
                val triggerPlaceable = measurables[0].measure(constraints)

                // Measure dropdown (Child 1) with unconstrained overlay bounds so it takes full width/height
                val dropdownPlaceable = if (measurables.size > 1) {
                    measurables[1].measure(
                        constraints.copy(
                            minWidth = 0,
                            minHeight = 0
                        )
                    )
                } else null

                // CRITICAL: Always report ONLY the trigger footprint to the parent Row!
                // This prevents the parent Row from expanding and pushing the navigation tabs to the right.
                val reportedWidth = triggerPlaceable.width
                val reportedHeight = 32.dp.roundToPx()

                layout(reportedWidth, reportedHeight) {
                    // Place trigger
                    triggerPlaceable.place(0, 0)

                    // Place dropdown overlay floating on top
                    dropdownPlaceable?.place(0, 0)
                }
            },
            modifier = Modifier.zIndex(200f)
        )

        // Center: High-performance TV Navigation Tabs with instant zero-latency focus
        val tabBounds = remember { mutableMapOf<String, androidx.compose.ui.geometry.Rect>() }
        var currentlyFocusedTab by remember { mutableStateOf<String?>(null) }

        // perf: keep latest onTabSelected callback in a State so the LaunchedEffect
        // key can be just the tab name (no closure recreation on parent re-render).
        val onTabSelectedState = rememberUpdatedState(onTabSelected)
        // The cursor changes immediately; Home debounces the expensive page change.
        LaunchedEffect(currentlyFocusedTab) {
            val tab = currentlyFocusedTab ?: return@LaunchedEffect
            onTabSelectedState.value(tab)
        }

        // perf: stable derivedStateOf so the rest of the tab bar doesn't recompose
        // every time `currentlyFocusedTab` changes before the bounds map is updated.
        val targetBounds by remember {
            derivedStateOf { tabBounds[currentlyFocusedTab] }
        }

        val animatedX = animateFloatAsState(
            targetValue = targetBounds?.left ?: 0f,
            animationSpec = tween(durationMillis = TvMotion.duration(200), easing = FastOutSlowInEasing),
            label = "tabX"
        )
        val animatedWidth = animateFloatAsState(
            targetValue = targetBounds?.width ?: 0f,
            animationSpec = tween(durationMillis = TvMotion.duration(200), easing = FastOutSlowInEasing),
            label = "tabWidth"
        )
        val animatedAlpha = animateFloatAsState(
            targetValue = if (currentlyFocusedTab != null && targetBounds != null) 1f else 0f,
            animationSpec = tween(durationMillis = TvMotion.duration(200), easing = FastOutSlowInEasing),
            label = "tabAlpha"
        )

        // perf: removed dead `isTrackFocused` write in onFocusChanged.
        Box(
            modifier = Modifier
                .onFocusChanged { if (it.hasFocus) onFocused() }
        ) {
            NavigationFocusPill(
                horizontalOffset = animatedX,
                width = animatedWidth,
                alpha = animatedAlpha
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
            // Search Icon (Index 0)
            // perf: extracted to its own composable so its focus-state change
            // (isSearchFocused) doesn't recompose the whole tab Row.
            val onSearchFocused = remember { { currentlyFocusedTab = "Search" } }
            val onSearchUnfocused = remember { { if (currentlyFocusedTab == "Search") currentlyFocusedTab = null } }
            val onSearchClick = remember { { onTabActivatedState.value("Search") } }
            val onSearchPlaced = remember { { rect: androidx.compose.ui.geometry.Rect -> tabBounds["Search"] = rect } }
            SearchIcon(
                isSearchSelected = selectedTab == "Search",
                isDropdownExpanded = isDropdownExpanded,
                focusRequester = searchIconFocusRequester,
                leftFocusRequester = profileFocusRequester,
                rightFocusRequester = homeTabFocusRequester,
                onClick = onSearchClick,
                onFocused = onSearchFocused,
                onUnfocused = onSearchUnfocused,
                onPlaced = onSearchPlaced,
                onDpadUp = onDpadUp,
                onDpadDown = onDpadDown
            )

            // Tabs: Home, Series, Films, My Netflix
            // perf: extract each tab to a child composable so per-tab focus state
            // changes (e.g. D-pad) only recompose that tab, not the whole Row.
            // perf: when() lookups moved out of the lambda body so they're hoisted.
            val onTabFocused: (String) -> Unit = remember(navTabsList) {
                { name -> currentlyFocusedTab = name }
            }
            val onTabUnfocused: (String) -> Unit = remember(navTabsList) {
                { name -> if (currentlyFocusedTab == name) currentlyFocusedTab = null }
            }
            val onTabPlaced: (String, androidx.compose.ui.geometry.Rect) -> Unit = remember(navTabsList) {
                { name, rect -> tabBounds[name] = rect }
            }
            navTabsList.forEach { tabName ->
                key(tabName) {
                    val (tabFocusRequester, leftRequester, rightRequester) = when (tabName) {
                        "Home" -> Triple(homeTabFocusRequester, searchIconFocusRequester, seriesTabFocusRequester)
                        "Series" -> Triple(seriesTabFocusRequester, homeTabFocusRequester, filmsTabFocusRequester)
                        "Films" -> Triple(filmsTabFocusRequester, seriesTabFocusRequester, myNetflixTabFocusRequester)
                        "My Netflix" -> Triple(myNetflixTabFocusRequester, filmsTabFocusRequester, FocusRequester.Cancel)
                        else -> Triple(homeTabFocusRequester, FocusRequester.Default, FocusRequester.Default)
                    }
                    NavTab(
                        tabName = tabName,
                        isSelected = selectedTab == tabName,
                        isDropdownExpanded = isDropdownExpanded,
                        tabFocusRequester = tabFocusRequester,
                        leftRequester = leftRequester,
                        rightRequester = rightRequester,
                        // perf: re-use the same lambda reference across recompositions
                        // by capturing the tabName once.
                        onClick = remember(tabName) { { onTabActivatedState.value(tabName) } },
                        onTabFocused = remember(tabName) { { onTabFocused(tabName) } },
                        onTabUnfocused = remember(tabName) { { onTabUnfocused(tabName) } },
                        onDpadUp = onDpadUp,
                        onDpadDown = onDpadDown,
                        onFocused = onFocused,
                        onPlaced = remember(tabName) { { rect: androidx.compose.ui.geometry.Rect -> onTabPlaced(tabName, rect) } }
                    )
                }
            }
        }
        }

        // Right: Red Netflix 'N' Logo or Kids Pill Badge
        if (currentProfile.isKid) {
            Box(
                modifier = Modifier
                    .background(Color.White, RoundedCornerShape(8.dp))
                    .border(1.dp, KidsAccent, RoundedCornerShape(8.dp))
                    .padding(horizontal = 6.dp, vertical = 1.5.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "kids",
                    color = NetflixRed,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
            }
        } else {
            Image(
                painter = painterResource(id = R.drawable.ic_netflix_n),
                contentDescription = "Netflix Logo",
                modifier = Modifier.height(29.dp).width(17.dp)
            )
        }
    }

    if (showHelpDialog) {
        val closeButtonFocusRequester = remember { FocusRequester() }
        LaunchedEffect(Unit) {
            kotlinx.coroutines.delay(80)
            closeButtonFocusRequester.safeRequestFocus()
        }

        Dialog(
            onDismissRequest = {
                showHelpDialog = false
                profileFocusRequester.safeRequestFocus()
            },
            properties = DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = true
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF141414))
                    .clickable {
                        showHelpDialog = false
                        profileFocusRequester.safeRequestFocus()
                    },
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    onClick = { /* Keep inside dialog */ },
                    modifier = Modifier
                        .width(460.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1E1E24))
                        .border(1.dp, Color(0xFF2B2B2B), RoundedCornerShape(16.dp))
                        .padding(24.dp),
                    shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(16.dp)),
                    colors = ClickableSurfaceDefaults.colors(
                        containerColor = Color(0xFF1E1E24),
                        focusedContainerColor = Color(0xFF1E1E24)
                    ),
                    scale = ClickableSurfaceDefaults.scale(focusedScale = 1.0f)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = null,
                            tint = NetflixRed,
                            modifier = Modifier.size(44.dp)
                        )

                        Text(
                            text = "Netflix Help Center",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF141416), RoundedCornerShape(10.dp))
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "• App Version: 2.4.0 (Android TV Edition)",
                                color = Color(0xFFE6E6E6),
                                fontSize = 13.5.sp
                            )
                            Text(
                                text = "• Quick Controls: Use D-pad to navigate, Select/OK to play.",
                                color = Color(0xFFE6E6E6),
                                fontSize = 13.5.sp
                            )
                            Text(
                                text = "• Back button returns to previous screen or exits dialogs.",
                                color = Color(0xFFE6E6E6),
                                fontSize = 13.5.sp
                            )
                            Text(
                                text = "• Manage profiles or adjust playback in the Profiles screen.",
                                color = Color(0xFFE6E6E6),
                                fontSize = 13.5.sp
                            )
                        }

                        var isCloseFocused by remember { mutableStateOf(false) }
                        Surface(
                            onClick = {
                                showHelpDialog = false
                                profileFocusRequester.safeRequestFocus()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .focusRequester(closeButtonFocusRequester)
                                .onFocusChanged { isCloseFocused = it.isFocused }
                                .onPreviewKeyEvent { keyEvent ->
                                    if (keyEvent.type == KeyEventType.KeyDown) {
                                        val code = keyEvent.nativeKeyEvent.keyCode
                                        if (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) {
                                            showHelpDialog = false
                                            profileFocusRequester.safeRequestFocus()
                                            true
                                        } else if (code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_ESCAPE) {
                                            showHelpDialog = false
                                            profileFocusRequester.safeRequestFocus()
                                            true
                                        } else false
                                    } else false
                                },
                            shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(8.dp)),
                            colors = ClickableSurfaceDefaults.colors(
                                containerColor = if (isCloseFocused) Color.White else NetflixRed,
                                focusedContainerColor = Color.White
                            ),
                            scale = ClickableSurfaceDefaults.scale(focusedScale = 1.02f)
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Close",
                                    color = if (isCloseFocused) Color.Black else Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
