package com.example.tv

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.tvprovider.media.tv.Channel
import androidx.tvprovider.media.tv.ChannelLogoUtils
import androidx.tvprovider.media.tv.PreviewProgram
import androidx.tvprovider.media.tv.TvContractCompat
import androidx.tvprovider.media.tv.WatchNextProgram
import com.example.R
import com.example.model.Movie
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Manages the dedicated "NETFLIX PRO" Android TV / Google TV Home Screen Channel
 * and the system-wide "Play Next" / Watch Next row via the official Android TV Provider API.
 */
object TvHomeChannelManager {
    private const val TAG = "TvHomeChannelManager"
    private const val CHANNEL_NAME = "NETFLIX PRO"
    private const val PREFS_NAME = "netflix_tv_channel_prefs"
    private const val KEY_CHANNEL_ID = "netflix_pro_channel_id"
    private const val MAX_WATCH_NEXT_PROGRAMS = 5

    private val lastUpdateTimestamps = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private fun isTvProviderAvailable(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
        return try {
            val providerInfo = context.packageManager.resolveContentProvider("android.media.tv", 0)
            providerInfo != null
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Finds or registers the dedicated "NETFLIX PRO" channel row on Android TV / Google TV launcher.
     */
    suspend fun getOrCreateNetflixProChannel(context: Context): Long? = withContext(Dispatchers.IO) {
        if (!isTvProviderAvailable(context)) {
            return@withContext null
        }

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedId = prefs.getLong(KEY_CHANNEL_ID, -1L)

        // Verify if saved channel exists in system TvProvider
        if (savedId != -1L) {
            try {
                val cursor = context.contentResolver.query(
                    TvContractCompat.buildChannelUri(savedId),
                    null,
                    null,
                    null,
                    null
                )
                cursor?.use {
                    if (it.moveToFirst()) {
                        return@withContext savedId
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Saved channel lookup failed: ${e.message}")
            }
        }

        // Query all channels by package
        try {
            val cursor = context.contentResolver.query(
                TvContractCompat.Channels.CONTENT_URI,
                arrayOf(TvContractCompat.Channels._ID, TvContractCompat.Channels.COLUMN_DISPLAY_NAME),
                "${TvContractCompat.Channels.COLUMN_PACKAGE_NAME} = ?",
                arrayOf(context.packageName),
                null
            )
            cursor?.use {
                while (it.moveToNext()) {
                    val id = it.getLong(0)
                    val name = it.getString(1)
                    if (name.equals(CHANNEL_NAME, ignoreCase = true)) {
                        prefs.edit().putLong(KEY_CHANNEL_ID, id).apply()
                        return@withContext id
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Existing channels query failed: ${e.message}")
        }

        // Create new dedicated "NETFLIX PRO" System Home Screen Channel
        try {
            val builder = Channel.Builder()
                .setType(TvContractCompat.Channels.TYPE_PREVIEW)
                .setDisplayName(CHANNEL_NAME)
                .setDescription("Trending Movies, Shows & Originals on Netflix Pro")
                .setAppLinkIntentUri(Uri.parse("netflixpro://home"))

            val channelUri = context.contentResolver.insert(
                TvContractCompat.Channels.CONTENT_URI,
                builder.build().toContentValues()
            )

            if (channelUri != null) {
                val channelId = ContentUris.parseId(channelUri)
                prefs.edit().putLong(KEY_CHANNEL_ID, channelId).apply()

                // Set channel brand icon / logo
                try {
                    val logoBitmap = getChannelLogoBitmap(context)
                    if (logoBitmap != null) {
                        ChannelLogoUtils.storeChannelLogo(context, channelId, logoBitmap)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Could not set channel logo: ${e.message}")
                }

                // Request channel to be browsable / visible by default on Android TV home screen
                try {
                    TvContractCompat.requestChannelBrowsable(context, channelId)
                } catch (e: Exception) {
                    Log.w(TAG, "Request browsable error: ${e.message}")
                }

                Log.d(TAG, "🎉 Successfully created '$CHANNEL_NAME' Android TV System Channel (ID: $channelId)")
                return@withContext channelId
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create '$CHANNEL_NAME' system channel: ${e.message}")
        }
        null
    }

    /**
     * Publishes trending/recommended movies into the "NETFLIX PRO" Android TV Home Screen channel.
     */
    suspend fun publishChannelPrograms(context: Context, movies: List<Movie>) = withContext(Dispatchers.IO) {
        if (!isTvProviderAvailable(context) || movies.isEmpty()) return@withContext

        val channelId = getOrCreateNetflixProChannel(context) ?: return@withContext

        try {
            // Delete old programs in channel
            context.contentResolver.delete(
                TvContractCompat.buildPreviewProgramsUriForChannel(channelId),
                null,
                null
            )

            // Insert top 15-20 movies/shows into the home screen channel
            movies.take(20).forEachIndexed { index, movie ->
                try {
                    val isSeries = movie.type.equals("Series", ignoreCase = true) || movie.duration.contains("Season", ignoreCase = true)
                    val programType = if (isSeries) TvContractCompat.PreviewPrograms.TYPE_TV_SERIES else TvContractCompat.PreviewPrograms.TYPE_MOVIE

                    val posterUrl = movie.backdropUrl.ifBlank { movie.posterUrl }

                    val program = PreviewProgram.Builder()
                        .setChannelId(channelId)
                        .setTitle(movie.title)
                        .setDescription(movie.description)
                        .setPosterArtUri(if (posterUrl.isNotBlank()) Uri.parse(posterUrl) else null)
                        .setPosterArtAspectRatio(TvContractCompat.PreviewProgramColumns.ASPECT_RATIO_16_9)
                        .setType(programType)
                        .setIntentUri(Uri.parse("netflixpro://movie/${movie.id}"))
                        .setWeight(20 - index)
                        .setLive(false)
                        .build()

                    context.contentResolver.insert(
                        TvContractCompat.PreviewPrograms.CONTENT_URI,
                        program.toContentValues()
                    )
                } catch (e: Exception) {
                    Log.w(TAG, "Failed inserting program ${movie.title}: ${e.message}")
                }
            }
            Log.d(TAG, "🍿 Published ${movies.size.coerceAtMost(20)} programs to '$CHANNEL_NAME' TV Home Channel")
        } catch (e: Exception) {
            Log.e(TAG, "Error publishing programs to TV channel: ${e.message}")
        }
    }

    /**
     * Updates or inserts a movie into Android TV's system-wide "Play Next" row (WatchNextProgram).
     *
     * @param positionMs Current saved playback position in milliseconds.
     * @param durationMs Total duration in milliseconds.
     * @param isNextEpisode If true, marks as WATCH_NEXT_TYPE_NEXT (next episode queued).
     */
    suspend fun updateWatchNextProgram(
        context: Context,
        movie: Movie,
        positionMs: Long,
        durationMs: Long,
        season: Int = 1,
        episode: Int = 1,
        isNextEpisode: Boolean = false,
        forceUpdate: Boolean = false
    ) = withContext(Dispatchers.IO) {
        if (!isTvProviderAvailable(context)) return@withContext

        // Throttle updates: avoid spamming TvProvider every 2 seconds unless forced or state changed
        val now = System.currentTimeMillis()
        val lastUpdate = lastUpdateTimestamps[movie.id] ?: 0L
        if (!forceUpdate && !isNextEpisode && (now - lastUpdate < 15_000L)) {
            return@withContext
        }
        lastUpdateTimestamps[movie.id] = now

        try {
            val isSeries = movie.type.equals("Series", ignoreCase = true) || movie.duration.contains("Season", ignoreCase = true)
            val watchNextType = if (isNextEpisode) {
                TvContractCompat.WatchNextPrograms.WATCH_NEXT_TYPE_NEXT
            } else {
                TvContractCompat.WatchNextPrograms.WATCH_NEXT_TYPE_CONTINUE
            }

            val titleText = if (isSeries && season > 0 && episode > 0) {
                "${movie.title} • S${season}:E${episode}"
            } else {
                movie.title
            }

            val posterUrl = movie.backdropUrl.ifBlank { movie.posterUrl }
            val deepLink = "netflixpro://play/${movie.id}?season=$season&episode=$episode&pos=$positionMs"

            val program = WatchNextProgram.Builder()
                .setType(if (isSeries) TvContractCompat.WatchNextPrograms.TYPE_TV_SERIES else TvContractCompat.WatchNextPrograms.TYPE_MOVIE)
                .setWatchNextType(watchNextType)
                .setTitle(titleText)
                .setDescription(movie.description)
                .setPosterArtUri(if (posterUrl.isNotBlank()) Uri.parse(posterUrl) else null)
                .setPosterArtAspectRatio(TvContractCompat.PreviewProgramColumns.ASPECT_RATIO_16_9)
                .setLastPlaybackPositionMillis(positionMs.toInt())
                .setDurationMillis(durationMs.coerceAtLeast(1L).toInt())
                .setLastEngagementTimeUtcMillis(now)
                .setIntentUri(Uri.parse(deepLink))
                .setContentId(movie.id)
                .setInternalProviderId(movie.id)
                .build()

            // Find all existing entries for this movie in Watch Next to update or clean duplicates
            val existingIds = mutableListOf<Long>()
            try {
                val cursor = context.contentResolver.query(
                    TvContractCompat.WatchNextPrograms.CONTENT_URI,
                    arrayOf(
                        TvContractCompat.WatchNextPrograms._ID,
                        TvContractCompat.WatchNextPrograms.COLUMN_CONTENT_ID,
                        TvContractCompat.WatchNextPrograms.COLUMN_INTERNAL_PROVIDER_ID
                    ),
                    null,
                    null,
                    null
                )
                cursor?.use { c ->
                    val idCol = c.getColumnIndex(TvContractCompat.WatchNextPrograms._ID)
                    val contentIdCol = c.getColumnIndex(TvContractCompat.WatchNextPrograms.COLUMN_CONTENT_ID)
                    val internalIdCol = c.getColumnIndex(TvContractCompat.WatchNextPrograms.COLUMN_INTERNAL_PROVIDER_ID)

                    while (c.moveToNext()) {
                        val rowId = if (idCol >= 0) c.getLong(idCol) else -1L
                        val cId = if (contentIdCol >= 0) c.getString(contentIdCol) else null
                        val intId = if (internalIdCol >= 0) c.getString(internalIdCol) else null

                        if (cId == movie.id || intId == movie.id) {
                            if (rowId > 0L) existingIds.add(rowId)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed querying existing WatchNext cards: ${e.message}")
            }

            if (existingIds.isNotEmpty()) {
                // Update the primary existing card in-place
                val primaryId = existingIds.first()
                val updateUri = TvContractCompat.buildWatchNextProgramUri(primaryId)
                context.contentResolver.update(updateUri, program.toContentValues(), null, null)

                // Delete any duplicate records for this same movie
                for (i in 1 until existingIds.size) {
                    try {
                        context.contentResolver.delete(TvContractCompat.buildWatchNextProgramUri(existingIds[i]), null, null)
                    } catch (_: Exception) {}
                }
                Log.d(TAG, "▶ Updated existing Watch Next Program in-place: $titleText (ID: $primaryId)")
            } else {
                // Insert fresh card
                context.contentResolver.insert(
                    TvContractCompat.WatchNextPrograms.CONTENT_URI,
                    program.toContentValues()
                )
                Log.d(TAG, "▶ Inserted new Watch Next Program: $titleText")
            }

            // Prune excess Play Next cards so the user never gets unlimited cards on TV
            pruneWatchNextPrograms(context, MAX_WATCH_NEXT_PROGRAMS)

        } catch (e: Exception) {
            Log.e(TAG, "Error updating WatchNextProgram: ${e.message}")
        }
    }

    /**
     * Enforces strict limit on the TV Play Next row by removing older/excess cards.
     */
    private fun pruneWatchNextPrograms(context: Context, maxItems: Int) {
        try {
            val allCards = mutableListOf<Pair<Long, Long>>() // (id, lastEngagementTime)
            val cursor = context.contentResolver.query(
                TvContractCompat.WatchNextPrograms.CONTENT_URI,
                arrayOf(
                    TvContractCompat.WatchNextPrograms._ID,
                    TvContractCompat.WatchNextPrograms.COLUMN_LAST_ENGAGEMENT_TIME_UTC_MILLIS
                ),
                null,
                null,
                null
            )
            cursor?.use { c ->
                val idCol = c.getColumnIndex(TvContractCompat.WatchNextPrograms._ID)
                val timeCol = c.getColumnIndex(TvContractCompat.WatchNextPrograms.COLUMN_LAST_ENGAGEMENT_TIME_UTC_MILLIS)

                while (c.moveToNext()) {
                    val rowId = if (idCol >= 0) c.getLong(idCol) else -1L
                    val time = if (timeCol >= 0) c.getLong(timeCol) else 0L
                    if (rowId > 0L) {
                        allCards.add(rowId to time)
                    }
                }
            }

            if (allCards.size > maxItems) {
                // Sort descending by engagement time; cards after maxItems are the oldest to prune
                allCards.sortByDescending { it.second }
                val cardsToDelete = allCards.drop(maxItems)
                for ((excessId, _) in cardsToDelete) {
                    try {
                        context.contentResolver.delete(TvContractCompat.buildWatchNextProgramUri(excessId), null, null)
                        Log.d(TAG, "✂ Pruned excess Watch Next card (ID: $excessId)")
                    } catch (_: Exception) {}
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error pruning Watch Next cards: ${e.message}")
        }
    }

    /**
     * Removes an entry from the Android TV "Play Next" row.
     */
    suspend fun removeWatchNextProgram(context: Context, movieId: String) = withContext(Dispatchers.IO) {
        if (!isTvProviderAvailable(context)) return@withContext
        lastUpdateTimestamps.remove(movieId)
        try {
            // Find and delete matching programs by URI
            val idsToDelete = mutableListOf<Long>()
            val cursor = context.contentResolver.query(
                TvContractCompat.WatchNextPrograms.CONTENT_URI,
                arrayOf(
                    TvContractCompat.WatchNextPrograms._ID,
                    TvContractCompat.WatchNextPrograms.COLUMN_CONTENT_ID,
                    TvContractCompat.WatchNextPrograms.COLUMN_INTERNAL_PROVIDER_ID
                ),
                null,
                null,
                null
            )
            cursor?.use { c ->
                val idCol = c.getColumnIndex(TvContractCompat.WatchNextPrograms._ID)
                val contentIdCol = c.getColumnIndex(TvContractCompat.WatchNextPrograms.COLUMN_CONTENT_ID)
                val internalIdCol = c.getColumnIndex(TvContractCompat.WatchNextPrograms.COLUMN_INTERNAL_PROVIDER_ID)

                while (c.moveToNext()) {
                    val rowId = if (idCol >= 0) c.getLong(idCol) else -1L
                    val cId = if (contentIdCol >= 0) c.getString(contentIdCol) else null
                    val intId = if (internalIdCol >= 0) c.getString(internalIdCol) else null

                    if (cId == movieId || intId == movieId) {
                        if (rowId > 0L) idsToDelete.add(rowId)
                    }
                }
            }

            for (id in idsToDelete) {
                context.contentResolver.delete(TvContractCompat.buildWatchNextProgramUri(id), null, null)
                Log.d(TAG, "🗑 Removed Watch Next card (ID: $id) for movieId: $movieId")
            }

            // Fallback direct delete
            try {
                context.contentResolver.delete(
                    TvContractCompat.WatchNextPrograms.CONTENT_URI,
                    "${TvContractCompat.WatchNextPrograms.COLUMN_CONTENT_ID} = ? OR ${TvContractCompat.WatchNextPrograms.COLUMN_INTERNAL_PROVIDER_ID} = ?",
                    arrayOf(movieId, movieId)
                )
            } catch (_: Exception) {}

        } catch (e: Exception) {
            Log.w(TAG, "Error removing WatchNextProgram: ${e.message}")
        }
    }

    private fun getChannelLogoBitmap(context: Context): Bitmap? {
        return try {
            val drawable = ContextCompat.getDrawable(context, R.drawable.ic_netflix_logo) ?: return null
            val bitmap = Bitmap.createBitmap(300, 100, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            bitmap
        } catch (e: Exception) {
            null
        }
    }
}
