package com.example.data

import com.example.BuildConfig
import com.example.api.TmdbClient
import com.example.api.TmdbItemDto
import com.example.model.Movie
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

class TmdbRepository {
    private val apiKey: String
        get() = try {
            BuildConfig.TMDB_API_KEY.ifEmpty { "8baba8ab6b8bbe247645bcae7df63d0d" }
        } catch (e: Exception) {
            "8baba8ab6b8bbe247645bcae7df63d0d"
        }

    companion object {
        private val logoCache = java.util.concurrent.ConcurrentHashMap<String, String>()
        fun getCachedLogo(itemId: String): String? = logoCache[itemId]
        fun putCachedLogo(itemId: String, url: String) { logoCache[itemId] = url }
    }

    fun getCachedLogo(itemId: String): String? = logoCache[itemId]

    private fun TmdbItemDto.toMovie(logoUrl: String? = null): Movie {
        val imageBase = "https://image.tmdb.org/t/p/"
        val backdrop = backdropPath?.let { 
            val cleanPath = if (it.startsWith("/")) it else "/$it"
            "${imageBase}original$cleanPath"
        } ?: posterPath?.let { 
            val cleanPath = if (it.startsWith("/")) it else "/$it"
            "${imageBase}w780$cleanPath"
        } ?: ""

        val poster = posterPath?.let { 
            val cleanPath = if (it.startsWith("/")) it else "/$it"
            "${imageBase}w780$cleanPath"
        } ?: backdropPath?.let { 
            val cleanPath = if (it.startsWith("/")) it else "/$it"
            "${imageBase}w780$cleanPath"
        } ?: ""

        val itemTitle = title ?: name ?: "Untitled"
        val releaseYear = releaseDate?.take(4) ?: firstAirDate?.take(4) ?: "2025"
        val isTv = mediaType == "tv" || name != null
        val isAnimation = genreIds.contains(16L)
        val isFamily = genreIds.contains(10751L)
        val isKidsTv = genreIds.contains(10762L)
        val isKidFriendlyGenre = isAnimation || isFamily || isKidsTv
        val itemType = if (isAnimation) "Animation" else if (isTv) "Series" else "Movie"
        
        val ageRating = when {
            isKidFriendlyGenre -> {
                when {
                    isKidsTv -> "TV-Y7"
                    isAnimation -> "PG"
                    isFamily -> "PG"
                    else -> "12"
                }
            }
            voteAverage != null && voteAverage >= 8.3 -> "18"
            voteAverage != null && voteAverage >= 7.2 -> "16"
            voteAverage != null && voteAverage >= 6.0 -> "13"
            else -> "13"
        }

        return Movie(
            id = id.toString(),
            title = itemTitle,
            description = overview?.ifBlank { "A thrilling title on Netflix Pro." } ?: "A thrilling title on Netflix Pro.",
            backdropUrl = backdrop,
            posterUrl = poster,
            rating = ageRating,
            year = releaseYear,
            type = itemType,
            duration = if (isTv) "Series" else "Feature",
            logoUrl = logoUrl ?: logoCache[id.toString()]
        )
    }

    suspend fun fetchLogoUrl(itemId: Long, isTv: Boolean): String? {
        val key = itemId.toString()
        logoCache[key]?.let { return it }
        return try {
            val response = if (isTv) {
                TmdbClient.instance.getTvImages(itemId, apiKey)
            } else {
                TmdbClient.instance.getMovieImages(itemId, apiKey)
            }
            val logo = response.logos.firstOrNull { it.iso == "en" } ?: response.logos.firstOrNull()
            logo?.filePath?.let {
                val cleanPath = if (it.startsWith("/")) it else "/$it"
                val url = "https://image.tmdb.org/t/p/w500$cleanPath"
                logoCache[key] = url
                url
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun mapToMovies(items: List<TmdbItemDto>): List<Movie> {
        return items.take(20).map { item ->
            item.toMovie(null)
        }.filter { it.backdropUrl.isNotBlank() || it.posterUrl.isNotBlank() }
    }

    suspend fun getTrending(fetchLogos: Boolean = false): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.getTrending(apiKey).results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getPopularMovies(fetchLogos: Boolean = false): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.getPopularMovies(apiKey).results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getPopularTvShows(fetchLogos: Boolean = false): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.getPopularTvShows(apiKey).results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getTopRatedMovies(fetchLogos: Boolean = false): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.getTopRatedMovies(apiKey).results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getNowPlayingMovies(fetchLogos: Boolean = false): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.getNowPlayingMovies(apiKey).results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getTopRatedTvShows(fetchLogos: Boolean = false): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.getTopRatedTvShows(apiKey).results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getKidsMovies(): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.discoverKidsMovies(apiKey).results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getKidsTvShows(): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.discoverKidsTv(apiKey).results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getActionMovies(): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.discoverMoviesAdvanced(apiKey, withGenres = "28,12", sortBy = "popularity.desc").results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getSciFiMovies(): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.discoverMoviesAdvanced(apiKey, withGenres = "878", sortBy = "popularity.desc").results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getCrimeThrillers(): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.discoverMoviesAdvanced(apiKey, withGenres = "80,53", sortBy = "popularity.desc").results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getAnime(): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.discoverTvAdvanced(apiKey, withGenres = "16", sortBy = "popularity.desc").results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getComedies(): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.discoverMoviesAdvanced(apiKey, withGenres = "35", sortBy = "popularity.desc").results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getHorror(): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.discoverMoviesAdvanced(apiKey, withGenres = "27", sortBy = "popularity.desc").results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getDramas(): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.discoverMoviesAdvanced(apiKey, withGenres = "18", sortBy = "popularity.desc").results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getAwardWinning(): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.discoverMoviesAdvanced(apiKey, sortBy = "vote_average.desc", voteAverageGte = 8.0, voteCountGte = 500).results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getDocumentaries(): List<Movie> {
        return try {
            val rawResults = TmdbClient.instance.discoverMoviesAdvanced(apiKey, withGenres = "99", sortBy = "popularity.desc").results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getTvSeasonEpisodes(tvId: Long, seasonNumber: Int = 1): List<com.example.model.Episode> {
        return try {
            val response = TmdbClient.instance.getTvSeason(tvId, seasonNumber, apiKey)
            response.episodes.map { ep ->
                val still = ep.stillPath?.let { "https://image.tmdb.org/t/p/w500$it" } ?: ""
                val runtimeStr = ep.runtime?.let { "${it}m" } ?: "45m"
                com.example.model.Episode(
                    id = ep.id,
                    episodeNumber = ep.episodeNumber ?: 1,
                    seasonNumber = ep.seasonNumber ?: seasonNumber,
                    title = ep.name ?: "Episode ${ep.episodeNumber}",
                    description = ep.overview ?: "No description available.",
                    stillUrl = still,
                    runtime = runtimeStr
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getTvSeasons(tvId: Long): List<Int> {
        return try {
            val details = TmdbClient.instance.getTvDetails(tvId, apiKey)
            val seasonNumbers = details.seasons
                .map { it.seasonNumber }
                .filter { it > 0 }
                .distinct()
                .sorted()
            if (seasonNumbers.isNotEmpty()) seasonNumbers
            else {
                val num = details.numberOfSeasons ?: 1
                (1..num.coerceAtLeast(1)).toList()
            }
        } catch (e: Exception) {
            listOf(1)
        }
    }

    suspend fun searchMulti(query: String): List<Movie> {
        if (query.isBlank()) return emptyList()
        return try {
            val rawResults = TmdbClient.instance.searchMulti(apiKey, query).results
            mapToMovies(rawResults)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getGenres(): List<com.example.api.TmdbGenreDto> {
        return try {
            val movies = TmdbClient.instance.getMovieGenres(apiKey).genres
            val tv = TmdbClient.instance.getTvGenres(apiKey).genres
            (movies + tv).distinctBy { it.id }.sortedBy { it.name }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun discoverByGenre(genreId: Long): List<Movie> {
        return try {
            // We just fetch movies for simplicity, or we can fetch both and mix
            val movieResults = TmdbClient.instance.discoverMoviesByGenre(apiKey, genreId).results
            val tvResults = TmdbClient.instance.discoverTvByGenre(apiKey, genreId).results
            val mixed = (movieResults + tvResults).shuffled()
            mapToMovies(mixed)
        } catch (e: Exception) {
            emptyList()
        }
    }
}
